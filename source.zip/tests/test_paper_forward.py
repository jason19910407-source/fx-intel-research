# coding: utf-8
import sys,sqlite3,datetime as dt,json,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from fxintel import paper_forward as f,core
class Store:
 def __init__(self):
  self.c=sqlite3.connect(':memory:');self.c.row_factory=sqlite3.Row;self.c.executescript((Path(__file__).resolve().parents[1]/'cloud/schema.sql').read_text())
 def query(self,sql,params=()):
  cur=self.c.execute(sql,params);self.c.commit();return [dict(r) for r in cur.fetchall()]
class ForwardTests(unittest.TestCase):
 def setUp(self):
  self.s=Store();self.s.query('INSERT INTO forward_experiments VALUES(?,?,?,?)',(f.ID,'2026-11-06T16:00:00+00:00',f.RULE_HASH,f.ENCODED));self.c=core.connect(':memory:');self.at=f.stamp('2026-11-06T16:08:00Z');self.payload={'analysis':{'usable_source_count':33},'market_v2':{'pairs':[]}}
 def test_window_exactly_fourteen_days(self):self.assertEqual((f.stamp(f.CONFIG['end_exclusive'])-f.stamp(f.CONFIG['start'])).days,14)
 def test_twentyfour_decisions_no_fills_or_fake_metrics(self):
  r=f.record(self.s,self.c,self.payload,'test',self.at);row=self.s.query('SELECT body FROM forward_observations')[0];b=json.loads(row['body']);self.assertEqual(len(b['decisions']),24);self.assertTrue(all(x['entry'] is None and not x['executable'] for x in b['decisions']));self.assertIsNone(r['daily_report']['strategies']['A']['total_pnl_twd'])
 def test_slot_duplicate_does_not_modify(self):
  f.record(self.s,self.c,self.payload,'one',self.at);before=self.s.query('SELECT body FROM forward_observations');f.record(self.s,self.c,{},'two',self.at+dt.timedelta(minutes=2));self.assertEqual(before,self.s.query('SELECT body FROM forward_observations'))
 def test_database_prevents_changes(self):
  f.record(self.s,self.c,self.payload,'one',self.at)
  for sql in ['UPDATE forward_observations SET body=\'x\'','DELETE FROM forward_observations','UPDATE forward_experiments SET rules_hash=\'x\'']:
   with self.assertRaises(sqlite3.IntegrityError):self.s.query(sql)
 def test_hash_chain(self):
  f.record(self.s,self.c,self.payload,'one',self.at);f.record(self.s,self.c,self.payload,'two',self.at+dt.timedelta(minutes=30));a=self.s.query('SELECT * FROM forward_observations ORDER BY slot');self.assertEqual(a[1]['previous_hash'],a[0]['body_hash']);self.assertTrue(all(f.digest(x['body'])==x['body_hash'] for x in a))
 def test_no_backfill_before_activation(self):
  r=f.record(self.s,self.c,self.payload,'old',self.at-dt.timedelta(hours=1));self.assertFalse(self.s.query('SELECT * FROM forward_observations'))
 def test_final_report_no_new_observation(self):
  f.record(self.s,self.c,self.payload,'one',self.at);f.record(self.s,self.c,self.payload,'end',f.stamp(f.CONFIG['end_exclusive']));self.assertEqual(len(self.s.query('SELECT * FROM forward_observations')),1);self.assertTrue(self.s.query("SELECT * FROM forward_reports WHERE kind='final'"))
 def test_weekend_no_trade(self):
  self.assertFalse(f.market_open(f.stamp('2026-11-08T04:00:00Z')));d=f.decision('A','EURUSD',{},[],f.stamp('2026-11-08T04:00:00Z'),False);self.assertFalse(d['executable'])
 def item(self,**kw):
  d=dict(id='synthetic-unit-fixture',source_id='fed',title='Federal Reserve raises interest rates',link='https://www.federalreserve.gov/',published_at='2026-11-06T16:01:00Z',first_seen_at='2026-11-06T16:02:00Z',observed_at='2026-11-06T16:04:00Z');d.update(kw);return d
 def test_news_future_rejected(self):self.assertEqual(f.facts([self.item(published_at='2026-11-06T17:00:00Z')],self.at,f.stamp(f.CONFIG['start'])),[])
 def test_pretest_news_not_backfilled(self):self.assertEqual(f.facts([self.item(first_seen_at='2026-11-06T15:00:00Z')],self.at,f.stamp(f.CONFIG['start'])),[])
 def test_forecast_not_completed_action(self):self.assertEqual(f.facts([self.item(title='Federal Reserve expected to raise rates')],self.at,f.stamp(f.CONFIG['start'])),[])
 def test_news_and_tech_conflict_no_combined(self):
  news=f.facts([self.item()],self.at,f.stamp(f.CONFIG['start']));m={'technical':{tf:dict(valid=True,direction='偏多',score=80,setup='突破確認') for tf in ['D1','H4','H1']},'quote_quality':{'valid':True}};b=f.decision('B','EURUSD',m,news,self.at,True);self.assertEqual(b['direction'],'偏空');self.assertEqual(b['score'],70);c=f.decision('C','EURUSD',m,news,self.at,True);self.assertFalse(c['candidate']);self.assertFalse(b['executable']);self.assertIsNone(b['entry'])
 def test_risk_and_correlation(self):
  self.assertEqual(f.common_risk(35000,35000,[],{})['budget_twd'],525);self.assertFalse(f.common_risk(35000,35000,[{'risk_twd':525}],{})['passed']);self.assertFalse(f.common_risk(32000,35000,[],{})['passed']);self.assertTrue(f.common_risk(30000,35000,[],{})['stop_at_ten']);self.assertFalse(f.common_risk(33000,35000,[{'risk_twd':262.5,'exposure':{'USD':-1}}],{'USD':-1})['passed'])
if __name__=='__main__':unittest.main()
