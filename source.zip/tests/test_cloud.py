import unittest,tempfile,sqlite3,time,datetime as dt,json,copy,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from cloud.store import Store
from cloud.gates import eligibility,signal_id,REQUIRED
from cloud.notify import enqueue,deliver

class LocalStore(Store):
 def __init__(self):
  self.c=sqlite3.connect(':memory:');self.c.row_factory=sqlite3.Row
  self.c.executescript((Path(__file__).resolve().parents[1]/'cloud/schema.sql').read_text())
 def query(self,sql,params=()):
  cur=self.c.execute(sql,params);r=[dict(x) for x in cur.fetchall()] if cur.description else [];self.c.commit();return r

def candidate(at):
 return dict(pair='EURUSD',direction='做多',setup_id='isolated-unit-fixture',score=75,entry=1.10,stop=1.09,tp1=1.12,tp2=1.13,risk_twd=175,equity_twd=35000,units=1000,net_reward_risk=2,legacy_gate={'passed':True},conditions={k:True for k in REQUIRED},expires_at=(at+dt.timedelta(minutes=10)).isoformat(),data_at=at.isoformat(),reasons='隔離的通知閘門測試，非真實行情')

class Tests(unittest.TestCase):
 def setUp(self):self.s=LocalStore();self.at=dt.datetime.now(dt.timezone.utc);self.c=candidate(self.at)
 def test_daily_free_budget(self):
  for i in range(72):self.assertEqual(self.s.reserve_budget('2026-11-06'),i+1)
  with self.assertRaises(RuntimeError):self.s.reserve_budget('2026-11-06')
  self.assertEqual(self.s.reserve_budget('2026-11-07'),1)
 def test_lost_lease_cannot_commit_checkpoint(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'a.db';c=sqlite3.connect(p);c.execute('CREATE TABLE t(x)');c.commit();c.close();self.s.acquire('a',int(time.time())-700);self.s.acquire('b',int(time.time()))
   with self.assertRaises(RuntimeError):self.s.checkpoint(p,'abandoned','a')
   self.assertIsNone(self.s.value('checkpoint'))
 def test_lease_excludes_second_owner(self):
  n=int(time.time());self.assertTrue(self.s.acquire('a',n));self.assertFalse(self.s.acquire('b',n));self.s.release('b');self.assertTrue(self.s.owns('a'))
 def test_expired_lease_takeover(self):
  self.s.acquire('a',int(time.time())-700);self.assertTrue(self.s.acquire('b',int(time.time())))
 def test_checkpoint_restores_new_environment(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'a.db';c=sqlite3.connect(p);c.execute('CREATE TABLE proof(x TEXT)');c.execute("INSERT INTO proof VALUES('真實持久化機制測試')");c.commit();c.close();self.s.acquire('a',int(time.time()));self.s.checkpoint(p,'r1','a');q=Path(d)/'b.db';self.assertTrue(self.s.restore(q));self.assertEqual(sqlite3.connect(q).execute('SELECT x FROM proof').fetchone()[0],'真實持久化機制測試')
 def test_missing_chunk_fails_closed(self):
  self.s.put('checkpoint',json.dumps(dict(generation='x',parts=1,sha256='bad')))
  with self.assertRaises(RuntimeError):self.s.restore('/not-written')
 def test_below_70_rejected(self):
  self.c['score']=69;self.assertFalse(eligibility(self.c,self.at)['passed']);self.assertFalse(enqueue(self.s,self.c,self.at)['enqueued'])
 def test_high_score_risk_rejected(self):
  self.c['score']=100;self.c['conditions']['cost_verified']=False;self.assertFalse(enqueue(self.s,self.c,self.at)['enqueued'])
 def test_legacy_gate_cannot_bypass(self):
  self.c['legacy_gate']['passed']=False;self.assertFalse(eligibility(self.c,self.at)['passed'])
 def test_all_required_guards(self):
  for k in REQUIRED:
   c=copy.deepcopy(self.c);c['conditions'][k]=False;self.assertFalse(eligibility(c,self.at)['passed'],k)
 def test_nan_score(self):
  self.c['score']=float('nan');self.assertFalse(eligibility(self.c,self.at)['passed'])
 def test_stale_quote(self):
  self.c['data_at']=(self.at-dt.timedelta(seconds=61)).isoformat();self.assertFalse(eligibility(self.c,self.at)['passed'])
 def test_future_quote(self):
  self.c['data_at']=(self.at+dt.timedelta(seconds=1)).isoformat();self.assertFalse(eligibility(self.c,self.at)['passed'])
 def test_expired_signal(self):
  self.c['expires_at']=self.at.isoformat();self.assertFalse(eligibility(self.c,self.at)['passed'])
 def test_simulation_forbidden(self):
  self.c['simulation']=True;self.assertFalse(eligibility(self.c,self.at)['passed'])
 def test_rr_and_budget(self):
  for k,v in [('net_reward_risk',1.99),('risk_twd',351),('risk_twd',174),('equity_twd',35001),('entry',float('nan'))]:
   c=copy.deepcopy(self.c);c[k]=v;self.assertFalse(eligibility(c,self.at)['passed'])
 def test_duplicate_sent_once(self):
  enqueue(self.s,self.c,self.at);enqueue(self.s,self.c,self.at);calls=[]
  def send(text):calls.append(text);return 'sent','123',None
  deliver(self.s,send,self.at);deliver(self.s,send,self.at);self.assertEqual(len(calls),1);self.assertIn('研究訊號，非已驗證交易策略',calls[0])
 def test_score_changes_do_not_duplicate(self):
  a=signal_id(self.c);self.c['score']=85;self.assertEqual(a,signal_id(self.c))
 def test_unknown_delivery_no_retry(self):
  enqueue(self.s,self.c,self.at);calls=[]
  def send(text):calls.append(text);return 'unknown',None,'timeout'
  deliver(self.s,send,self.at);deliver(self.s,send,self.at);self.assertEqual(len(calls),1)
 def test_crash_sending_no_retry(self):
  enqueue(self.s,self.c,self.at);self.s.query("UPDATE outbox SET status='sending'");calls=[];deliver(self.s,lambda t:calls.append(t),self.at);self.assertEqual(calls,[])
 def test_database_failure_blocks_send(self):
  enqueue(self.s,self.c,self.at);original=self.s.query;calls=[]
  def broken(sql,params=()):
   if sql.startswith('UPDATE outbox SET status=\'sending\''):raise RuntimeError('DB故障')
   return original(sql,params)
  self.s.query=broken
  with self.assertRaises(RuntimeError):deliver(self.s,lambda t:calls.append(t),self.at)
  self.assertEqual(calls,[])
 def test_legacy_strategy_still_unapproved(self):
  sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'));from fxintel import core
  self.assertIs(core.STRATEGY_APPROVED,False)

if __name__=='__main__':unittest.main(verbosity=2)
