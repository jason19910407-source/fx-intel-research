# coding: utf-8
import unittest,datetime as dt,sys,sqlite3
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from fxintel.marketdata import *
from fxintel.technical import indicators,integrate
from fxintel.research_v2 import report_slot,risk_budget
class MarketV2(unittest.TestCase):
 def row(self,h):
  a=dt.datetime(2026,11,2,h,tzinfo=UTC);return dict(opened_at=iso(a),closed_at=iso(a+dt.timedelta(hours=1)),known_at=iso(a+dt.timedelta(hours=1)),open=1.,high=1.2,low=.9,close=1.1,complete=True,coverage=1)
 def test_no_future_or_partial(self):
  rows=[self.row(h) for h in range(4)]
  self.assertEqual(aggregate(rows,'H4',stamp('2026-11-02T03:59Z'),'test','EURUSD'),[])
  self.assertEqual(aggregate(rows,'H4',stamp('2026-11-02T04:00Z'),'test','EURUSD')[0]['complete'],1)
 def test_missing_not_filled(self):
  r=aggregate([self.row(h) for h in [0,1,3]],'H4',stamp('2026-11-02T04:00Z'),'test','EURUSD')[0]
  self.assertEqual(r['complete'],0);self.assertEqual(r['coverage'],.75)
 def test_duplicate_rejected(self):
  with self.assertRaises(ValueError):aggregate([self.row(0),self.row(0)],'H1',stamp('2026-11-02T04:00Z'),'test','EURUSD')
 def test_quote_time_not_receipt(self):
  q=dict(bid=1,ask=1.1,received_at='2026-11-02T04:00Z',quote_time=None,kind='即時指示買賣價',timezone_verified=False,license_verified=True)
  self.assertFalse(quote_status(q,stamp('2026-11-02T04:00Z'))['valid'])
 def test_crossed_or_future_quote(self):
  q=dict(bid=2,ask=1,quote_time='2026-11-02T04:01Z',kind='即時指示買賣價',timezone_verified=True,license_verified=True)
  self.assertFalse(quote_status(q,stamp('2026-11-02T04:00Z'))['valid'])
 def test_new_york_dst(self):
  a,b=interval(stamp('2026-07-08T12:00Z'),'D1');self.assertEqual(a.hour,21)
  a,b=interval(stamp('2026-11-04T12:00Z'),'D1');self.assertEqual(a.hour,22)
 def test_weekend(self):
  self.assertFalse(market_open(stamp('2026-11-07T12:00Z')))
  self.assertTrue(market_open(stamp('2026-11-08T22:00Z')))
 def test_revision_asof(self):
  c=sqlite3.connect(':memory:');init(c)
  r=aggregate([self.row(0)],'H1',stamp('2026-11-02T02:00Z'),'test','EURUSD')[0]
  fields=','.join(r);c.execute('INSERT INTO market_bars_v2 ('+fields+') VALUES('+','.join('?' for x in r)+')',list(r.values()))
  r.update(known_at='2026-11-03T00:00:00+00:00',close=1.15)
  c.execute('INSERT INTO market_bars_v2 ('+fields+') VALUES('+','.join('?' for x in r)+')',list(r.values()))
  self.assertEqual(latest_bars(c,'EURUSD','H1',stamp('2026-11-02T02:00Z'))[0]['close'],1.1)
 def test_five_report_times(self):
  hours=[h for h in range(24) if report_slot(stamp('2026-11-02T%02d:08:00+08:00'%h))]
  self.assertEqual(hours,[0,8,12,16,20])
 def test_risk_limits(self):
  self.assertEqual(risk_budget(35000,35000,0,True)['risk_budget_twd'],525)
  self.assertEqual(risk_budget(33000,35000,0,True)['risk_budget_twd'],262.5)
  self.assertEqual(risk_budget(32000,35000,0,True)['risk_budget_twd'],0)
  self.assertEqual(risk_budget(35000,35000,525,True)['risk_budget_twd'],175)
  self.assertEqual(risk_budget(35000,35000,0,False)['risk_budget_twd'],0)
 def test_news_absence_no_imputed_score(self):
  t={k:dict(valid=True,direction='偏多',score=80) for k in ['D1','H4','H1']}
  self.assertIsNone(integrate(t,{})['score'])
  self.assertLess(integrate(t,dict(direction='偏空',score=100))['score'],70)
class TechnicalNumerics(unittest.TestCase):
 def fixture(self):
  rows=[];a=stamp('2026-11-02T00:00Z')
  for i in range(100):
   x=a+dt.timedelta(hours=i);rows.append(dict(opened_at=iso(x),closed_at=iso(x+dt.timedelta(hours=1)),known_at=iso(x+dt.timedelta(hours=1)),open=1.5,high=2.,low=1.,close=1.5,complete=True))
  return rows,a+dt.timedelta(hours=100)
 def test_constant_prices_exact_values(self):
  rows,at=self.fixture();r=indicators(rows,at)
  self.assertTrue(r['valid']);self.assertEqual(r['rsi14'],50);self.assertEqual(r['ma20'],1.5);self.assertEqual(r['ma60'],1.5);self.assertAlmostEqual(r['macd'],0);self.assertEqual(r['atr14'],1)
 def test_future_and_invalid_price_rejected(self):
  rows,at=self.fixture();self.assertFalse(indicators(rows,at-dt.timedelta(minutes=1))['valid'])
  rows[-1]['close']=float('nan');self.assertFalse(indicators(rows,at)['valid'])
 def test_missing_hour_rejected(self):
  rows,at=self.fixture();rows=rows[:50]+rows[51:];rows.insert(0,dict(rows[0],opened_at=iso(stamp(rows[0]['opened_at'])-dt.timedelta(hours=1)),closed_at=rows[0]['opened_at']))
  self.assertFalse(indicators(rows,at)['valid'])
class FormalReports(unittest.TestCase):
 def test_slot_dedup_and_no_four_am(self):
  from fxintel.formal_reports import update
  c=sqlite3.connect(':memory:');m=dict(pairs=[],as_of='2026-11-02T00:08:00+00:00',validation='尚未通過交易策略驗證')
  at=stamp('2026-11-02T08:08:00+08:00');update(c,m,at,[]);update(c,m,at,[])
  self.assertEqual(c.execute('SELECT count(*) FROM formal_reports_v2').fetchone()[0],1)
  update(c,m,stamp('2026-11-03T04:08:00+08:00'),[])
  self.assertEqual(c.execute('SELECT count(*) FROM formal_reports_v2').fetchone()[0],1)
 def test_weekend_pause_and_actual_delay(self):
  from fxintel.formal_reports import update
  c=sqlite3.connect(':memory:');m=dict(pairs=[],as_of='2026-11-07T00:08:00+00:00',validation='尚未通過交易策略驗證')
  r=update(c,m,stamp('2026-11-07T08:08:00+08:00'),[])[0]
  self.assertEqual(r['status'],'週末暫停');self.assertEqual(r['publication_delay_seconds'],480)
if __name__=='__main__':unittest.main()
