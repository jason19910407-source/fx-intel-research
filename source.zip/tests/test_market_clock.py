# coding: utf-8
import sys,unittest,datetime as dt
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from fxintel import pipeline_v2 as p,core,marketdata as md,paper_forward_v2 as f,formal_reports
class MarketClockTests(unittest.TestCase):
 def test_cache_second_run_no_fetch_or_duplicate_keys(self):
  c=core.connect(':memory:');p.init(c)
  for pair in md.PAIRS:p.put(c,'mh:'+pair,dict(pair=pair,status='已更新',next_due='2099-01-01T00:00:00+00:00'))
  with patch.object(p,'get_free',side_effect=AssertionError('不得連線')):
   rows=p.update_bars(c,fetch=lambda u:self.fail('快取不應擷取'),sleep=lambda t:None)
  self.assertEqual(len(rows),8);self.assertTrue(all(r['status']=='每日批次快取未到期' for r in rows))
 def test_weekend_latest_bars_not_fault(self):
  for tf,close in [('H1','2026-11-06T22:00:00Z'),('H4','2026-11-07T00:00:00Z')]:
   r=p.bar_clock(close,tf,'2026-11-08T08:00:00Z');self.assertFalse(r['market_open']);self.assertTrue(r['latest_expected_bar_present']);self.assertEqual(r['open_market_age_seconds'],0)
 def test_friday_gap_not_hidden_by_weekend(self):
  r=p.bar_clock('2026-11-06T20:00:00Z','H1','2026-11-08T08:00:00Z');self.assertFalse(r['latest_expected_bar_present']);self.assertEqual(r['open_market_age_seconds'],7200)
 def test_opening_and_dst(self):
  self.assertFalse(md.market_open('2026-11-08T21:59:00Z'));self.assertTrue(md.market_open('2026-11-08T22:00:00Z'))
  self.assertFalse(md.market_open('2026-07-05T20:59:00Z'));self.assertTrue(md.market_open('2026-07-05T21:00:00Z'))
  r=p.bar_clock('2026-11-06T22:00:00Z','H1','2026-11-08T23:00:00Z');self.assertFalse(r['latest_expected_bar_present']);self.assertEqual(r['latest_expected_closed_at'],'2026-11-08T23:00:00+00:00')
 def test_b_direction_independent_of_missing_technical(self):
  at=md.stamp('2026-11-10T12:00:00Z');news=[dict(id='isolated-unit-test',currency='EUR',direction=1,age_seconds=3600,source_id='ecb')]
  b=f.decision('B','EURUSD',{},news,at,False);a=f.decision('A','EURUSD',{},news,at,False);z=f.decision('C','EURUSD',{},news,at,False)
  self.assertEqual((b['score'],b['direction'],b['candidate']),(70,'偏多',True));self.assertFalse(b['executable']);self.assertFalse(a['candidate']);self.assertFalse(z['candidate'])
 def test_pipeline_contract_at_all_report_slots_weekend_and_open(self):
  for day in ['2026-11-08','2026-11-10']:
   for hour in [0,4,8,12,16,20]:
    with self.subTest(day=day,hour=hour):
     c=core.connect(':memory:');at=md.stamp(day+'T%02d:08:00+08:00'%hour)
     market=p.snapshot(c,at);self.assertEqual(market['validation'],'尚未通過交易策略驗證');self.assertEqual(len(market['pairs']),8)
     reports=formal_reports.update(c,market,at,[])
     self.assertEqual(len(reports),0 if hour==4 else 1)
     if reports:
      self.assertEqual(len(reports[0]['pairs']),8);self.assertEqual(reports[0]['qualified_opportunities'],[])
      self.assertEqual(reports[0]['status'],'週末暫停' if not md.market_open(at) else '已完成資料限制研究報告')
     c.close()
if __name__=='__main__':unittest.main()
