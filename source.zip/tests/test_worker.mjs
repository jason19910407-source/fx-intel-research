import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {fetchHandler,authenticated,scheduledHandler} from '../cloud/worker.mjs';
class D1 {
 constructor(){this.db=new DatabaseSync(':memory:');this.db.exec(readFileSync(new URL('../cloud/schema.sql',import.meta.url),'utf8'));}
 prepare(sql){const db=this.db;let params=[];const api={bind(...p){params=p;return api},async first(){return db.prepare(sql).get(...params)||null},async all(){return {results:db.prepare(sql).all(...params)}},async run(){return db.prepare(sql).run(...params)}};return api;}
}
const hash=async s=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))].map(v=>v.toString(16).padStart(2,'0')).join('');
async function environment(){return {FX_DB:new D1(),LOGIN_PASSWORD_HASH:await hash('a'.repeat(40)),SESSION_SECRET:'s'.repeat(40)}}
async function login(env,password='a'.repeat(40),origin='https://fx.example'){return fetchHandler(new Request('https://fx.example/login',{method:'POST',headers:{Origin:origin,'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({password})}),env)}
async function signedRequest(env,path='/api/dashboard'){const r=await login(env);return new Request('https://fx.example'+path,{headers:{Cookie:r.headers.get('Set-Cookie').split(';')[0]}})}
test('未設定憑證拒絕提供資料',async()=>assert.equal((await fetchHandler(new Request('https://fx.example/'),{})).status,503));
test('未登入不能取得分析',async()=>assert.equal((await fetchHandler(new Request('https://fx.example/api/dashboard'),await environment())).status,401));
test('登入頁為繁體中文且沒有資料庫金鑰',async()=>{const r=await fetchHandler(new Request('https://fx.example/'),await environment());assert.match(await r.text(),/私人頁面登入/);assert.match(r.headers.get('Content-Security-Policy'),/frame-ancestors 'none'/)});
test('正確登入取得安全cookie',async()=>{const e=await environment(),r=await login(e);assert.equal(r.status,303);assert.match(r.headers.get('Set-Cookie'),/HttpOnly; Secure; SameSite=Strict/)});
test('錯誤密碼拒絕登入',async()=>assert.equal((await login(await environment(),'x'.repeat(40))).status,401));
test('跨站登入拒絕',async()=>assert.equal((await login(await environment(),'a'.repeat(40),'https://evil.example')).status,403));
test('登入暴力嘗試限流',async()=>{const e=await environment();for(let i=0;i<10;i++)await login(e,'x'.repeat(40));assert.equal((await login(e)).status,429)});
test('偽造cookie無法通過',async()=>assert.equal(await authenticated(new Request('https://fx.example/',{headers:{Cookie:'__Host-fx_session=9999999999999.x.fake'}}),await environment()),false));
test('登入後可取得只讀頁面',async()=>{const e=await environment(),r=await fetchHandler(await signedRequest(e,'/'),e);assert.match(await r.text(),/外匯市場情報研究台/)});
test('沒有分析時標示過期',async()=>{const e=await environment(),r=await fetchHandler(await signedRequest(e),e);assert.equal((await r.json()).stale,true)});
test('過期分析隱藏訊號',async()=>{const e=await environment();e.FX_DB.db.prepare('INSERT INTO kv VALUES(?,?)').run('latest',JSON.stringify({analysis:{analyzed_at:'2022-01-01T00:00:00Z'},signals:[{id:'unit-fixture'}]}));const d=await (await fetchHandler(await signedRequest(e),e)).json();assert.equal(d.stale,true);assert.deepEqual(d.signals,[])});
test('不接受本機管理及下單路由',async()=>{const e=await environment(),req=await signedRequest(e);for(const path of ['/api/orders','/api/simulation','/api/equity']){const r=await fetchHandler(new Request('https://fx.example'+path,{method:'POST',headers:req.headers}),e);assert.equal(r.status,405)}});
test('資料不會進入共享快取',async()=>{const e=await environment(),r=await fetchHandler(await signedRequest(e),e);assert.equal(r.headers.get('Cache-Control'),'no-store')});
test('系統監控警報具持久化去重且不冒充交易訊號',async()=>{const e=await environment();await scheduledHandler({},e);await scheduledHandler({},e);const rows=e.FX_DB.db.prepare('SELECT * FROM outbox').all();assert.equal(rows.length,1);assert.equal(rows[0].kind,'system');assert.match(rows[0].body,/非交易訊號/)});
test('最新成功分析不產生故障警報',async()=>{const e=await environment();e.FX_DB.db.prepare('INSERT INTO kv VALUES(?,?)').run('last_success_at',new Date().toISOString());await scheduledHandler({},e);assert.equal(e.FX_DB.db.prepare('SELECT count(*) n FROM outbox').get().n,0)});
