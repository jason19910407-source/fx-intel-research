import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {fetchHandler,authenticated,scheduledHandler} from '../cloud/worker.mjs';
class D1 {
 constructor(){this.db=new DatabaseSync(':memory:');this.db.exec(readFileSync(new URL('../cloud/schema.sql',import.meta.url),'utf8'));}
 prepare(sql){const db=this.db;let params=[];const api={bind(...p){params=p;return api},async first(){return db.prepare(sql).get(...params)||null},async all(){return {results:db.prepare(sql).all(...params)}},async run(){return db.prepare(sql).run(...params)}};return api;}
}
const hash=async s=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))].map(v=>v.toString(16).padStart(2,'0')).join('');
async function environment(){return {FX_DB:new D1(),LOGIN_PASSWORD_HASH:await hash('a'.repeat(40)),SESSION_SECRET:'s'.repeat(40)}}
async function login(env,password='a'.repeat(40),origin='https://fx.example'){return fetchHandler(new Request('https://fx.example/login',{method:'POST',headers:{Origin:origin,'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({password})}),env)}
async function signedRequest(env,path='/api/dashboard'){const r=await login(env);return new Request('https://fx.example'+path,{headers:{Cookie:r.headers.get('Set-Cookie').split(';')[0]}})}
test('未設定憑證拒絕提供資料',async()=>assert.equal((await fetchHandler(new Request('https://fx.example/'),{})).status,503));
test('未登入不能取得分析',async()=>assert.equal((await fetchHandler(new Request('https://fx.example/api/dashboard'),await environment())).status,401));
test('登入頁為繁體中文且沒有資料庫金鑰',async()=>{const r=await fetchHandler(new Request('https://fx.example/'),await environment());assert.match(await r.text(),/私人頁面登入/);assert.match(r.headers.get('Content-Security-Policy'),/frame-ancestors 'none'/)});
test('正確登入取得安全cookie',async()=>{const e=await environment(),r=await login(e);assert.equal(r.status,303);assert.match(r.headers.get('Set-Cookie'),/HttpOnly; Secure; SameSite=Strict/)});
test('錯誤密碼拒絕登入',async()=>assert.equal((await login(await environment(),'x'.repeat(40))).status,401));
test('跨站登入拒絕',async()=>assert.equal((await login(await environment(),'a'.repeat(40),'https://evil.example')).status,403));
test('登入暴力嘗試限流',async()=>{const e=await environment();for(let i=0;i<10;i++)await login(e,'x'.repeat(40));assert.equal((await login(e)).status,429)});
test('偽造cookie無法通過',async()=>assert.equal(await authenticated(new Request('https://fx.example/',{headers:{Cookie:'__Host-fx_session=9999999999999.x.fake'}}),await environment()),false));
test('登入後可取得只讀頁面',async()=>{const e=await environment(),r=await fetchHandler(await signedRequest(e,'/'),e);assert.match(await r.text(),/外匯市場情報研究台/)});
test('沒有分析時標示過期',async()=>{const e=await environment(),r=await fetchHandler(await signedRequest(e),e);assert.equal((await r.json()).stale,true)});
test('過期分析隱藏訊號',async()=>{const e=await environment();e.FX_DB.db.prepare('INSERT INTO kv VALUES(?,?)').run('latest',JSON.stringify({analysis:{analyzed_at:'2022-01-01T00:00:00Z'},signals:[{id:'unit-fixture'}]}));const d=await (await fetchHandler(await signedRequest(e),e)).json();assert.equal(d.stale,true);assert.deepEqual(d.signals,[])});
test('不接受本機管理及下單路由',async()=>{const e=await environment(),req=await signedRequest(e);for(const path of ['/api/orders','/api/simulation','/api/equity']){const r=await fetchHandler(new Request('https://fx.example'+path,{method:'POST',headers:req.headers}),e);assert.equal(r.status,405)}});
test('資料不會進入共享快取',async()=>{const e=await environment(),r=await fetchHandler(await signedRequest(e),e);assert.equal(r.headers.get('Cache-Control'),'no-store')});
test('系統監控警報具持久化去重且不冒充交易訊號',async()=>{const e=await environment();await scheduledHandler({},e);await scheduledHandler({},e);const rows=e.FX_DB.db.prepare('SELECT * FROM outbox').all();assert.equal(rows.length,1);assert.equal(rows[0].kind,'system');assert.match(rows[0].body,/非交易訊號/)});
test('最新成功分析不產生故障警報',async()=>{const e=await environment();e.FX_DB.db.prepare('INSERT INTO kv VALUES(?,?)').run('last_success_at',new Date().toISOString());await scheduledHandler({},e);assert.equal(e.FX_DB.db.prepare('SELECT count(*) n FROM outbox').get().n,0)});

test('恢復後解除舊健康警報，不解除授權到期提醒',async()=>{const e=await environment();await scheduledHandler({},e);e.FX_DB.db.prepare("INSERT INTO outbox(id,kind,created_at,expires_at,body,status) VALUES('dispatch-expiry-fixture','system','x','x','{}','pending')").run();e.FX_DB.db.prepare("INSERT INTO kv VALUES('last_success_at',?)").run(new Date().toISOString());await scheduledHandler({},e);const old=e.FX_DB.db.prepare("SELECT status FROM outbox WHERE id LIKE 'system-health-%'").get();assert.equal(old.status,'expired');assert.equal(e.FX_DB.db.prepare("SELECT status FROM outbox WHERE id='dispatch-expiry-fixture'").get().status,'pending')});

test('登入頁同源來源政策避免Chrome表單被誤擋',async()=>{const r=await fetchHandler(new Request('https://fx.example/'),await environment());assert.equal(r.headers.get('Referrer-Policy'),'same-origin')});
test('登入30天且第31天失效',async()=>{const e=await environment(),start=Date.now(),r=await login(e),cookie=r.headers.get('Set-Cookie');assert.match(cookie,/Max-Age=2592000/);const q=new Request('https://fx.example/',{headers:{Cookie:cookie.split(';')[0]}});assert.equal(await authenticated(q,e,start+29*86400000),true);assert.equal(await authenticated(q,e,start+31*86400000),false)});
test('改密碼後舊密碼及既有登入立即失效',async()=>{const e=await environment(),old=await login(e),q=new Request('https://fx.example/',{headers:{Cookie:old.headers.get('Set-Cookie').split(';')[0]}});e.LOGIN_PASSWORD_HASH=await hash('b'.repeat(16));assert.equal(await authenticated(q,e),false);assert.equal((await login(e)).status,401);assert.equal((await login(e,'b'.repeat(16))).status,303)});
test('登出後舊Cookie重播也失效',async()=>{const e=await environment(),req=await signedRequest(e),cookie=req.headers.get('Cookie');const logout=await fetchHandler(new Request('https://fx.example/logout',{method:'POST',headers:{Origin:'https://fx.example',Cookie:cookie}}),e);assert.equal(logout.status,303);assert.match(logout.headers.get('Set-Cookie'),/Max-Age=0/);assert.equal(await authenticated(req,e),false)});
test('手機及電腦各自登入互不踢出，只登出目前裝置',async()=>{const e=await environment(),a=await signedRequest(e),b=await signedRequest(e);await fetchHandler(new Request('https://fx.example/logout',{method:'POST',headers:{Origin:'https://fx.example',Cookie:a.headers.get('Cookie')}}),e);assert.equal(await authenticated(a,e),false);assert.equal(await authenticated(b,e),true)});
test('跨站登出遭拒，合法登入保持有效',async()=>{const e=await environment(),a=await signedRequest(e);const r=await fetchHandler(new Request('https://fx.example/logout',{method:'POST',headers:{Origin:'https://evil.example',Cookie:a.headers.get('Cookie')}}),e);assert.equal(r.status,403);assert.equal(await authenticated(a,e),true)});
