# coding: utf-8
import sys,json,datetime as dt,unittest,ast,sqlite3
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from fxintel import core,collect,pipeline_v2 as p,paper_forward as old,paper_forward_v2 as new,marketdata as md
from test_paper_forward import Store
class PipelineTests(unittest.TestCase):
 def setUp(self):self.c=core.connect(':memory:');p.init(self.c);self.at=md.stamp('2026-11-10T12:00:00Z')
 def insert_news(self,source,key,published):
  self.c.execute('INSERT INTO items(id,source_id,title,title_zh,link,published_at,first_seen_at,observed_at,topic,currencies,payload) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(key,source,'unit-test headline','單元測試','',''+published,'2026-11-10T10:00:00+00:00','2026-11-10T10:00:00+00:00','政策','[]','{}'))
 def test_policy_news_survives_hundreds_of_other_source_items(self):
  for i in range(350):self.insert_news('supplement',str(i),'2026-11-10T11:00:00+00:00')
  self.insert_news('fed','policy','2026-11-10T09:00:00+00:00');items=p.select_news(self.c,self.at);self.assertIn('policy',[i['id'] for i in items]);self.assertEqual(sum(i['source_id']=='supplement' for i in items),2)
 def test_future_news_and_calendar_not_used_as_published_news(self):
  self.insert_news('fed','future','2026-11-11T09:00:00+00:00');self.insert_news('ons_calendar','calendar','2026-11-10T09:00:00+00:00');self.assertEqual(p.select_news(self.c,self.at),[])
 def test_rss_updated_is_not_original_publication(self):
  src=dict(id='unit',name='test',currencies=['USD'],documentation='https://example.com');items,_=collect.rss(src,b'<feed><entry><title>test</title><id>x</id><updated>2026-11-10T10:00:00Z</updated></entry></feed>');self.assertIsNone(items[0]['published_at'])
 def test_official_calendar_keeps_first_known_and_missing_values(self):
  s=dict(id='ons_calendar',name='test',currencies=['GBP'],documentation='https://example.com',parser='ons_calendar');raw=json.dumps({'releases':[{'uri':'/releases/unit','description':{'title':'unit-test GDP','release_date':'2026-11-13T07:00:00Z','finalised':True}}]}).encode();items,_=p.parse_calendar(s,raw);p.calendar_item(self.c,items[0],'2026-11-10T11:00:00+00:00');p.calendar_item(self.c,items[0],'2026-11-10T11:30:00+00:00');d=p.calendar_snapshot(self.c,self.at);self.assertEqual(d['known_event_count'],1);e=d['events'][0];self.assertEqual(e['first_available_to_system'],'2026-11-10T11:00:00+00:00');self.assertIsNone(e['actual_value']);self.assertIsNone(e['expected_value']);self.assertFalse(d['coverage_verified']);self.assertIsNone(items[0]['published_at'])
 def test_future_calendar_revision_not_visible_earlier(self):
  self.c.execute('INSERT INTO official_calendar_versions VALUES(?,?,?,?,?)',('x','k','s','2026-11-11T00:00:00+00:00','{}'));self.assertEqual(p.calendar_snapshot(self.c,self.at)['events'],[])
 def test_census_does_not_mix_other_tables_or_invent_dst(self):
  s=dict(id='census_calendar',name='test',currencies=['USD'],documentation='https://example.com',endpoint='https://www.census.gov/foreign-trade/schedule.html',parser='census_calendar');raw=b'Eastern <table><tr><th>Statistical Month</th><th>Data Release</th><th>Day</th></tr><tr><td>September 2026</td><td>November 4, 2026</td><td>WED</td></tr></table><table><tr><td>September 2026</td><td>November 9, 2026</td><td>MON</td></tr></table>';items,_=p.parse_calendar(s,raw);self.assertEqual(len(items),1);self.assertEqual(json.loads(items[0]['payload'])['event_time'],'2026-11-04T13:30:00+00:00')
 def row(self,h):return dict(opened_at=md.iso(h),closed_at=md.iso(h+dt.timedelta(hours=1)),known_at='2026-11-10T11:00:00+00:00',open=1.,high=1.2,low=.9,close=1.1,complete=1)
 def test_closed_weekend_hours_not_fabricated_but_open_hour_gap_invalid(self):
  h=md.stamp('2026-11-08T22:00:00Z');rows=[self.row(h),self.row(h+dt.timedelta(hours=1))];a=p.aggregate_open_hours(rows,'H4',self.at,'EURUSD');self.assertEqual(a[0]['complete'],1);self.assertEqual(a[0]['coverage'],1);b=p.aggregate_open_hours(rows[:1],'H4',self.at,'EURUSD');self.assertEqual(b[0]['complete'],0);self.assertEqual(b[0]['coverage'],.5)
 def test_no_paid_or_unknown_network_path(self):
  for url in ['https://getmarkethistory.com/query/v1/bars/fx/global/EURUSD/1h','https://example.com/api/v1/bars/fx/global/EURUSD/1h']:
   with self.assertRaises(ValueError):p.get_free(url)
 def test_indicator_and_strategy_rules_unchanged(self):
  a=Path(old.__file__).read_text();b=Path(new.__file__).read_text()
  for name in ['facts','decision','common_risk']:
   fa=next(n for n in ast.parse(a).body if isinstance(n,ast.FunctionDef) and n.name==name);fb=next(n for n in ast.parse(b).body if isinstance(n,ast.FunctionDef) and n.name==name);self.assertEqual(ast.dump(fa),ast.dump(fb))
 def test_versions_separate_and_old_record_not_changed(self):
  store=Store();store.query('INSERT INTO forward_experiments VALUES(?,?,?,?)',(old.ID,'2026-11-06T16:00:00+00:00',old.RULE_HASH,old.ENCODED));old.record(store,self.c,{'market_v2':{'pairs':[]}},'old',self.at);before=store.query('SELECT id,body,body_hash FROM forward_observations');store.query('INSERT INTO forward_experiments VALUES(?,?,?,?)',(new.ID,'2026-11-10T11:00:00+00:00',new.RULE_HASH,new.ENCODED));result=new.record(store,self.c,{'market_v2':{'pairs':[]}},'new',self.at);self.assertEqual(store.query('SELECT id,body,body_hash FROM forward_observations WHERE experiment=?',(old.ID,)),before);self.assertNotEqual(new.RULE_HASH,old.RULE_HASH);self.assertFalse(result['execution_enabled']);self.assertEqual(len(store.query('SELECT id FROM forward_observations')),2)
 def test_received_time_not_replaced_by_historical_bar_close(self):
  raw=json.dumps(dict(symbol='EURUSD',timestamp='2026-11-09T12:00:00Z',open=1.,high=1.1,low=.9,close=1.,is_gap=False,gap_fill_method=0)).encode();p.ingest_hourly(self.c,'EURUSD',raw,self.at);r=self.c.execute("SELECT known_at FROM market_bars_v2 WHERE timeframe='H1'").fetchone();self.assertEqual(r[0],md.iso(self.at));self.assertEqual(p.source_rows(self.c,'EURUSD','H1',self.at-dt.timedelta(minutes=1)),[])
if __name__=='__main__':unittest.main()
