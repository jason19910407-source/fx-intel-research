import {test} from 'node:test';import assert from 'node:assert/strict';
import {trustedClaims,verifyGithub} from '../cloud/oidc.mjs';
const env={GITHUB_REPOSITORY:'example/research',GITHUB_OWNER_ID:'123',GITHUB_REPOSITORY_ID:'456',OIDC_AUDIENCE:'https://research.example'};
const now=1700000000;
const valid=()=>({iss:'https://token.actions.githubusercontent.com',aud:env.OIDC_AUDIENCE,repository:env.GITHUB_REPOSITORY,repository_owner_id:'123',repository_id:'456',ref:'refs/heads/main',ref_type:'branch',runner_environment:'github-hosted',workflow_ref:'example/research/.github/workflows/analyze.yml@refs/heads/main',event_name:'schedule',sub:'repo:example@123/research@456:ref:refs/heads/main',exp:now+300,nbf:now-5,iat:now-5});
test('只接受已綁定的GitHub專案及工作流程',()=>assert.equal(trustedClaims(valid(),env,now),true));
for(const [key,value] of Object.entries({iss:'https://attacker.example',aud:'https://other.example',repository:'attacker/fork',repository_owner_id:'999',repository_id:'999',ref:'refs/heads/dev',ref_type:'tag',runner_environment:'self-hosted',workflow_ref:'example/research/.github/workflows/other.yml@refs/heads/main',event_name:'pull_request',sub:'repo:attacker/fork:ref:refs/heads/main',exp:now-1,nbf:now+60,iat:now+60}))test('拒絕不合格聲明：'+key,()=>assert.equal(trustedClaims({...valid(),[key]:value},env,now),false));
test('拒絕偽造未簽名憑證',async()=>assert.equal(await verifyGithub(new Request('https://research.example/internal/query',{headers:{Authorization:'Bearer eyJhbGciOiJub25lIn0.e30.fake'}}),env),false));
test('沒有憑證拒絕存取',async()=>assert.equal(await verifyGithub(new Request('https://research.example/internal/query'),env),false));
