# coding: utf-8
"""第二版固定研究條件；不提供任何交易端點。"""
from zoneinfo import ZoneInfo
import math
from .marketdata import stamp
REPORT_HOURS=(0,8,12,16,20)
RISK=dict(initial_twd=35000,risk_fraction=.015,risk_twd=525,total_open_risk_fraction=.02,reduce_drawdown=.05,stop_new_drawdown=.08,stop_live_drawdown=.10,reward_risk=2)
def report_slot(at):
 t=stamp(at).astimezone(ZoneInfo('Asia/Taipei'))
 # 半小時工作於08分取得該時槽，唯一鍵防重送；正式報告不是每4小時無條件包含04點。
 if t.hour not in REPORT_HOURS or t.minute>=30:return None
 return t.strftime('%Y-%m-%dT%H:00+08:00')
def risk_budget(equity,peak,open_risk_twd,exposure_verified=False):
 if not all(math.isfinite(x) for x in [equity,peak,open_risk_twd]) or equity<0 or peak<=0 or open_risk_twd<0:raise ValueError('帳戶或風險數值無效')
 dd=max(0,1-equity/max(35000,peak));remaining=max(0,700-open_risk_twd)
 budget=min(525*(.5 if dd+1e-12>=.05 else 1),remaining)
 reasons=[]
 if dd+1e-12>=.08:budget=0;reasons.append('回撤達8%，停止新倉')
 if dd+1e-12>=.10:reasons.append('回撤達10%，停止實盤並檢討')
 if not exposure_verified:budget=0;reasons.append('未核對現有持倉與相關貨幣曝險，禁止新構想')
 return dict(risk_budget_twd=budget,drawdown=dd,review_required=dd+1e-12>=.10,reasons=reasons,automatic_orders=False)
