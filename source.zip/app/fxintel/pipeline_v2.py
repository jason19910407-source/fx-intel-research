# coding: utf-8
"""資料管線修復版：官方公開來源、每日歷史K、逐來源新聞、部分事件日曆。無成交。"""
import datetime as dt,json,hashlib,math,re,time,subprocess,tempfile,urllib.parse
from pathlib import Path
from zoneinfo import ZoneInfo
from html.parser import HTMLParser
from . import core,marketdata as md,technical
VERSION='資料管線修復2.1';SOURCE='MarketHistory_fx_global_每日批次買價'
SCHEMA='''CREATE TABLE IF NOT EXISTS pipeline_state(k TEXT PRIMARY KEY,v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS official_calendar_versions(id TEXT PRIMARY KEY,event_key TEXT NOT NULL,source TEXT NOT NULL,known_at TEXT NOT NULL,body TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS official_calendar_known ON official_calendar_versions(event_key,known_at);'''
def init(c):md.init(c);c.executescript(SCHEMA)
def state(c,key):
 r=c.execute('SELECT v FROM pipeline_state WHERE k=?',(key,)).fetchone();return json.loads(r[0]) if r else None
def put(c,key,value):c.execute('INSERT OR REPLACE INTO pipeline_state VALUES(?,?)',(key,json.dumps(value,ensure_ascii=False)))
def get_free(url):
 u=urllib.parse.urlsplit(url)
 if u.scheme!='https' or u.netloc!='getmarkethistory.com' or not re.fullmatch('/api/v1/bars/fx/global/(EURUSD|USDJPY|GBPUSD|AUDUSD|USDCAD|USDCHF|EURJPY|GBPJPY)/1h',u.path):raise ValueError('只允許官方免金鑰小時線；拒絕付費路徑')
 with tempfile.TemporaryDirectory(prefix='fx-history-') as d:
  p=Path(d);r=subprocess.run(['curl','--silent','--show-error','--proto','=https','--max-time','20','--user-agent','FXResearchMonitor/2.1 personal research','--dump-header',str(p/'headers'),'--output',str(p/'body'),'--write-out','%{http_code}',url],capture_output=True)
  code=int(r.stdout or b'0');body=(p/'body').read_bytes() if (p/'body').exists() else b''
  if code!=200:raise RuntimeError('歷史來源HTTP '+str(code)+'，停止該來源，不繞過')
  if r.returncode or len(body)>8_000_000:raise RuntimeError('歷史來源傳輸或容量不合格')
  headers={x.split(':',1)[0].lower():x.split(':',1)[1].strip() for x in (p/'headers').read_text().splitlines() if ':' in x}
  if int(headers.get('x-bars-charged','0'))!=0:raise RuntimeError('拒絕非免費回應')
  return body,headers

def aggregate_open_hours(rows,tf,at,pair):
 groups={};at=md.stamp(at)
 for r in rows:
  if not md.market_open(md.stamp(r['opened_at'])):continue
  a,b=md.interval(r['opened_at'],tf);groups.setdefault((a,b),[]).append(r)
 out=[]
 for (a,b),rs in sorted(groups.items()):
  if b>at:continue
  expected=[];t=a
  while t<b:
   if md.market_open(t):expected.append(md.iso(t))
   t+=dt.timedelta(hours=1)
  unique={r['opened_at']:r for r in rs};got=[unique[k] for k in sorted(unique)];coverage=sum(bool(unique.get(k,{}).get('complete')) for k in expected)/len(expected) if expected else 0
  complete=set(unique)==set(expected) and coverage==1
  if not got:continue
  out.append(dict(source=SOURCE,pair=pair,timeframe=tf,opened_at=md.iso(a),closed_at=md.iso(b),known_at=max(r['known_at'] for r in got),open=got[0]['open'],high=max(r['high'] for r in got),low=min(r['low'] for r in got),close=got[-1]['close'],bid_close=got[-1]['close'],ask_close=None,coverage=coverage,complete=int(complete),quality_reason='按紐約開市時段核對原生小時線；休市不補價；未核實小時內逐筆完整性' if complete else '開市時段缺口或來源缺值，不補造'))
 return out

def ingest_hourly(c,pair,raw,received):
 init(c);at=md.stamp(received);rows=[];invalid=0
 for line in raw.splitlines():
  if not line.strip():continue
  d=json.loads(line);opened=md.stamp(d['timestamp']);closed=opened+dt.timedelta(hours=1)
  if d.get('symbol')!=pair or opened.minute or opened.second or not md.valid_ohlc(d):invalid+=1;continue
  if closed>at:continue
  complete=not d.get('is_gap',False) and d.get('gap_fill_method',0)==0
  rows.append(dict(source=SOURCE,pair=pair,timeframe='H1',opened_at=md.iso(opened),closed_at=md.iso(closed),known_at=md.iso(at),**{k:float(d[k]) for k in ['open','high','low','close']},bid_close=float(d['close']),ask_close=None,coverage=1 if complete else 0,complete=int(complete),quality_reason='來源原生買價小時線；每日批次發布，非即時；分鐘內完整性未核實'))
 if invalid or not rows or len({r['opened_at'] for r in rows})!=len(rows):raise ValueError('來源價格、貨幣對、時間或重複資料不合格')
 columns=['source','pair','timeframe','opened_at','closed_at','known_at','open','high','low','close','bid_close','ask_close','coverage','complete','quality_reason'];added=0
 for r in rows:
  prev=c.execute('SELECT open,high,low,close,complete FROM market_bars_v2 WHERE source=? AND pair=? AND timeframe=? AND opened_at=? ORDER BY known_at DESC LIMIT 1',(SOURCE,pair,'H1',r['opened_at'])).fetchone()
  if prev and tuple(prev)==tuple(r[k] for k in ['open','high','low','close','complete']):continue
  c.execute('INSERT OR IGNORE INTO market_bars_v2 VALUES('+','.join('?'*15)+')',tuple(r[k] for k in columns));added+=1
 hourly=source_rows(c,pair,'H1',at,5000)
 for tf in ['H4','D1']:
  for r in aggregate_open_hours(hourly,tf,at,pair):
   prev=c.execute('SELECT open,high,low,close,complete FROM market_bars_v2 WHERE source=? AND pair=? AND timeframe=? AND opened_at=? ORDER BY known_at DESC LIMIT 1',(SOURCE,pair,tf,r['opened_at'])).fetchone()
   if prev and tuple(prev)==tuple(r[k] for k in ['open','high','low','close','complete']):continue
   c.execute('INSERT OR IGNORE INTO market_bars_v2 VALUES('+','.join('?'*15)+')',tuple(r[k] for k in columns))
 return dict(pair=pair,received_at=md.iso(at),source_latest_close=max(r['closed_at'] for r in rows),received_hourly=len(rows),new_hourly_versions=added,source=SOURCE,frequency='每日批次；不是即時',bid_only=True,sha256=hashlib.sha256(raw).hexdigest())

def source_rows(c,pair,tf,at,limit=250):
 sql='''SELECT b.* FROM market_bars_v2 b WHERE b.source=? AND b.pair=? AND b.timeframe=? AND b.closed_at<=? AND b.known_at<=? AND NOT EXISTS(SELECT 1 FROM market_bars_v2 n WHERE n.source=b.source AND n.pair=b.pair AND n.timeframe=b.timeframe AND n.opened_at=b.opened_at AND n.known_at>b.known_at AND n.known_at<=?) ORDER BY b.closed_at DESC LIMIT ?'''
 rows=[dict(r) for r in c.execute(sql,(SOURCE,pair,tf,md.iso(at),md.iso(at),md.iso(at),limit))]
 return list(reversed(rows))

def update_bars(c,fetch=get_free,sleep=time.sleep):
 init(c);results=[];at=core.now()
 for pair in md.PAIRS:
  old=state(c,'mh:'+pair)
  if old and md.stamp(old['next_due'])>at:results.append(dict(old,pair=pair,status='每日批次快取未到期'));continue
  latest=c.execute('SELECT MAX(opened_at) FROM market_bars_v2 WHERE source=? AND pair=? AND timeframe=?',(SOURCE,pair,'H1')).fetchone()[0]
  start=(md.stamp(latest)-dt.timedelta(days=2)).date() if latest else (at-dt.timedelta(days=210)).date()
  url='https://getmarkethistory.com/api/v1/bars/fx/global/'+pair+'/1h?'+urllib.parse.urlencode(dict(start=start.isoformat(),end=at.date().isoformat(),limit=5000))
  try:
   raw,h=fetch(url)
   if h.get('x-next-cursor'):raise RuntimeError('免費分頁未完整，不截斷當作成功')
   received=core.now();r=ingest_hourly(c,pair,raw,received);r.update(status='已更新每日批次歷史K線',data_through=h.get('x-data-through'),next_due=core.iso(received+dt.timedelta(hours=6)))
  except Exception as e:r=dict(pair=pair,status='歷史更新失敗；不補造',detail=str(e)[:160],next_due=core.iso(core.now()+dt.timedelta(hours=24)))
  put(c,'mh:'+pair,r);c.commit();results.append(r);sleep(6.3)
 return results

def select_news(c,at):
 # 先逐來源排名，不以全球最近250筆切斷央行資料；每央行最多10，其餘每來源2。
 rows=[dict(r) for r in c.execute('''SELECT id,source_id,title,title_zh,link,published_at,first_seen_at,observed_at,topic,currencies,payload FROM (SELECT *,ROW_NUMBER() OVER(PARTITION BY source_id ORDER BY (published_at IS NULL),published_at DESC,first_seen_at DESC,id) rn FROM items WHERE source_id NOT IN ('bls_calendar','ons_calendar','census_calendar') AND first_seen_at<=? AND observed_at<=? AND (published_at IS NULL OR published_at<=?)) WHERE rn<=CASE WHEN source_id IN ('fed','ecb','boe','boj') THEN 10 ELSE 2 END ORDER BY CASE WHEN source_id IN ('fed','ecb','boe','boj') THEN 0 ELSE 1 END,source_id,rn LIMIT 128''',(md.iso(at),md.iso(at),md.iso(at)))]
 return rows

def calendar_item(c,item,known):
 init(c);p=json.loads(item['payload']);event_time=p.get('event_time')
 if not event_time:return
 md.stamp(event_time);key=item['source_id']+'|'+item['source_key'];body=dict(event_key=key,source_id=item['source_id'],title=item['title'],event_time=event_time,source_url=item['link'],currencies=json.loads(item['currencies']),source_publication_at=p.get('source_publication_at'),first_available_to_system=known,observed_at=known,time_definition=p.get('time_definition'),schedule_status=p.get('schedule_status','scheduled'),expected_value=None,expected_status='官方日程未提供市場共識預期值',actual_value=None,actual_status='日程介面不提供可配對實際數值；未補造',actual_first_available_at=None)
 latest=c.execute('SELECT body FROM official_calendar_versions WHERE event_key=? ORDER BY known_at DESC LIMIT 1',(key,)).fetchone()
 if latest:
  old=json.loads(latest[0]);body['first_available_to_system']=old['first_available_to_system']
  if all(old.get(k)==body.get(k) for k in body if k not in ['observed_at']):return
 text=json.dumps(body,ensure_ascii=False,sort_keys=True);ident=hashlib.sha256(text.encode()).hexdigest();c.execute('INSERT OR IGNORE INTO official_calendar_versions VALUES(?,?,?,?,?)',(ident,key,item['source_id'],known,text))

def calendar_snapshot(c,at):
 init(c);rows=c.execute('''SELECT e.body FROM official_calendar_versions e WHERE known_at<=? AND NOT EXISTS(SELECT 1 FROM official_calendar_versions n WHERE n.event_key=e.event_key AND n.known_at>e.known_at AND n.known_at<=?) ORDER BY json_extract(e.body,'$.event_time')''',(md.iso(at),md.iso(at)))
 events=[json.loads(r[0]) for r in rows];events=[e for e in events if md.stamp(at)-dt.timedelta(days=7)<=md.stamp(e['event_time'])<=md.stamp(at)+dt.timedelta(days=30)]
 return dict(status='官方日程部分可用；非完整八貨幣事件覆蓋',events=events[:40],known_event_count=len(events),snapshot_event_count=min(40,len(events)),snapshot_omitted=max(0,len(events)-40),snapshot_note='前向快照保存時間排序前40件；完整日程版本保存在私人資料庫，不以截斷代表完整覆蓋',coverage_verified=False,missing=['全貨幣重大事件完整覆蓋','市場共識預期值','與發布日程精確配對的實際值及首次發布版本'],source_states=[dict(r) for r in c.execute("SELECT source_id,status,checked_at,last_success,detail FROM source_state WHERE source_id IN ('ons_calendar','census_calendar','bls_calendar')")])

def bar_clock(closed,tf,at):
 """只增加市場時鐘診斷；不改固定策略的原有新鮮度准入標準。"""
 at=md.stamp(at);closed=md.stamp(closed);cursor=min(closed,at);active=0
 while cursor<at:
  end=min(cursor.replace(minute=0,second=0,microsecond=0)+dt.timedelta(hours=1),at)
  if md.market_open(cursor):active+=(end-cursor).total_seconds()
  cursor=end
 expected=None;h=at.replace(minute=0,second=0,microsecond=0)
 for i in range(24*8):
  a=h-dt.timedelta(hours=i+1);_,end=md.interval(a,tf)
  if md.market_open(a) and end<=at:expected=max(expected,end) if expected else end
 current=expected is not None and closed>=expected
 return dict(market_open=md.market_open(at),wall_age_seconds=(at-closed).total_seconds(),open_market_age_seconds=active,latest_expected_closed_at=md.iso(expected) if expected else None,latest_expected_bar_present=current,status='休市，已持有最後應閉合K線；不是資料故障' if not md.market_open(at) and current else '缺少應已閉合K線；每日批次來源仍可能延遲' if not current else '已持有最新應閉合K線',source_is_intraday=False,eligibility_note='市場時鐘診斷與原鎖定策略准入分開；不藉週末放寬門檻',session_note='採紐約週日17時至週五17時的一般現貨外匯週期；交易商分鐘差異及特殊假日未核實')

def snapshot(c,at):
 init(c);result=[]
 for pair,name in md.PAIRS.items():
  tech={};charts={};quality={}
  for tf in ['D1','H4','H1']:
   rows=source_rows(c,pair,tf,at,250)
   if tf=='H1':rows=[r for r in rows if md.market_open(md.stamp(r['opened_at']))]
   t=technical.indicators(rows,at)
   if rows:
    t['last_bar_closed_at']=rows[-1]['closed_at'];t['age_seconds']=(md.stamp(at)-md.stamp(rows[-1]['closed_at'])).total_seconds()
    clock=bar_clock(rows[-1]['closed_at'],tf,at);t['market_clock']={k:clock[k] for k in ['market_open','open_market_age_seconds','latest_expected_closed_at','latest_expected_bar_present']}
    if t['age_seconds']>md.TF_SECONDS[tf]*2:t['valid']=False;t.setdefault('reasons',[]).append('原時效未通過')
   t['data_source']=SOURCE;t['update_frequency']='來源每日批次；不能冒充即時';tech[tf]=t;charts[tf]=[{k:r[k] for k in ['opened_at','closed_at','open','high','low','close','complete','coverage']} for r in rows[-60:]];quality[tf]=dict(loaded_bars=len(rows),valid=t['valid'],latest_close=rows[-1]['closed_at'] if rows else None)
  news=dict(direction='資料不足',score=None,reason='新聞方向使用修復版前向策略的原固定政策事實規則，不從日程或一般標題猜測')
  result.append(dict(pair=pair,name=name,quote=None,quote_quality=md.quote_status(None,at),technical=tech,news_macro=news,combined=technical.integrate(tech,news),charts=charts,qualified=False,decision='研究資料檢查；無成交資格',blocking_reasons=['尚無已授權有效買賣價','尚未通過交易策略驗證'],entry=None,stop=None,target=None,invalidation='資料失效或條件不符即觀望',bar_quality=quality,bar_update_state=state(c,'mh:'+pair)))
 return dict(version=VERSION,as_of=md.iso(at),pairs=result,risk=__import__('fxintel.research_v2',fromlist=['RISK']).RISK,automatic_orders=False,calendar=calendar_snapshot(c,at),market_time_note='日線採紐約17時；4小時及1小時UTC；來源每日批次買價，不是即時報價；休市不填價')

class Tables(HTMLParser):
 def __init__(self):super().__init__();self.rows=[];self.row=None;self.cell=None
 def handle_starttag(self,tag,attrs):
  if tag=='tr':self.row=[]
  if tag in ['td','th'] and self.row is not None:self.cell=[]
 def handle_data(self,data):
  if self.cell is not None:self.cell.append(data)
 def handle_endtag(self,tag):
  if tag in ['td','th'] and self.cell is not None:
   self.row.append(re.sub(r'\s+',' ',' '.join(self.cell)).strip());self.cell=None
  if tag=='tr' and self.row is not None:self.rows.append(self.row);self.row=None

def parse_calendar(s,raw):
 from .collect import item
 out=[]
 if s['parser']=='ons_calendar':
  data=json.loads(raw)
  if data.get('breakdown',{}).get('total',len(data.get('releases',[])))>len(data.get('releases',[])):raise ValueError('ONS日程尚有未取頁，不能宣稱完整擷取')
  for x in data.get('releases',[]):
   d=x.get('description',{});when=d.get('release_date')
   if not when:continue
   try:event_time=md.iso(md.stamp(when))
   except (ValueError,TypeError):continue
   url='https://www.ons.gov.uk'+x['uri'];out.append(item(s,x['uri'],d['title'],url,payload=dict(event_time=event_time,source_publication_at=None,schedule_status='cancelled' if d.get('cancelled') else 'provisional' if d.get('provisional_date') or not d.get('finalised') else 'scheduled',time_definition='ONS官方release_date含UTC偏移；排程時間不是實際發布時刻')))
 elif s['parser']=='census_calendar':
  text=raw.decode('utf-8','replace')
  if 'Eastern' not in text:raise ValueError('官方日程時區定義缺失，不推定')
  tables=re.findall(r'<table\b[^>]*>.*?</table>',text,re.S|re.I)
  table=next((t for t in tables if 'Statistical Month' in t and 'Data Release' in t),None)
  if not table:raise ValueError('找不到官方FT900日程表，不混用其他發布表')
  parser=Tables();parser.feed(table)
  for cells in parser.rows:
   if len(cells)<3:continue
   try:d=dt.datetime.strptime(cells[1].strip(),'%B %d, %Y')
   except ValueError:continue
   title='美國國際商品與服務貿易｜統計期'+cells[0]
   when=dt.datetime(d.year,d.month,d.day,8,30,tzinfo=ZoneInfo('America/New_York'))
   out.append(item(s,cells[0],title,s['endpoint'],payload=dict(event_time=md.iso(when),source_publication_at=None,schedule_status='scheduled',time_definition='官方FT900日程明定8:30 Eastern，依America/New_York轉UTC')))
 else:raise ValueError('未核准事件解析器')
 return out,[]
