# coding: utf-8
"""固定參數、只採完整閉合K；趨勢、動能各自分組，避免相似指標反覆加分。"""
import math,statistics
from .marketdata import stamp,market_open,valid_ohlc
PARAMETERS=dict(ma_fast=20,ma_slow=60,rsi=14,macd=[12,26,9],atr=14,support_resistance=20,minimum_bars=100)
VALIDATION='尚未通過交易策略驗證'
def ema_series(xs,n):
 out=[];v=xs[0]
 for x in xs:v=x*2/(n+1)+v*(1-2/(n+1));out.append(v)
 return out

def indicators(rows,at):
 at=stamp(at);reasons=[]
 if len(rows)<100:return dict(valid=False,reasons=['至少需要100根歷史閉合K線'],validation=VALIDATION)
 if any(not valid_ohlc(r) or not r.get('complete') or stamp(r['known_at'])>at or stamp(r['closed_at'])>at for r in rows):reasons.append('歷史K線不完整或尚未可知')
 # 不跨缺漏計算指標；週末可跳過，交易商假日未知則仍視為缺漏。
 for p,r in zip(rows,rows[1:]):
  a,b=stamp(p['closed_at']),stamp(r['opened_at'])
  if a>b:reasons.append('K線重疊或排序錯誤');break
  if a<b:
   t=a
   import datetime as dt
   while t<b:
    if market_open(t):reasons.append('指標回看區間有開市時段缺漏');break
    t+=dt.timedelta(hours=1)
   if reasons:break
 if reasons:return dict(valid=False,reasons=sorted(set(reasons)),validation=VALIDATION)
 close=[r['close'] for r in rows];last=close[-1];ma20=statistics.mean(close[-20:]);ma60=statistics.mean(close[-60:])
 delta=[b-a for a,b in zip(close,close[1:])];gain=sum(max(x,0) for x in delta[:14])/14;loss=sum(max(-x,0) for x in delta[:14])/14
 for x in delta[14:]:gain=(gain*13+max(x,0))/14;loss=(loss*13+max(-x,0))/14
 rsi=100-100/(1+gain/loss) if loss else 100 if gain else 50
 e12,e26=ema_series(close,12),ema_series(close,26);macd=[a-b for a,b in zip(e12,e26)];sig=ema_series(macd,9);hist=macd[-1]-sig[-1]
 tr=[max(r['high']-r['low'],abs(r['high']-p['close']),abs(r['low']-p['close'])) for p,r in zip(rows,rows[1:])];atr=sum(tr[:14])/14
 for x in tr[14:]:atr=(atr*13+x)/14
 # 支撐壓力只取當前K之前20根，當前突破不污染門檻。
 support=min(r['low'] for r in rows[-21:-1]);resistance=max(r['high'] for r in rows[-21:-1]);r,p=rows[-1],rows[-2]
 trend=1 if last>ma20>ma60 else -1 if last<ma20<ma60 else 0
 momentum=1 if 50<rsi<75 and hist>0 else -1 if 25<rsi<50 and hist<0 else 0
 # RSI與MACD共同決定一個動能組，不各加一次趨勢分。
 direction='偏多' if trend==momentum==1 else '偏空' if trend==momentum==-1 else '觀望'
 setup='突破確認' if (last>resistance and r['open']<=resistance) or (last<support and r['open']>=support) else '回檔確認' if (trend==1 and r['low']<=ma20<last and last>p['high']) or (trend==-1 and r['high']>=ma20>last and last<p['low']) else '反轉待確認' if (r['low']<p['low'] and last>p['high']) or (r['high']>p['high'] and last<p['low']) else '尚無確認型態'
 score=50+(20 if trend==momentum and trend else 0)+(10 if setup in ['突破確認','回檔確認'] else 0)
 return dict(valid=True,ma20=ma20,ma60=ma60,rsi14=rsi,macd=macd[-1],macd_signal=sig[-1],macd_histogram=hist,atr14=atr,support=support,resistance=resistance,direction=direction,setup=setup,score=score,as_of=rows[-1]['closed_at'],parameters=PARAMETERS,validation=VALIDATION)

def integrate(technical,news):
 valid=all(technical.get(tf,{}).get('valid') for tf in ['D1','H4','H1'])
 directions=[technical.get(tf,{}).get('direction') for tf in ['D1','H4','H1']]
 td=directions[0] if valid and len(set(directions))==1 and directions[0]!='觀望' else '觀望'
 nd=news.get('direction','資料不足');conflict=td in ['偏多','偏空'] and nd in ['偏多','偏空'] and td!=nd
 # 新聞無可查證方向不假定中性，不生成整合數字；分數不是勝率。
 ns=news.get('score');ts=min(technical[tf]['score'] for tf in technical) if valid else None
 score=round(.6*ts+.4*ns) if ts is not None and ns is not None else None
 if conflict:score=min(score,69) if score is not None else None
 return dict(technical_direction=td,news_direction=nd,agreement='衝突，觀望' if conflict else '方向一致' if td==nd and td!='觀望' else '尚未形成一致方向',technical_score=ts,news_score=ns,score=score,direction='觀望' if conflict or td!=nd else td,validation=VALIDATION,score_note='一致性分數，不是勝率；缺少新聞方向評估時不補分')
