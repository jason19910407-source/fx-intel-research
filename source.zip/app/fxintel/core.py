# -*- coding: utf-8 -*-
import datetime as dt,hashlib,json,sqlite3,math,re,os,uuid
from pathlib import Path
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[1]
UTC=dt.timezone.utc
PAIRS={'EURUSD':('EUR/USD（歐元兌美元）',.0001),'USDJPY':('USD/JPY（美元兌日圓）',.01),'GBPUSD':('GBP/USD（英鎊兌美元）',.0001)}
STRATEGY_APPROVED=False # 前輪未通過；設定檔或模型輸出均不能解除。
def now():return dt.datetime.now(UTC)
def iso(x=None):return (x or now()).astimezone(UTC).isoformat()
def parse_time(x):
 if not x:return None
 try:
  v=dt.datetime.fromisoformat(str(x).replace('Z','+00:00'))
  return v.astimezone(UTC) if v.tzinfo else None
 except (TypeError,ValueError):return None
def digest(x):return hashlib.sha256(x.encode()).hexdigest()
def write_json(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+'.tmp.'+uuid.uuid4().hex)
 try:tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2));os.replace(tmp,path)
 finally:
  if tmp.exists():tmp.unlink()
def sources():return json.loads((ROOT/'sources.json').read_text())
def config():return json.loads((ROOT/'config.json').read_text())
def connect(path=None):
 p=Path(path) if path else ROOT/'data/intelligence.sqlite3';p.parent.mkdir(parents=True,exist_ok=True)
 c=sqlite3.connect(p,timeout=20);c.row_factory=sqlite3.Row;c.execute('PRAGMA journal_mode=WAL');c.execute('PRAGMA foreign_keys=ON')
 c.executescript('''
 CREATE TABLE IF NOT EXISTS source_state(source_id TEXT PRIMARY KEY,status TEXT NOT NULL,detail TEXT,checked_at TEXT,last_success TEXT,etag TEXT,modified TEXT,next_due TEXT,failures INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS fetches(id INTEGER PRIMARY KEY,source_id TEXT,observed_at TEXT,url TEXT,http_status INTEGER,sha256 TEXT,bytes INTEGER,records INTEGER,status TEXT,detail TEXT);
 CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY,source_id TEXT,source_key TEXT,title TEXT,title_zh TEXT,link TEXT,published_at TEXT,first_seen_at TEXT,observed_at TEXT,topic TEXT,currencies TEXT,payload TEXT,UNIQUE(source_id,source_key,payload));
 CREATE TABLE IF NOT EXISTS reference_rates(id TEXT PRIMARY KEY,source_id TEXT,pair TEXT,reference_date TEXT,value REAL,first_seen_at TEXT,observed_at TEXT,kind TEXT);
 CREATE TABLE IF NOT EXISTS quotes(id INTEGER PRIMARY KEY,source_id TEXT,pair TEXT,bid REAL,ask REAL,quote_time TEXT,received_at TEXT,practice INTEGER);
 CREATE TABLE IF NOT EXISTS alerts(id TEXT PRIMARY KEY,created_at TEXT,kind TEXT,title TEXT,body TEXT,evidence TEXT,acknowledged INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS account_entries(id INTEGER PRIMARY KEY,observed_at TEXT,equity_twd REAL,notes TEXT);
 CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY,created_at TEXT,pair TEXT,decision TEXT,note TEXT);
 CREATE TABLE IF NOT EXISTS notification_receipts(id INTEGER PRIMARY KEY,alert_id TEXT,channel TEXT,stage TEXT,received_at TEXT,UNIQUE(alert_id,channel,stage));
 CREATE TABLE IF NOT EXISTS cycles(id INTEGER PRIMARY KEY,started_at TEXT,ended_at TEXT,usable_sources INTEGER,status TEXT);
 CREATE TABLE IF NOT EXISTS calendar(id TEXT PRIMARY KEY,source_id TEXT,title TEXT,event_time TEXT,observed_at TEXT,currencies TEXT);
 ''');return c

def alert(c,key,kind,title,body,evidence=None):
 c.execute('INSERT OR IGNORE INTO alerts(id,created_at,kind,title,body,evidence) VALUES(?,?,?,?,?,?)',(digest(key),iso(),kind,title,body,json.dumps(evidence or {},ensure_ascii=False)))
def account(c):
 rows=c.execute('SELECT * FROM account_entries ORDER BY id').fetchall();cap=float(config()['capital_twd']);eq=float(rows[-1]['equity_twd']) if rows else cap;peak=max([cap]+[float(r['equity_twd']) for r in rows]);dd=max(0,1-eq/peak)
 historical_peak=cap;max_dd=0
 for r in rows:
  historical_peak=max(historical_peak,float(r['equity_twd']));max_dd=max(max_dd,1-float(r['equity_twd'])/historical_peak)
 return dict(initial_twd=cap,equity_twd=eq,peak_twd=peak,drawdown_fraction=dd,max_drawdown_fraction=max_dd,warning=max_dd>=config()['max_drawdown']-1e-12,observation='人工淨值紀錄；未連接交易帳戶',last_updated=rows[-1]['observed_at'] if rows else None)
def add_equity(c,value,note):
 value=float(value)
 if not math.isfinite(value) or value<0 or value>10000000:raise ValueError('淨值必須為0至1,000萬元的有限值；僅紀錄損益淨值，不接受追加資金。')
 c.execute('INSERT INTO account_entries(observed_at,equity_twd,notes) VALUES(?,?,?)',(iso(),value,str(note)[:500]));a=account(c)
 if a['warning']:alert(c,'account-dd-'+str(round(a['peak_twd'],2)),'risk','帳戶回撤已達5%警戒','暫停新增交易構想；本系統不會替你平倉，請人工檢查所有既有部位。',a)
 c.commit();return a

def classify(title,currency_hint):
 t=title.lower();topics=[('利率與政策',['interest','monetary','fomc','policy','rate decision','利率','金融政策']),('通膨',['inflation','consumer price','cpi','hicp','物価']),('就業',['employment','payroll','labour','labor','unemployment']),('經濟成長',['gross domestic','gdp','growth','production']),('外匯與干預',['exchange','foreign currency','intervention','外国為替'])]
 topic=next((a for a,words in topics if any(w in t for w in words)),'一般官方公告')
 return topic,currency_hint

def sessions(at=None):
 at=at or now();labels=[]
 for zone,start,end,label in [('Asia/Tokyo',9,18,'亞洲主要時段'),('Europe/London',8,17,'歐洲主要時段'),('America/New_York',8,17,'美國主要時段')]:
  local=at.astimezone(ZoneInfo(zone))
  if local.weekday()<5 and start<=local.hour<end:labels.append(label)
 return dict(active=labels or ['主要時段外／週末；不等同交易商保證開市'],overlap=len(labels)>1,utc=iso(at),taipei=at.astimezone(ZoneInfo('Asia/Taipei')).isoformat(),note='地區夏令時間自動轉換；假日與交易商臨時休市尚未完全核實')

def market_open(at):
 n=at.astimezone(ZoneInfo('America/New_York'));wd=n.weekday()
 return not(wd==5 or (wd==6 and n.hour<17) or (wd==4 and n.hour>=17))

def risk_scenario(c,payload,at=None):
 at=at or now();pair=payload.get('pair','EURUSD')
 if pair not in PAIRS:raise ValueError('僅支援三組研究貨幣對')
 direction=payload.get('direction','多')
 if direction not in ['多','空']:raise ValueError('方向必須為多或空')
 def positive(k):
  v=float(payload[k])
  if not math.isfinite(v) or v<=0:raise ValueError('價格及換算匯率必須為有限正數')
  return v
 entry,stop,target,conv=[positive(k) for k in ['entry','stop','target','usd_twd']]
 if not ((stop<entry<target) if direction=='多' else (target<entry<stop)):raise ValueError('停損、進場及目標價的方向不一致')
 risk=float(payload.get('risk_fraction',.005))
 if not math.isfinite(risk) or not .005<=risk<=.01:raise ValueError('風險比例限0.5%至1%')
 a=account(c);budget=min(a['equity_twd'],a['initial_twd'])*risk
 pip=PAIRS[pair][1];dist=abs(entry-stop)
 # 僅情境估計：歷史研究參考，並非已核實交易商報價。
 spread=float(payload.get('spread_pips',2));slip=float(payload.get('slippage_pips',.2));lev=float(payload.get('leverage',20))
 if not all(math.isfinite(x) for x in [spread,slip,lev]) or not 0<=spread<=50 or not .2<=slip<=100 or not 1<=lev<=20:raise ValueError('點差、滑價或槓桿超出研究限制')
 quote_to_usd=1/stop if pair=='USDJPY' else 1
 unit_notional=1 if pair=='USDJPY' else entry
 costs_unit=(spread+2*slip)*pip*quote_to_usd+2*35/1_000_000*unit_notional
 loss_unit=dist*quote_to_usd+costs_unit
 qty=math.floor(budget/conv/loss_unit/1000)*1000
 margin_usd=qty*unit_notional/lev
 reasons=['前輪策略未通過實盤驗證；本版只提供觀察與風險情境','未核實臺灣適用交易商、逐日成本及強平規則','經濟事件行事曆涵蓋未完整驗證','停損遇跳空可能超過預算，模型不能保證精準成交']
 q=c.execute('SELECT * FROM quotes WHERE pair=? ORDER BY id DESC LIMIT 1',(pair,)).fetchone()
 if not q:reasons.append('沒有已驗證即時買價與賣價；每日參考價不能替代')
 else:
  qt=parse_time(q['quote_time']);age=(at-qt).total_seconds() if qt else float('inf')
  if age<0 or age>config()['quote_max_age_seconds']:reasons.append('即時買賣價已過期或時間異常')
  if q['practice']:reasons.append('僅模擬帳戶報價，未驗證真實帳戶成交條件')
 if not market_open(at):reasons.append('主要外匯市場週末休市時段')
 if a['warning']:reasons.append('人工帳戶淨值已達5%回撤警戒')
 if qty<1000:reasons.append('最小1,000單位已超出風險預算')
 if margin_usd*conv>a['equity_twd']:reasons.append('估算可用資金不足原始保證金')
 if costs_unit/loss_unit>config()['max_total_cost_fraction_of_risk']:reasons.append('估算成本占風險預算比重過高')
 return dict(pair=PAIRS[pair][0],decision='暫不具備交易條件',can_trade=False,automatic_orders=False,reasons=reasons,risk_budget_twd=round(budget,2),hypothetical_units=qty,estimated_stop_loss_twd=round(qty*loss_unit*conv,2),estimated_roundtrip_cost_twd=round(qty*costs_unit*conv,2),estimated_margin_twd=round(margin_usd*conv,2),estimated_margin_buffer_twd=round(a['equity_twd']-margin_usd*conv,2),gross_reward_risk=round(abs(target-entry)/dist,3),assumptions='人工輸入價格與USD/TWD；最小1,000單位，20倍以下槓桿，往返佣金每邊35美元／百萬美元名目本金，至少每邊0.2pip（最小報價變動單位）滑價；不是交易建議或真實報價。',at=iso(at))

def snapshot(c):
 states={r['source_id']:dict(r) for r in c.execute('SELECT * FROM source_state')};reg=[]
 for s in sources():reg.append(dict(s,state=states.get(s['id'],dict(status='尚未擷取' if s['enabled'] else '未啟用',detail=s['access_limit']))))
 rates=[dict(r) for r in c.execute('SELECT r.* FROM reference_rates r JOIN (SELECT pair,MAX(reference_date) d FROM reference_rates GROUP BY pair) n ON r.pair=n.pair AND r.reference_date=n.d ORDER BY r.pair')]
 for r in rates:r['age_days']=(now().date()-dt.date.fromisoformat(r['reference_date'])).days
 items=[dict(r) for r in c.execute("SELECT id,source_id,title_zh,title,link,published_at,first_seen_at,observed_at,topic,currencies,payload FROM items WHERE source_id NOT IN ('bls_calendar','ons_calendar','census_calendar') AND (published_at IS NULL OR published_at<=?) ORDER BY CASE WHEN source_id IN ('nasa','usgs','noaa') THEN 1 ELSE 0 END,(published_at IS NULL),published_at DESC,first_seen_at DESC LIMIT 250",(iso(),))]
 seen_counts={};diverse=[]
 for x in items:
  n=seen_counts.get(x['source_id'],0)
  if n>=3:continue
  seen_counts[x['source_id']]=n+1
  try:
   p=json.loads(x['payload'])
   if x['source_id']=='bls':x['title_zh']='美國消費者物價指數｜'+p['year']+'年'+p['period'][1:]+'月：'+p['value']+'（指數值）'
   elif x['source_id']=='cftc':x['title_zh']='主要貨幣期貨部位｜統計日：'+str(p.get('report_date_as_yyyy_mm_dd','未提供'))[:10]+'（非即時部位）'
   elif x['source_id']=='treasury':x['title_zh']='美國財政部報告換算匯率｜參考日：'+p['record_date']+'（非交易價）'
  except (ValueError,TypeError,KeyError):pass
  diverse.append(x)
 items=diverse[:80]
 upcoming=[dict(r) for r in c.execute('SELECT id,source_id,title_zh,link,published_at,first_seen_at FROM items WHERE published_at>? ORDER BY published_at LIMIT 20',(iso(),))]
 audit_path=ROOT/'reports/來源逐一查核.json'
 audits={x['id']:x for x in json.loads(audit_path.read_text())} if audit_path.exists() else {}
 for source in reg:
  detail=source['state'].get('detail','')
  if detail and not re.search('[\u4e00-\u9fff]',detail):source['state']['detail']='資料格式或連線驗證失敗；詳本機原始稽核紀錄'
  proof=audits.get(source['id'],{});source['documentation_check']=proof.get('documentation_check',{});source['policy_check']=proof.get('policy_check',{})
 alerts=[dict(r) for r in c.execute('SELECT * FROM alerts ORDER BY created_at DESC LIMIT 50')]
 return dict(generated_at=iso(),mode='只讀情報／人工決策研究',hosted_snapshot=False,automatic_orders=False,strategy_approved=STRATEGY_APPROVED,model=config()['model'],account=account(c),sessions=sessions(),sources=reg,rates=rates,items=items,upcoming=upcoming,alerts=alerts,health=dict(configured_sources=len(reg),enabled_sources=sum(s['enabled'] for s in reg),parsed_sources=sum(s['state']['status']=='成功解析' for s in reg),records=c.execute('SELECT count(*) FROM items').fetchone()[0],quote_records=c.execute('SELECT count(*) FROM quotes').fetchone()[0]),limitation='目前無通過實盤驗證策略；每日參考匯率不是即時可成交買賣價。')
