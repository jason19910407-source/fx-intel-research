# -*- coding: utf-8 -*-
import datetime as dt,json,re,time,urllib.request,urllib.error,urllib.parse,urllib.robotparser,xml.etree.ElementTree as ET,email.utils,concurrent.futures
import ssl
try:
 import certifi
 SSL_CONTEXT=ssl.create_default_context(cafile=certifi.where())
except ImportError:
 SSL_CONTEXT=ssl.create_default_context()
from .core import ROOT,UTC,now,iso,parse_time,digest,connect,sources,classify,alert
MAX_BYTES=8_000_000
UA='FXResearchMonitor/1.0 (personal noncommercial research; public feeds only)'
def localname(x):return x.rsplit('}',1)[-1]
def clean(x):return re.sub(r'\s+',' ',re.sub('<[^>]+>','',x or '')).strip()
def stamp(x):
 if not x:return None
 try:
  d=email.utils.parsedate_to_datetime(x)
  return iso(d) if d.tzinfo else None
 except Exception:
  p=parse_time(x)
  if p:return iso(p)
  if re.fullmatch(r'\d{4}-\d{2}-\d{2}',str(x)):return None # 只有日期，不補造午夜發布時刻。
 return None

def item(s,key,title,link=None,published=None,payload=None):
 topic,ccy=classify(title,s['currencies']);p=json.dumps(payload or {},ensure_ascii=False,sort_keys=True)
 return dict(id=digest(s['id']+'|'+str(key)+'|'+p+'|'+title),source_id=s['id'],source_key=str(key),title=title[:1000],title_zh=s['name']+'：'+topic+'資料更新（請核對原文）',link=link or s['documentation'],published_at=stamp(published),topic=topic,currencies=json.dumps(ccy),payload=p)

def rss(s,b):
 root=ET.fromstring(b);out=[]
 for e in root.iter():
  if localname(e.tag) not in ['item','entry']:continue
  d={localname(c.tag):c for c in e};title=clean(''.join(d['title'].itertext())) if 'title' in d else ''
  if not title:continue
  link=d.get('link');url=(link.attrib.get('href') or link.text or '') if link is not None else ''
  pub=next((d[k].text for k in ['pubDate','published','date'] if k in d),None)
  # updated只代表修改，不可冒充首次發布；缺原發布時間就保留空值。
  key=next((d[k].text for k in ['guid','id'] if k in d),None) or url or title
  out.append(item(s,key,title,url,pub,{'source_publication_raw':pub,'publication_precision':'日期' if pub and re.fullmatch(r'\d{4}-\d{2}-\d{2}',pub) else '依來源時間戳，非本機實測發布時刻'}))
 return out,[]

def parse(s,b):
 kind=s['parser']
 if kind in ['ons_calendar','census_calendar']:
  from .pipeline_v2 import parse_calendar
  return parse_calendar(s,b)
 if kind=='rss':
  if b'<!DOCTYPE' in b.upper() or b'<!ENTITY' in b.upper():raise ValueError('拒絕XML外部宣告或回傳HTML頁面')
  return rss(s,b)
 if kind=='ecb':
  root=ET.fromstring(b);rates=[]
  for cube in root.iter():
   date=cube.attrib.get('time')
   if not date:continue
   vals={x.attrib.get('currency'):float(x.attrib['rate']) for x in cube if x.attrib.get('rate')}
   if not all(x in vals for x in ['USD','JPY','GBP']):continue
   pairs={'EURUSD':vals['USD'],'USDJPY':vals['JPY']/vals['USD'],'GBPUSD':vals['USD']/vals['GBP']}
   for p,v in pairs.items():
    if not 0<v<10000:raise ValueError('參考匯率數值無效')
    rates.append(dict(id=digest(s['id']+p+date+str(v)),source_id=s['id'],pair=p,reference_date=date,value=v,kind='每日官方參考價，非即時買賣價'))
  if not rates:raise ValueError('未找到三組匯率')
  latest=max(x['reference_date'] for x in rates)
  return [item(s,latest,'歐洲央行每日參考匯率',published=None,payload={'reference_date':latest,'用途':'研究背景，不可用於交易成交判定'})],rates
 if kind=='bot':
  import csv,io
  text=b.decode('utf-8-sig','replace');rows=list(csv.reader(io.StringIO(text)))
  if len(rows)<2:raise ValueError('臺銀CSV沒有牌告資料')
  out=[]
  for row in rows[1:]:
   if any(code in str(row[0]) for code in ['USD','JPY','EUR','GBP']):out.append(item(s,row[0]+'|'+str(row),'臺銀牌告匯率資料',payload={'columns':rows[0],'values':row,'用途':'人工換算背景，非交易商即時價格'}))
  if not out:raise ValueError('臺銀CSV未找到研究幣別，可能格式改變')
  return out,[]
 if kind=='ics':
  text=re.sub(r'\r?\n[ \t]','',b.decode('utf-8-sig'));out=[]
  for event in text.split('BEGIN:VEVENT')[1:]:
   title=re.search(r'^SUMMARY:(.*)$',event,re.M);date=re.search(r'^DTSTART([^:]*):(.*)$',event,re.M);uid=re.search(r'^UID:(.*)$',event,re.M)
   if not title or not date:continue
   raw=date.group(2).strip();tz=re.search(r'TZID=([^;:]+)',date.group(1))
   try:
    if raw.endswith('Z'):v=dt.datetime.strptime(raw,'%Y%m%dT%H%M%SZ').replace(tzinfo=UTC)
    elif tz:
     from zoneinfo import ZoneInfo
     v=dt.datetime.strptime(raw,'%Y%m%dT%H%M%S').replace(tzinfo=ZoneInfo(tz.group(1)))
    else:continue # 全日或無明確時區，不補造發布時間。
   except ValueError:continue
   out.append(item(s,uid.group(1).strip() if uid else raw,title.group(1).strip(),payload={'event_time':iso(v),'time_confirmed':True}))
  return out,[]
 d=json.loads(b)
 if kind=='bls':
  if d.get('status')!='REQUEST_SUCCEEDED':raise ValueError('BLS未成功回傳統計：'+str(d.get('message')))
  rows=d['Results']['series'][0]['data']
  out=[item(s,x['year']+x['period'],'美國消費者物價指數',payload=x) for x in rows if x['period']!='M13'];return out,[]
 if kind=='treasury':return [item(s,x['record_date']+x['country_currency_desc'],'美國財政部報告換算匯率',payload=x) for x in d['data']],[]
 if kind=='eurostat':
  if not d.get('value'):raise ValueError('Eurostat沒有實際觀察值')
  return [item(s,d.get('updated','unknown'),'歐元區調和消費者物價年增率',payload={'updated':d.get('updated'),'label':d.get('label'),'dimension':d.get('dimension'),'value':d['value']})],[]
 if kind=='ons':
  # 目錄中繼資料，與真實數值資料來源分開計數。
  return [item(s,x.get('id',x.get('title','')),'英國官方統計資料集目錄',payload=x) for x in d.get('items',[])],[]
 if kind=='cftc':
  if not isinstance(d,list):raise ValueError('CFTC資料不是列資料')
  return [item(s,str(x.get('report_date_as_yyyy_mm_dd'))+str(x.get('cftc_contract_market_code')),'主要貨幣期貨部位報告',payload=x) for x in d],[]
 if kind=='worldbank':
  if not isinstance(d,list) or len(d)<2:raise ValueError('世界銀行沒有觀察資料')
  return [item(s,str(x['country']['id'])+x['date'],'世界銀行經濟指標',payload=x) for x in d[1] if x.get('value') is not None],[]
 if kind=='govuk':return [item(s,x.get('link',str(x)),x.get('title','英國政府公告'),'https://www.gov.uk'+x['link'],x.get('public_timestamp'),x) for x in d.get('results',[])],[]
 if kind=='noaa':return [item(s,x.get('product_id','')+x.get('issue_datetime',''),'太空天氣警戒',payload=x) for x in d],[]
 if kind=='usgs':return [item(s,x['id'],'地震與潛在供應鏈風險',x['properties'].get('url'),iso(dt.datetime.fromtimestamp(x['properties']['time']/1000,UTC)),x['properties']) for x in d['features']],[]
 if kind=='eonet':return [item(s,x['id'],'開放自然災害事件',x.get('link'),payload=x) for x in d['events']],[]
 raise ValueError('尚未實作資料解析器；不視為可用來源')

def allowed_endpoint(s,url):
 if not s.get('enabled') or not s.get('endpoint') or url!=s['endpoint']:raise ValueError('來源未核准或非固定公開讀取端點')
 u=urllib.parse.urlsplit(url)
 if u.scheme!='https' or not u.hostname or u.username or u.password:raise ValueError('僅允許固定HTTPS公開來源')
 if any(x in u.path.lower() for x in ['/orders','/trades','/positions']):raise ValueError('禁止交易路由')
 return True

def fetch_one(s,at=None):
 at=at or now();c=connect();prev=c.execute('SELECT * FROM source_state WHERE source_id=?',(s['id'],)).fetchone();prev=dict(prev) if prev else {}
 previous_url=c.execute('SELECT url FROM fetches WHERE source_id=? ORDER BY id DESC LIMIT 1',(s['id'],)).fetchone()
 if previous_url and previous_url[0]!=s['endpoint']:prev={} # 正式核准的來源變更不可沿用另一資源的快取驗證器。
 due=parse_time(prev.get('next_due'))
 if due and at<due:c.close();return {'source':s['id'],'status':'快取未到期','records':0}
 url=s['endpoint'];status='連線失敗';detail='';code=None;b=b'';records=0;rates=[];items=[];headers={};is_block=False
 try:
  allowed_endpoint(s,url)
  h={'User-Agent':UA,'Accept':'application/xml,application/rss+xml,application/json,text/xml,*/*'}
  if prev.get('etag'):h['If-None-Match']=prev['etag']
  if prev.get('modified'):h['If-Modified-Since']=prev['modified']
  # 公開訂閱僅讀取訂閱端點，不擷取新聞全文。
  req=urllib.request.Request(url,headers=h,method='GET')
  with urllib.request.urlopen(req,timeout=20,context=SSL_CONTEXT) as r:
   code=r.status;headers=dict(r.headers);b=r.read(MAX_BYTES+1)
   if len(b)>MAX_BYTES:raise ValueError('資料超過大小限制，未截斷當成功')
   if not r.url.startswith('https://'):raise ValueError('拒絕不安全重新導向')
   items,rates=parse(s,b)
   if not items and not rates:raise ValueError('空資料或格式變動，不視為成功')
   records=len(items)+len(rates);status='成功解析';detail='真實資料已解析；未確認為即時交易價'
 except urllib.error.HTTPError as e:
  code=e.code
  if code==304:
   if prev.get('last_success'):status='成功解析';detail='來源回覆未修改，保留前次已解析資料'
   else:status='格式失敗';detail='無前次有效快取卻回304'
  elif code==429:status='限流暫停';detail='HTTP 429，停止重試並延後至少24小時';is_block=True
  else:status='存取受限' if code in [401,403] else '連線失敗';detail='HTTP '+str(code)+'；未繞過限制'
 except Exception as e:detail=str(e)[:200];status='格式或連線失敗'
 checked=iso(now());last=checked if status=='成功解析' else prev.get('last_success');failures=0 if status=='成功解析' else int(prev.get('failures',0))+1
 delay=max(s['poll_seconds'],86400 if is_block else min(86400,1800*2**min(failures,5)) if failures else 0)
 due=iso(parse_time(checked)+dt.timedelta(seconds=delay))
 if status=='成功解析' and s['poll_seconds']==1800:
  end=parse_time(checked);due=iso(dt.datetime.fromtimestamp((int(end.timestamp())//1800+1)*1800,UTC)) # 對齊半小時時槽，不因下載數秒延誤而每隔一輪跳過。
 with c:
  for x in items:
   c.execute('INSERT OR IGNORE INTO items(id,source_id,source_key,title,title_zh,link,published_at,first_seen_at,observed_at,topic,currencies,payload) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(x['id'],x['source_id'],x['source_key'],x['title'],x['title_zh'],x['link'],x['published_at'],checked,checked,x['topic'],x['currencies'],x['payload']))
   c.execute('UPDATE items SET observed_at=? WHERE id=?',(checked,x['id']))
   if s['parser'] in ['ics','ons_calendar','census_calendar']:
    from .pipeline_v2 import calendar_item
    calendar_item(c,x,checked)
    payload=json.loads(x['payload']);c.execute('INSERT OR REPLACE INTO calendar VALUES(?,?,?,?,?,?)',(x['id'],s['id'],x['title'],payload['event_time'],checked,x['currencies']))
  for x in rates:
   c.execute('INSERT OR IGNORE INTO reference_rates(id,source_id,pair,reference_date,value,first_seen_at,observed_at,kind) VALUES(?,?,?,?,?,?,?,?)',(x['id'],s['id'],x['pair'],x['reference_date'],x['value'],checked,checked,x['kind']))
   c.execute('UPDATE reference_rates SET observed_at=? WHERE id=?',(checked,x['id']))
  if b:
   p=ROOT/'data/raw'/s['id'];p.mkdir(parents=True,exist_ok=True);(p/(digest(b.decode('utf-8','replace'))+'.bin')).write_bytes(b)
  c.execute('INSERT INTO fetches(source_id,observed_at,url,http_status,sha256,bytes,records,status,detail) VALUES(?,?,?,?,?,?,?,?,?)',(s['id'],checked,url,code,__import__('hashlib').sha256(b).hexdigest() if b else None,len(b),records,status,detail))
  c.execute('INSERT OR REPLACE INTO source_state(source_id,status,detail,checked_at,last_success,etag,modified,next_due,failures) VALUES(?,?,?,?,?,?,?,?,?)',(s['id'],status,detail,checked,last,headers.get('ETag',prev.get('etag')),headers.get('Last-Modified',prev.get('modified')),due,failures))
  if prev.get('status') and (prev['status']=='成功解析')!=(status=='成功解析'):alert(c,s['id']+checked,'source','資料來源狀態改變',s['name']+'：'+status,{'source_id':s['id'],'detail':detail})
 c.close();return {'source':s['id'],'status':status,'records':records,'detail':detail}

def collect():
 ss=[s for s in sources() if s['enabled'] and s.get('endpoint')]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:result=list(pool.map(fetch_one,ss))
 p=ROOT/'reports/最近資料擷取.json';p.write_text(json.dumps({'at':iso(),'results':result},ensure_ascii=False,indent=2));return result
