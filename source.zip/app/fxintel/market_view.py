# coding: utf-8
"""只讀八組市場資料快照；行情不足時明確禁止可執行構想。"""
from .marketdata import PAIRS,init,latest_bars,quote_status,iso,stamp,TF_SECONDS
from .technical import indicators,integrate,VALIDATION
from .research_v2 import RISK,REPORT_HOURS

def snapshot(c,at):
 init(c);result=[]
 for pair,name in PAIRS.items():
  q=c.execute('SELECT * FROM market_quotes_v2 WHERE pair=? AND received_at<=? ORDER BY received_at DESC LIMIT 1',(pair,iso(at))).fetchone()
  q=dict(q) if q else None;quality=quote_status(q,at)
  tech={};charts={}
  for tf in ['D1','H4','H1']:
   rows=latest_bars(c,pair,tf,at,250);charts[tf]=[{k:r[k] for k in ['opened_at','closed_at','open','high','low','close','complete','coverage']} for r in rows[-80:]]
   tech[tf]=indicators(rows,at)
   if rows:
    tech[tf]['last_bar_closed_at']=rows[-1]['closed_at'];age=(stamp(at)-stamp(rows[-1]['closed_at'])).total_seconds();tech[tf]['age_seconds']=age
    if age>TF_SECONDS[tf]*2:
     tech[tf]['valid']=False;tech[tf].setdefault('reasons',[]).append('最近閉合K線已過期')
  news=dict(direction='資料不足',score=None,reason='已蒐集官方新聞；未驗證預期差與政策方向，不以標題硬判多空')
  combined=integrate(tech,news)
  reasons=quality['reasons']+[VALIDATION]
  if not all(t.get('valid') for t in tech.values()):reasons.append('多週期歷史資料不足或存在缺漏')
  result.append(dict(pair=pair,name=name,quote=q,quote_quality=quality,technical=tech,news_macro=news,combined=combined,charts=charts,qualified=False,decision='觀望／資料不足',blocking_reasons=reasons,entry=None,stop=None,target=None,invalidation='有效行情、完整閉合K線或風控任一失效即撤銷構想'))
 return dict(version='2.0分階段研究版',as_of=iso(at),pairs=result,risk=RISK,report_hours_taipei=list(REPORT_HOURS),report_status='正式報告尚未啟用；每日五個時槽，不包含04:00',validation=VALIDATION,automatic_orders=False,market_time_note='H1（1小時線）與H4（4小時線）採UTC（世界協調時間）對齊；D1（日線）採紐約17:00結算，隨夏令時間調整。')
