# coding: utf-8
"""第二版資料契約：不填補缺價，不將擷取時間當作報價時間。僅處理已授權輸入。"""
import datetime as dt, math, sqlite3
from zoneinfo import ZoneInfo
UTC=dt.timezone.utc
PAIRS={'EURUSD':'歐元／美元','USDJPY':'美元／日圓','GBPUSD':'英鎊／美元','AUDUSD':'澳幣／美元','USDCAD':'美元／加幣','USDCHF':'美元／瑞郎','EURJPY':'歐元／日圓','GBPJPY':'英鎊／日圓'}
TF_SECONDS={'H1':3600,'H4':14400,'D1':86400}
SCHEMA='''
CREATE TABLE IF NOT EXISTS market_bars_v2(source TEXT NOT NULL,pair TEXT NOT NULL,timeframe TEXT NOT NULL,opened_at TEXT NOT NULL,closed_at TEXT NOT NULL,known_at TEXT NOT NULL,open REAL NOT NULL,high REAL NOT NULL,low REAL NOT NULL,close REAL NOT NULL,bid_close REAL,ask_close REAL,coverage REAL NOT NULL,complete INTEGER NOT NULL,quality_reason TEXT NOT NULL,PRIMARY KEY(source,pair,timeframe,opened_at,known_at));
CREATE INDEX IF NOT EXISTS market_bars_lookup_v2 ON market_bars_v2(pair,timeframe,closed_at);
CREATE TABLE IF NOT EXISTS market_quotes_v2(source TEXT NOT NULL,pair TEXT NOT NULL,received_at TEXT NOT NULL,quote_time TEXT,bid REAL,ask REAL,kind TEXT NOT NULL,timezone_verified INTEGER NOT NULL,license_verified INTEGER NOT NULL,PRIMARY KEY(source,pair,received_at));
CREATE TABLE IF NOT EXISTS market_ingestions_v2(id TEXT PRIMARY KEY,source TEXT NOT NULL,observed_at TEXT NOT NULL,status TEXT NOT NULL,detail TEXT NOT NULL,sha256 TEXT);
'''
def init(c):c.executescript(SCHEMA)
def stamp(value):
 if isinstance(value,str):value=dt.datetime.fromisoformat(value.replace('Z','+00:00'))
 if value.tzinfo is None:raise ValueError('時間必須附時區')
 return value.astimezone(UTC)
def iso(value):return stamp(value).isoformat()
def market_open(at):
 n=stamp(at).astimezone(ZoneInfo('America/New_York'))
 return n.weekday()!=5 and not(n.weekday()==6 and n.hour<17) and not(n.weekday()==4 and n.hour>=17)
def interval(start,tf):
 """日線採紐約17時結算、夏令時間隨當地變化；H1/H4依UTC對齊。"""
 t=stamp(start)
 if tf=='D1':
  n=t.astimezone(ZoneInfo('America/New_York'));d=n.date() if n.hour>=17 else n.date()-dt.timedelta(days=1)
  a=dt.datetime.combine(d,dt.time(17),ZoneInfo('America/New_York'));b=dt.datetime.combine(d+dt.timedelta(days=1),dt.time(17),ZoneInfo('America/New_York'))
  return a.astimezone(UTC),b.astimezone(UTC)
 secs=TF_SECONDS[tf];a=dt.datetime.fromtimestamp(int(t.timestamp())//secs*secs,UTC)
 return a,a+dt.timedelta(seconds=secs)
def valid_ohlc(row):
 try:o,h,l,c=[float(row[k]) for k in ['open','high','low','close']]
 except (KeyError,ValueError,TypeError):return False
 return all(math.isfinite(x) and x>0 for x in [o,h,l,c]) and l<=min(o,c)<=max(o,c)<=h

def aggregate(rows,tf,at,source,pair):
 """輸入完整H1或5分鐘K；要求連續覆蓋全部開市區段，遺漏不補。"""
 at=stamp(at);groups={};seen=set()
 for r in sorted(rows,key=lambda x:stamp(x['opened_at'])):
  a,b=stamp(r['opened_at']),stamp(r['closed_at']);known=stamp(r['known_at'])
  if (a,b) in seen:raise ValueError('輸入含重複時段；先明確選擇當時已知修訂版')
  seen.add((a,b))
  if b<=a or known<b or not valid_ohlc(r):raise ValueError('來源價格或時間無效')
  if b>at or known>at:continue
  start,end=interval(a,tf)
  if b>end:raise ValueError('來源K線跨越目標週期邊界')
  groups.setdefault((start,end),[]).append(r)
 out=[]
 for (a,b),rs in sorted(groups.items()):
  if b>at:continue
  expected=int((b-a).total_seconds());covered=0;cursor=a;complete=True
  for r in rs:
   x,y=stamp(r['opened_at']),stamp(r['closed_at'])
   if x!=cursor:complete=False
   cursor=y;covered+=(y-x).total_seconds()*float(r.get('coverage',1));complete=complete and bool(r.get('complete',False))
  complete=complete and cursor==b and covered==expected
  if not any(market_open(a+dt.timedelta(seconds=i)) for i in range(0,expected,3600)):continue
  last=rs[-1]
  out.append(dict(source=source,pair=pair,timeframe=tf,opened_at=iso(a),closed_at=iso(b),known_at=iso(max(stamp(r['known_at']) for r in rs)),open=rs[0]['open'],high=max(r['high'] for r in rs),low=min(r['low'] for r in rs),close=last['close'],bid_close=last.get('bid_close'),ask_close=last.get('ask_close'),coverage=min(1,covered/expected),complete=int(complete),quality_reason='完整閉合K線' if complete else '缺少來源時段或分鐘覆蓋；不補價'))
 return out

def quote_status(q,at,max_age=120):
 at=stamp(at);reasons=[]
 if not q:return dict(valid=False,kind='資料不足',age_seconds=None,market_open=market_open(at),reasons=['沒有已核實行情來源'])
 try:
  b,a=float(q['bid']),float(q['ask'])
  if not math.isfinite(b+a) or not 0<b<=a:reasons.append('買賣價格無效')
 except (ValueError,TypeError,KeyError):reasons.append('缺少買價或賣價')
 try:qt=stamp(q['quote_time']) if q.get('quote_time') else None
 except (TypeError,ValueError):qt=None
 try:
  if stamp(q['received_at'])>at:reasons.append('接收時間在未來')
 except (KeyError,TypeError,ValueError):reasons.append('缺少有效接收時間')
 age=(at-qt).total_seconds() if qt else None
 if age is None or age<0 or age>max_age:reasons.append('來源報價時間未核實、未來或過期')
 if not q.get('timezone_verified'):reasons.append('來源日期及時區未核實')
 if not q.get('license_verified'):reasons.append('使用授權未核實')
 if q.get('kind') not in ['即時指示買賣價','延遲指示買賣價']:reasons.append('不是可核對時間的買賣價')
 if not market_open(at):reasons.append('週末主要市場休市；假日仍須另核對')
 return dict(valid=not reasons,kind=q.get('kind','資料不足'),age_seconds=age,market_open=market_open(at),reasons=reasons)

def latest_bars(c,pair,tf,at,limit=250):
 # 只選分析當下已知版本；修訂日期不可反向套用於歷史訊號。
 q='''SELECT b.* FROM market_bars_v2 b WHERE pair=? AND timeframe=? AND closed_at<=? AND known_at<=? AND NOT EXISTS(SELECT 1 FROM market_bars_v2 n WHERE n.source=b.source AND n.pair=b.pair AND n.timeframe=b.timeframe AND n.opened_at=b.opened_at AND n.known_at>b.known_at AND n.known_at<=?) ORDER BY closed_at DESC LIMIT ?'''
 cursor=c.execute(q,(pair,tf,iso(at),iso(at),iso(at),limit));names=[x[0] for x in cursor.description];rows=[dict(zip(names,r)) for r in cursor]
 return list(reversed(rows))
