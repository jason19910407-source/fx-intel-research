# -*- coding: utf-8 -*-
import datetime as dt,json,math,statistics
from .core import *

def ema(values,n):
 a=2/(n+1);v=values[0]
 for x in values[1:]:v=a*x+(1-a)*v
 return v

def research_score(rows,at):
 # 事先固定的可解釋一致性分數，不是經統計校準的勝率或獲利機率。
 if len(rows)<60:return dict(score=None,direction='資料不足',components=[],reason='需至少60個不同日期的官方參考價')
 vals=[r['value'] for r in rows];last=rows[-1];age=(at.date()-dt.date.fromisoformat(last['reference_date'])).days
 if any(not math.isfinite(x) or x<=0 for x in vals) or age<0 or age>4:return dict(score=None,direction='資料品質不合格',components=[],reason='參考價非正數、未來日期或超過4曆日')
 e20,e60=ema(vals,20),ema(vals,60);direction='偏多觀察' if e20>e60 else '偏空觀察' if e20<e60 else '無方向'
 trend=1 if e20>e60 else -1;mom=vals[-1]/vals[-6]-1;returns=[vals[i]/vals[i-1]-1 for i in range(len(vals)-20,len(vals))];vol=statistics.pstdev(returns)
 parts=[('均線趨勢與收盤方向一致',30 if (vals[-1]-e20)*trend>0 else 0,30),('近五日動能與趨勢一致',25 if mom*trend>0 else 0,25),('波動未超過過去20日中位絕對變動三倍',15 if abs(returns[-1])<=3*max(statistics.median(map(abs,returns)),.00001) else 0,15),('至少60個不同日期有效觀察',15,15),('參考價在三曆日內',15 if age<=3 else 0,15)]
 return dict(score=sum(x[1] for x in parts),direction=direction,components=[dict(rule=n,points=v,max_points=m) for n,v,m in parts],reference_date=last['reference_date'],frequency='每日官方參考價；非分鐘級進場訊號',ema20=e20,ema60=e60,momentum5=mom,volatility20=vol,calibrated=False,reason='研究一致性分數，沒有勝率校準；本輪策略未獲實盤通過')

def evaluate_gate(score,conditions):
 reasons=[label for key,label in [('quote_fresh','即時買賣價不存在或過期'),('cost_verified','交易商真實成本及保證金規則未核實'),('calendar_complete','事件日曆涵蓋未完整核實'),('account_fresh','人工帳戶淨值不是今日已更新'),('drawdown_ok','帳戶回撤達5%警戒'),('sources_ok','可用來源未滿30個或來源健康過期'),('market_open','主要市場休市')] if not conditions.get(key,False)]
 if not STRATEGY_APPROVED:reasons.insert(0,'前輪樣本外研究未通過實盤資格')
 if score is None or score<70:reasons.append('研究信心分數未達70或無法計算')
 # 下單完全不存在；通過仍只能建立人工閱讀的通知。
 return dict(passed=not reasons,reasons=reasons,automatic_orders=False)

def analyze(c,at=None):
 at=at or now();a=account(c);reg=sources();states={r['source_id']:dict(r) for r in c.execute('SELECT * FROM source_state')};active=[]
 for s in reg:
  r=states.get(s['id'],{});last=parse_time(r.get('last_success'))
  if s.get('count_as_source',True) and s['parser']!='ons' and r.get('status')=='成功解析' and last and 0<=(at-last).total_seconds()<=max(s['poll_seconds']*3,86400):active.append(s['id'])
 output=[]
 for pair in PAIRS:
  rows=[dict(r) for r in c.execute('SELECT * FROM reference_rates WHERE pair=? AND first_seen_at<=? ORDER BY reference_date,first_seen_at',(pair,iso(at)))];unique={r['reference_date']:r for r in rows if r['reference_date']<=at.date().isoformat()};rows=[unique[k] for k in sorted(unique)];score=research_score(rows,at)
  latest=c.execute('SELECT * FROM quotes WHERE pair=? ORDER BY id DESC LIMIT 1',(pair,)).fetchone();fresh=False
  if latest:
   qt=parse_time(latest['quote_time']);fresh=bool(qt and 0<=(at-qt).total_seconds()<=60 and not latest['practice'] and latest['ask']>=latest['bid']>0)
  account_time=parse_time(a['last_updated']);conditions=dict(quote_fresh=fresh,cost_verified=False,calendar_complete=False,account_fresh=bool(account_time and (at-account_time).total_seconds()<86400),drawdown_ok=not a['warning'],sources_ok=len(active)>=30,market_open=market_open(at))
  gate=evaluate_gate(score['score'],conditions);result=dict(pair=pair,name=PAIRS[pair][0],research_confidence=score,gate=gate,decision='僅觀察；暫不具備交易條件' if not gate['passed'] else '可供人工複核；不代表應下單',evidence_source='ECB（歐洲中央銀行）每日參考價',last_reference=rows[-1] if rows else None,history=[dict(date=r['reference_date'],value=r['value']) for r in rows]);output.append(result)
  if gate['passed']:alert(c,'review-'+pair+'-'+str(rows[-1]['reference_date']),'review',PAIRS[pair][0]+'人工複核通知','研究分數達70且資料風控通過，仍需人工決定；系統無下單功能。',result)
 # 已發布訊息：只處理有來源發布時戳、最近30分鐘內、已知且非未來的官方公告；不將舊資料灌成即時新聞。
 for x in c.execute('SELECT * FROM items WHERE published_at IS NOT NULL ORDER BY published_at DESC LIMIT 300'):
  pub=parse_time(x['published_at']);seen=parse_time(x['first_seen_at'])
  if pub and seen and pub<=at and seen<=at and 0<=(at-pub).total_seconds()<=1800 and x['topic'] in ['利率與政策','通膨','就業']:
   alert(c,'news-'+x['id'],'event',x['title_zh'],'公告已發布，請核對原文。已重新檢查觀察方向；不能由標題推斷超預期或保證價格反應。',{'source_id':x['source_id'],'url':x['link'],'published_at':x['published_at'],'currencies':json.loads(x['currencies'])})
 for ev in c.execute('SELECT * FROM calendar'):
  stamp=parse_time(ev['event_time']);seen=parse_time(ev['observed_at'])
  if stamp and seen and seen<=at and 0<=(stamp-at).total_seconds()<=3600:alert(c,'calendar-'+ev['id'],'event','已排程官方數據發布風險','未來一小時有官方數據發布；暫停新增交易構想並注意跳空。',dict(ev))
 out=dict(analyzed_at=iso(at),next_analysis_at=iso(at+dt.timedelta(minutes=30)),usable_source_count=len(active),usable_source_ids=active,minimum_sources_met=len(active)>=30,results=output,scoring_note='研究信心為固定規則一致性0–100分，不是經驗證勝率；分數達70仍必須全部閘門通過。',news_note='每30分鐘輪詢會有最多一個週期以上的偵測延遲，不能保證預知或搶在突發新聞前。',model_mode='可解釋規則引擎；未啟用外部語言模型，不宣稱已執行大型語言模型推論')
 schedule=ROOT/'data/scheduler.json'
 if schedule.exists():
  try:out['next_analysis_at']=json.loads(schedule.read_text())['next_due_at']
  except (ValueError,KeyError):pass
 c.commit();write_json(ROOT/'reports/最新分析.json',out);return out
