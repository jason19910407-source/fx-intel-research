# coding: utf-8
"""固定14天前向資料與訊號帳本。成交模擬關閉；無交易帳戶或下單介面。"""
import datetime as dt,hashlib,json,re
from zoneinfo import ZoneInfo
from .marketdata import PAIRS,stamp,iso,market_open
ID='forward-20261107-20261121-v1';TAIPEI=ZoneInfo('Asia/Taipei')
CONFIG={'id':ID,'version':1,'timezone':'Asia/Taipei','start':'2026-11-07T00:00:00+08:00','end_exclusive':'2026-11-21T00:00:00+08:00','pairs':list(PAIRS),'initial_capital_twd':35000,'risk_initial_twd':525,'risk_fraction_initial':.015,'aggregate_risk_cap_twd':700,'max_drawdown':.10,'reduce_risk_at':.05,'stop_new_at':.08,'reward_risk':2,'holding_cap_hours':72,'score_threshold':70,'execution_enabled':False,'execution_reason':'最新買賣價持續擷取及保存授權、交易級歷史K線與成本尚未驗收；僅前向訊號帳本，不模擬成交','A':'純技術：D1、H4、H1皆有效且方向一致；取三週期最低技術分數，至少70；H1須有突破或回檔確認。缺資料不補分。','B':'純新聞事件方向：僅本次測試啟用後新取得、發布與取得時間均已可知的央行官方公告；明確已完成升息/降息，排除預期、提問、維持與模糊標題。事件方向50分、6小時內時效20分（24小時內10）、第二個一致官方事件20、兩個不同官方來源10；上限100。政策方向是假說，不是勝率，不以標題猜預期差。','C':'整合：A與B方向相同且兩者各至少70，分數為各50%平均；衝突或缺資料即觀望。','news_max_age_hours':24,'max_archived_items':66,'maximum_items_per_source':2,'archive_selection':'最近250筆中每來源最多2筆；記錄未保存數量及截斷標示，非完整網路新聞語料','no_retroactive_news':True,'common_execution':'三組共用同一行情與成本資格；B若未來有行情，止損波幅僅作共同風險定量，不參與B方向評分。未核實買賣價、可成交成本、TWD換算、最小數量時，進場/停損/停利皆空。','correlation':'每組獨立本金；同組每筆風險525、總風險700，因此正常風險下至多一筆。減半時不得同時持有共同貨幣同向曝險。跨A/B/C另列研究相關性，不把三組資金當作同一帳戶。','expiry_minutes':30,'retain_days_after_end':180,'immutable':'規則雜湊鎖定；每半小時觀察與三組八對判斷只插入，不更新或刪除；未通過及資料不足同樣保留。','test_status':'尚未通過交易策略驗證'}
ENCODED=json.dumps(CONFIG,ensure_ascii=False,sort_keys=True,separators=(',',':'));RULE_HASH=hashlib.sha256(ENCODED.encode()).hexdigest()
SQL={
 'experiment':'SELECT * FROM forward_experiments WHERE id=?',
 'existing':'SELECT id,body FROM forward_observations WHERE experiment=? AND slot=?',
 'last':'SELECT id,body_hash FROM forward_observations WHERE experiment=? ORDER BY recorded_at DESC,id DESC LIMIT 1',
 'insert':'INSERT OR IGNORE INTO forward_observations(id,experiment,slot,day_taipei,analyzed_at,recorded_at,previous_hash,body_hash,news_count,a_candidates,b_candidates,c_candidates,body) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
 'day':'SELECT id,slot,analyzed_at,news_count,a_candidates,b_candidates,c_candidates FROM forward_observations WHERE experiment=? AND day_taipei=? ORDER BY slot',
 'all':'SELECT day_taipei,COUNT(*) observations,SUM(news_count) news_observations,SUM(a_candidates) a_candidates,SUM(b_candidates) b_candidates,SUM(c_candidates) c_candidates FROM forward_observations WHERE experiment=? GROUP BY day_taipei ORDER BY day_taipei',
 'report_insert':'INSERT OR IGNORE INTO forward_reports(id,experiment,day_taipei,kind,created_at,body) VALUES(?,?,?,?,?,?)',
 'report_existing':'SELECT body FROM forward_reports WHERE id=?'
}
def digest(v):return hashlib.sha256(v.encode()).hexdigest()
def encoded(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def common_risk(equity,peak,positions,direction_exposure):
 if equity<0 or peak<=0:return dict(passed=False,reason='淨值無效',budget_twd=0)
 dd=max(0,1-equity/peak);budget=525*(.5 if dd>=.05-1e-12 else 1);used=sum(p['risk_twd'] for p in positions)
 conflict=any(any(currency in p.get('exposure',{}) and p['exposure'][currency]==side for currency,side in direction_exposure.items()) for p in positions)
 ok=dd<.08-1e-12 and used+budget<=700+1e-9 and not conflict
 return dict(passed=ok,budget_twd=budget if ok else 0,total_risk_twd=used,max_total_twd=700,drawdown=dd,stop_at_ten=dd>=.10-1e-12,correlation_conflict=conflict,reason='通過理論風險檢查' if ok else '回撤、總風險或共同貨幣方向風險不合格')
def exposure(pair,side):return {pair[:3]:side,pair[3:]:-side}
def facts(items,at,activated):
 result=[];official={'fed':'USD','ecb':'EUR','boe':'GBP','boj':'JPY'}
 for x in items:
  if x.get('source_id') not in official:continue
  try:pub,first,observed=map(stamp,[x.get('published_at'),x.get('first_seen_at'),x.get('observed_at')])
  except (ValueError,TypeError,AttributeError):continue
  if not(activated<=first<=observed<=at and pub<=observed and 0<=(at-pub).total_seconds()<=86400):continue
  # 無法分辨只有日期的午夜時間時採保守拒絕，避免擅造發布分鐘。
  if pub.hour==pub.minute==pub.second==0:continue
  title=(x.get('title') or '').lower()
  if re.search(r'expected|expects|forecast|may |might |could |will |would |preview|預期|預估|可能|將會|是否',title):continue
  up=bool(re.search(r'(raises?|increases?|hikes?)\b.{0,45}\b(rate|rates)\b|升息|提高.{0,8}利率',title));down=bool(re.search(r'(cuts?|lowers?|reduces?)\b.{0,45}\b(rate|rates)\b|降息|調降.{0,8}利率',title))
  if up==down:continue
  result.append(dict(id=x['id'],source_id=x['source_id'],currency=official[x['source_id']],direction=1 if up else -1,published_at=iso(pub),first_seen_at=iso(first),age_seconds=(at-pub).total_seconds(),url=x.get('link'),method='固定明確政策動作標題規則；未猜預期差'))
 return result

def decision(strategy,pair,market,news,at,calendar):
 tech=market.get('technical',{});td=[tech.get(tf,{}) for tf in ['D1','H4','H1']];valid=all(t.get('valid') for t in td);dirs=[t.get('direction') for t in td]
 adir=dirs[0] if valid and len(set(dirs))==1 and dirs[0] in ['偏多','偏空'] else None
 ascore=min(t.get('score',0) for t in td) if valid else None
 if valid and tech['H1'].get('setup') not in ['突破確認','回檔確認']:adir=None
 relevant=[]
 for event in news:
  if event['currency'] not in [pair[:3],pair[3:]]:continue
  side=event['direction']*(1 if event['currency']==pair[:3] else -1);relevant.append(dict(event,side=side))
 sides={x['side'] for x in relevant};bdir=('偏多' if next(iter(sides))==1 else '偏空') if len(sides)==1 else None
 bscore=None
 if bdir:
  fresh=min(x['age_seconds'] for x in relevant);bscore=min(100,50+(20 if fresh<=21600 else 10)+(20 if len({x['id'] for x in relevant})>=2 else 0)+(10 if len({x['source_id'] for x in relevant})>=2 else 0))
 score,direction=(ascore,adir) if strategy=='A' else (bscore,bdir) if strategy=='B' else ((ascore+bscore)/2,adir) if ascore is not None and bscore is not None and adir==bdir and adir else (None,None)
 if strategy=='C' and (ascore is None or bscore is None or min(ascore,bscore)<70):direction=None
 candidate=direction is not None and score is not None and score>=70
 reasons=[]
 if not market_open(at):reasons.append('週末主要市場休市，不建立模擬交易')
 if not market.get('quote_quality',{}).get('valid'):reasons.append('缺乏已授權且時間有效的買賣價')
 if not valid:reasons.append('閉合多週期技術資料不足或過期')
 if not calendar:reasons.append('重大事件行事曆涵蓋未完整驗證')
 reasons.append(CONFIG['execution_reason'])
 if not candidate:reasons.insert(0,'方向、資料或固定評分未達研究候選條件')
 side=1 if direction=='偏多' else -1 if direction=='偏空' else 0
 return dict(strategy=strategy,pair=pair,score=score,direction=direction or '觀望',status='研究候選／不可成交' if candidate else '資料不足' if score is None else '觀望',candidate=candidate,executable=False,entry=None,entry_range=None,stop=None,target=None,reward_risk_target=2,cost=None,cost_status='未核實，不以0代替',risk_budget_twd=525,expiry_at=iso(at+dt.timedelta(minutes=30)),invalidation='任何資料失效、方向衝突、重大事件否決或超過有效期即失效；只新增後續評估，不改寫原訊號',news_evidence=[x['id'] for x in relevant],currency_exposure=exposure(pair,side) if side else {},blocking_reasons=reasons,validation='研究訊號，非已驗證交易策略')

def daily(store,day,at,kind='daily_snapshot',slot=''):
 rows=store.query(SQL['day'],(ID,day));body=dict(day_taipei=day,kind=kind,as_of=iso(at),observations=len(rows),news_observation_count=sum(r['news_count'] for r in rows),strategies={s:dict(initial_capital_twd=35000,candidate_observations=sum(r[k] for r in rows),executed_trades=0,win_rate=None,average_win_loss_ratio=None,net_expectancy=None,total_pnl_twd=None,max_drawdown=None,unfinished_trades=0,status='只記錄訊號；成交、損益與回撤未啟用，不代表策略零損益') for s,k in [('A','a_candidates'),('B','b_candidates'),('C','c_candidates')]},coverage_note='觀察筆數不是獨立機會或成交數；同一方向可能在多個時槽重複出現',execution_enabled=False)
 rid=ID+':'+kind+':'+day+(':'+slot if kind=='daily_snapshot' else '')
 store.query(SQL['report_insert'],(rid,ID,day,kind,iso(at),encoded(body)));return body

def record(store,c,payload,runid,at):
 at=stamp(at);registered=store.query(SQL['experiment'],(ID,))
 if not registered:return dict(status='尚未啟用前向測試',execution_enabled=False)
 ex=registered[0]
 if ex['rules_hash']!=RULE_HASH or ex['body']!=ENCODED:raise RuntimeError('前向固定規則不一致，拒絕覆寫')
 start,end,activated=stamp(CONFIG['start']),stamp(CONFIG['end_exclusive']),stamp(ex['activated_at'])
 if at<max(start,activated):return dict(status='尚未到實際啟用時刻，不倒填',execution_enabled=False)
 day=at.astimezone(TAIPEI).date().isoformat();previous=(at.astimezone(TAIPEI).date()-dt.timedelta(days=1)).isoformat()
 if previous>=start.astimezone(TAIPEI).date().isoformat() and previous<end.astimezone(TAIPEI).date().isoformat():daily(store,previous,at,'daily_final')
 if at>=end:
  if not store.query(SQL['report_existing'],(ID+':final',)):
   result=dict(status='14天觀察區間結束',generated_at=iso(at),planned_start=CONFIG['start'],actual_activation=ex['activated_at'],end_exclusive=CONFIG['end_exclusive'],days=store.query(SQL['all'],(ID,)),execution_enabled=False,conclusion='行情與成本資格未啟用，因此只有前向訊號紀錄，沒有已完成交易回測；不能宣稱策略驗證成功')
   store.query(SQL['report_insert'],(ID+':final',ID,'','final',iso(at),encoded(result)))
  return dict(status='區間已結束，完整訊號比較報告已封存；非交易回測',execution_enabled=False)
 slot=iso(at.replace(minute=at.minute//30*30,second=0,microsecond=0));existing=store.query(SQL['existing'],(ID,slot))
 if existing:return dict(status='同一時槽已封存，不重複或覆寫',id=existing[0]['id'],execution_enabled=False)
 items=[dict(r) for r in c.execute('SELECT id,source_id,title,title_zh,link,published_at,first_seen_at,observed_at,topic,currencies,payload FROM items WHERE observed_at<=? ORDER BY observed_at DESC,id LIMIT 250',(iso(at),))]
 total_available=len(items);selected=[];seen_sources={}
 for item in items:
  source=item['source_id']
  if seen_sources.get(source,0)>=2:continue
  seen_sources[source]=seen_sources.get(source,0)+1;selected.append(item)
 items=selected[:66]
 # 保留原始輸入欄位及摘要；不保留整篇第三方文章。超長欄位明確標示截斷。
 for x in items:
  for key,limit in [('payload',600),('title',300),('title_zh',300),('link',900)]:
   v=x.get(key)
   if isinstance(v,str) and len(v)>limit:x[key]=v[:limit];x[key+'_truncated']=True
 known=facts(items,at,activated)
 cal=[dict(r) for r in c.execute('SELECT * FROM calendar WHERE observed_at<=? ORDER BY event_time LIMIT 50',(iso(at),))]
 market=payload.get('market_v2',{});pairs={p['pair']:p for p in market.get('pairs',[])};decisions=[decision(s,pair,pairs.get(pair,{}),known,at,False) for s in ['A','B','C'] for pair in PAIRS]
 overlaps=[]
 for i,left in enumerate(decisions):
  for right in decisions[i+1:]:
   if left['strategy']!=right['strategy'] or not left['candidate'] or not right['candidate']:continue
   shared=[k for k,v in left['currency_exposure'].items() if right['currency_exposure'].get(k)==v]
   if shared:overlaps.append(dict(strategy=left['strategy'],pairs=[left['pair'],right['pair']],same_direction_currencies=shared))
 source_state=[dict(r) for r in c.execute('SELECT source_id,status,checked_at,last_success FROM source_state')];last=store.query(SQL['last'],(ID,));previous_hash=last[0]['body_hash'] if last else None
 body=dict(id=ID+':'+slot,experiment=ID,run_id=runid,slot=slot,analyzed_at=iso(at),rules_hash=RULE_HASH,previous_hash=previous_hash,market_open=market_open(at),input_items_available=total_available,input_items_archived=len(items),input_items_omitted=total_available-len(items),news_items=items,news_direction_facts=known,calendar=cal,calendar_coverage_verified=False,source_states=source_state,source_count=payload.get('analysis',{}).get('usable_source_count'),market_inputs=[{k:p.get(k) for k in ['pair','quote','quote_quality','technical','news_macro','combined']} for p in pairs.values()],decisions=decisions,risk_state={s:common_risk(35000,35000,[],{}) for s in ['A','B','C']},correlation_watch=overlaps,correlation_note='追蹤共同貨幣方向曝險；缺合格報價時不虛構報酬相關係數。成交未啟用，持倉風險為0並非已驗證風險模型。',execution_enabled=False,automatic_orders=False,first_publication_note='來源發布時間、第一次取得、最近取得、分析時間分別保存；無法核對者不進方向評分',late_start_note='部署之前的測試時段不倒填')
 text=encoded(body)
 if len(text.encode())>140000:raise RuntimeError('前向封存超出保守容量，不截斷訊號或虛報成功')
 hashed=digest(text);counts=[sum(d['candidate'] for d in decisions if d['strategy']==s) for s in ['A','B','C']]
 store.query(SQL['insert'],(body['id'],ID,slot,day,iso(at),iso(at),previous_hash,hashed,len(items),*counts,text))
 check=store.query(SQL['existing'],(ID,slot))
 if not check or check[0]['body']!=text:raise RuntimeError('前向封存未確認或遇衝突，拒絕覆寫')
 report=daily(store,day,at,slot=slot)
 return dict(status='前向訊號紀錄已啟用；成交模擬未啟用',id=body['id'],rules_hash=RULE_HASH,record_hash=hashed,news_items=len(items),candidate_counts=dict(zip(['A','B','C'],counts)),daily_report=report,execution_enabled=False,end_exclusive=CONFIG['end_exclusive'])
