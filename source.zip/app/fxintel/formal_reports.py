# coding: utf-8
"""五個正式研究時槽；遲到明確記錄，不以目標時間冒充實際發布時間。"""
import json,datetime as dt
from .research_v2 import report_slot
from .marketdata import iso,market_open,stamp

def update(c,market,at,news):
 c.execute('CREATE TABLE IF NOT EXISTS formal_reports_v2(slot TEXT PRIMARY KEY,created_at TEXT NOT NULL,status TEXT NOT NULL,body TEXT NOT NULL)')
 slot=report_slot(at)
 if slot:
  closed=not market_open(at);status='週末暫停' if closed else '已完成資料限制研究報告'
  prior=c.execute('SELECT slot FROM formal_reports_v2 WHERE slot<? ORDER BY slot DESC LIMIT 1',(slot,)).fetchone()
  recent=[x for x in news if x.get('published_at') and 0<=(stamp(at)-stamp(x['published_at'])).total_seconds()<=14400]
  body=dict(target_slot=slot,published_at=iso(at),publication_delay_seconds=(stamp(at)-stamp(slot)).total_seconds(),status=status,pause_reason='週末主要市場休市，暫停一般市場報告及寄送' if closed else None,pairs=[dict(pair=p['pair'],direction=p['combined']['direction'],news_direction=p['news_macro']['direction'],technical_direction=p['combined']['technical_direction'],blocking_reasons=p['blocking_reasons']) for p in market['pairs']],news_last_four_hours=[{k:x.get(k) for k in ['source_id','title_zh','title','link','published_at']} for x in recent[:20]],future_events=dict(coverage='資料不足，未完成24～72小時事件涵蓋驗證',events=[]),scenarios='未取得完整有效價格與可核實新聞方向，不提出具價位的1～3天情境。',qualified_opportunities=[],prior_prediction_tracking=dict(previous_slot=prior[0] if prior else None,status='前次未有合格方向與進場構想；不虛構預測績效'),data_as_of=market['as_of'],validation=market['validation'],email_status='未啟用寄送；須獨立授權及實測，週末暫停不寄')
  c.execute('INSERT OR IGNORE INTO formal_reports_v2 VALUES(?,?,?,?)',(slot,iso(at),status,json.dumps(body,ensure_ascii=False)))
 c.execute('DELETE FROM formal_reports_v2 WHERE created_at<?',(iso(stamp(at)-dt.timedelta(days=30)),))
 return [json.loads(r[0]) for r in c.execute('SELECT body FROM formal_reports_v2 ORDER BY slot DESC LIMIT 3')]
