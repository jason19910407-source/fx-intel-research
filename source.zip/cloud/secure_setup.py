"""一次性本機憑證輸入：只綁定127.0.0.1，不回傳機密，不在聊天索取token。"""
import http.server,os,secrets,json,urllib.parse,argparse
from pathlib import Path

def serve(destination,port=8766):
 nonce=secrets.token_urlsafe(32);target=Path(destination).resolve()
 class Handler(http.server.BaseHTTPRequestHandler):
  def log_message(self,*args):pass
  def valid(self):return self.headers.get('Host')=='127.0.0.1:'+str(port)
  def reply(self,body,code=200):
   self.send_response(code);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Security-Policy',"default-src 'none'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(body.encode())
  def do_GET(self):
   if not self.valid() or self.path!='/':return self.reply('禁止存取',403)
   self.reply('''<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>外匯雲端｜本機機密設定</title><h1>一次性本機機密設定</h1><p>只在這台Mac儲存權限600的暫存設定，不寫入公開程式庫，不會顯示或傳回金鑰。請不要把金鑰貼到聊天。</p><form method="post"><input type="hidden" name="nonce" value="'''+nonce+'''"><p><label>Cloudflare 專用 API token（應限本帳號 D1 編輯、Workers 編輯）<br><input type="password" name="CLOUDFLARE_DEPLOY_TOKEN" autocomplete="off" size="60"></label></p><p><label>Telegram 機器人 token（機器人金鑰）<br><input type="password" name="TELEGRAM_BOT_TOKEN" autocomplete="off" size="60"></label></p><p><label>GitHub 專屬專案細粒度 token（只授權 fx-intel-research）<br><input type="password" name="GITHUB_DEPLOY_TOKEN" autocomplete="off" size="60"></label></p><p>留白不覆蓋已保存值。</p><button>只儲存於本機，交由部署工具安全讀取</button></form></html>''')
  def do_POST(self):
   if not self.valid() or self.path!='/' or self.headers.get('Origin')!='http://127.0.0.1:'+str(port):return self.reply('禁止存取',403)
   n=int(self.headers.get('Content-Length','0'))
   if not 0<n<8192:return self.reply('請求大小不合格',400)
   data=urllib.parse.parse_qs(self.rfile.read(n).decode())
   if not secrets.compare_digest(data.get('nonce',[''])[0],nonce):return self.reply('驗證失敗',403)
   allowed=['CLOUDFLARE_DEPLOY_TOKEN','TELEGRAM_BOT_TOKEN','GITHUB_DEPLOY_TOKEN'];saved=json.loads(target.read_text()) if target.exists() else {}
   for k in allowed:
    value=data.get(k,[''])[0].strip()
    if value:saved[k]=value
   target.parent.mkdir(parents=True,exist_ok=True)
   fd=os.open(str(target),os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
   with os.fdopen(fd,'w') as f:json.dump(saved,f)
   os.chmod(target,0o600)
   self.reply('<html lang="zh-Hant"><meta charset="utf-8"><h1>已安全儲存於本機</h1><p>頁面不顯示機密。請回到聊天回覆「機密已儲存」。可關閉本頁。</p></html>')
 http.server.ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--destination',required=True);p.add_argument('--port',type=int,default=8766);a=p.parse_args();serve(a.destination,a.port)
