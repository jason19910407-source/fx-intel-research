"""一次性本機Resend設定頁；不在聊天索取金鑰，不回顯既有憑證。"""
import http.server,os,secrets,json,urllib.parse,argparse,re,html
from pathlib import Path

def serve(destination,port=8766):
 nonce=secrets.token_urlsafe(32);target=Path(destination).resolve()
 class Handler(http.server.BaseHTTPRequestHandler):
  def log_message(self,*args):pass
  def valid(self):return self.headers.get('Host')=='127.0.0.1:'+str(port)
  def reply(self,body,code=200):
   self.send_response(code);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Security-Policy',"default-src 'none'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(body.encode())
  def do_GET(self):
   if not self.valid() or self.path!='/':return self.reply('禁止存取',403)
   saved=json.loads(target.read_text()) if target.exists() else {}
   sender=html.escape(saved.get('FX_EMAIL_FROM',''),quote=True);recipient=html.escape(saved.get('FX_EMAIL_TO',''),quote=True)
   self.reply('''<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>外匯雲端｜安全Email設定</title><h1>外匯電子郵件安全設定</h1><p>只在這台Mac儲存權限600的暫存設定，不會寫入公開程式庫，不會顯示或傳回金鑰。不要把金鑰貼到聊天。</p><p>外匯使用獨立寄送紀錄及排程；不修改房仲系統。免費共用帳號額度不足或無法確認時停止寄信。</p><form method="post"><input type="hidden" name="nonce" value="'''+nonce+'''"><p><label>外匯專用Resend金鑰<br><input type="password" name="RESEND_API_KEY" autocomplete="off" size="60"></label></p><p><label>寄件名稱與信箱<br><input name="FX_EMAIL_FROM" value="'''+sender+'''" size="60"></label></p><p><label>通知收件信箱<br><input type="email" name="FX_EMAIL_TO" value="'''+recipient+'''" size="60"></label></p><p>金鑰留白不覆蓋已保存值；本頁不會寄信，需另外執行明確標示的測試通知。</p><button>只儲存於本機，交由雲端部署工具安全讀取</button></form></html>''')
  def do_POST(self):
   if not self.valid() or self.path!='/' or self.headers.get('Origin')!='http://127.0.0.1:'+str(port):return self.reply('禁止存取',403)
   try:n=int(self.headers.get('Content-Length','0'))
   except ValueError:return self.reply('請求無效',400)
   if not 0<n<8192:return self.reply('請求大小不合格',400)
   data=urllib.parse.parse_qs(self.rfile.read(n).decode())
   if not secrets.compare_digest(data.get('nonce',[''])[0],nonce):return self.reply('驗證失敗',403)
   saved=json.loads(target.read_text()) if target.exists() else {};key=data.get('RESEND_API_KEY',[''])[0].strip()
   if key and not re.fullmatch(r're_[A-Za-z0-9_-]{10,200}',key):return self.reply('金鑰格式不合格，未儲存。請只貼入專用Resend金鑰，不要貼指令或聊天內容。',400)
   if key:saved['RESEND_API_KEY']=key
   for k in ['FX_EMAIL_TO','FX_EMAIL_FROM']:
    value=data.get(k,[''])[0].strip()
    if value:
     if '\r' in value or '\n' in value or len(value)>250 or '@' not in value:return self.reply('電子郵件格式不合格',400)
     saved[k]=value
   target.parent.mkdir(parents=True,exist_ok=True);fd=os.open(str(target),os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
   with os.fdopen(fd,'w') as f:json.dump(saved,f,ensure_ascii=False)
   os.chmod(target,0o600);self.reply('<html lang="zh-Hant"><meta charset="utf-8"><h1>已安全儲存於本機</h1><p>頁面不顯示機密。請回到聊天回覆「Email設定已儲存」。</p><a href="/">返回設定頁</a></html>')
 http.server.ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--destination',required=True);p.add_argument('--port',type=int,default=8766);a=p.parse_args();serve(a.destination,a.port)
