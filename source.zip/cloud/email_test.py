"""只允許手動執行的Email傳輸測試；不建立交易訊號。"""
import os,json
from .store import Store

def run():
 if os.environ.get('GITHUB_EVENT_NAME')!='workflow_dispatch':raise RuntimeError('Email通知測試只允許手動觸發')
 result=Store().email_test()
 if not result.get('configured'):raise RuntimeError('Email或免費額度尚未核對，不能宣稱測試成功')
 return result
if __name__=='__main__':print(json.dumps(run(),ensure_ascii=False))
