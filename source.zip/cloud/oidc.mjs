// GitHub OIDC（短效身分憑證）：不把Cloudflare帳號金鑰放入GitHub。
let cachedKeys=[],keysUntil=0;
const bytes=s=>Uint8Array.from(atob(s.replaceAll('-','+').replaceAll('_','/')),c=>c.charCodeAt(0));
const decode=s=>JSON.parse(new TextDecoder().decode(bytes(s)));
export function trustedClaims(c,env,now=Date.now()/1000){
 const repo=env.GITHUB_REPOSITORY,ownerId=String(env.GITHUB_OWNER_ID),repoId=String(env.GITHUB_REPOSITORY_ID);
 const [owner,name]=(repo||'').split('/');
 const subOld='repo:'+repo+':ref:refs/heads/main',subNew='repo:'+owner+'@'+ownerId+'/'+name+'@'+repoId+':ref:refs/heads/main';
 return Boolean(repo&&ownerId&&repoId&&c.iss==='https://token.actions.githubusercontent.com'&&c.aud===env.OIDC_AUDIENCE&&c.repository===repo&&String(c.repository_owner_id)===ownerId&&String(c.repository_id)===repoId&&c.ref==='refs/heads/main'&&c.ref_type==='branch'&&c.runner_environment==='github-hosted'&&c.workflow_ref===repo+'/.github/workflows/analyze.yml@refs/heads/main'&&['schedule','workflow_dispatch'].includes(c.event_name)&&[subOld,subNew].includes(c.sub)&&Number.isFinite(c.exp)&&Number.isFinite(c.nbf)&&Number.isFinite(c.iat)&&c.exp>now&&c.exp<=now+900&&c.nbf<=now+15&&c.iat<=now+15&&c.iat>=now-900);
}
export async function verifyGithub(request,env){
 try{
  const header=request.headers.get('Authorization')||'';if(!header.startsWith('Bearer ')||header.length>20000)return false;
  const [h,p,s,...extra]=header.slice(7).split('.');if(extra.length||!h||!p||!s)return false;
  const meta=decode(h),claims=decode(p);if(meta.alg!=='RS256'||!meta.kid||!trustedClaims(claims,env))return false;
  if(Date.now()>keysUntil||!cachedKeys.some(k=>k.kid===meta.kid)){
   const r=await fetch('https://token.actions.githubusercontent.com/.well-known/jwks');if(!r.ok)return false;
   const j=await r.json();cachedKeys=j.keys||[];keysUntil=Date.now()+3600000;
  }
  const jwk=cachedKeys.find(k=>k.kid===meta.kid&&k.kty==='RSA');if(!jwk)return false;
  const key=await crypto.subtle.importKey('jwk',jwk,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);
  return await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,bytes(s),new TextEncoder().encode(h+'.'+p));
 }catch{return false;}
}
