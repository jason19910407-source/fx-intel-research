"""D1（雲端 SQLite）最小橋接。機密只由環境變數讀取；不輸出 HTTP 例外 URL。"""
import os,json,urllib.request,urllib.error,time,hashlib,zlib,base64,sqlite3
from pathlib import Path

class Store:
 def __init__(self):
  self.base=os.environ.get('FX_CLOUD_URL','').rstrip('/')
  if not self.base:self.account=os.environ['CLOUDFLARE_ACCOUNT_ID'];self.database=os.environ['CLOUDFLARE_DATABASE_ID'];self.token=os.environ['CLOUDFLARE_D1_TOKEN']
  self.oidc=None;self.oidc_until=0
  self.reads=self.writes=0
 def query(self,sql,params=()):
  if self.reads>40_000 or self.writes>900:raise RuntimeError('本次執行超過保守資料庫額度，停止而不升級')
  if self.base:
   self.refresh_identity()
   req=urllib.request.Request(self.base+'/internal/query',data=json.dumps({'statement_id':hashlib.sha256(sql.encode()).hexdigest(),'params':list(params)}).encode(),headers={'Authorization':'Bearer '+self.oidc,'Content-Type':'application/json'},method='POST')
  else:
   req=urllib.request.Request('https://api.cloudflare.com/client/v4/accounts/'+self.account+'/d1/database/'+self.database+'/query',data=json.dumps({'sql':sql,'params':list(params)}).encode(),headers={'Authorization':'Bearer '+self.token,'Content-Type':'application/json'},method='POST')
  # 寫入可能已提交：此層不盲目重試；呼叫端使用可冪等的鍵及持久化狀態。
  try:
   with urllib.request.urlopen(req,timeout=30) as r:d=json.load(r)
  except Exception:raise RuntimeError('雲端資料庫存取失敗；交易通知已禁止') from None
  if not d.get('success') or not all(x.get('success',True) for x in d.get('result',[])):raise RuntimeError('雲端資料庫未確認提交；交易通知已禁止')
  out=d['result'][0]
  for x in d['result']:
   m=x.get('meta',{});self.reads+=m.get('rows_read',0);self.writes+=m.get('rows_written',0)
   if m.get('size_after',0)>200_000_000:raise RuntimeError('資料庫超過200MB保守上限，停止執行')
  return out.get('results',[])
 def refresh_identity(self):
  if self.oidc and time.time()<self.oidc_until:return
  url=os.environ['ACTIONS_ID_TOKEN_REQUEST_URL'];url+=('&' if '?' in url else '?')+'audience='+__import__('urllib.parse',fromlist=['quote']).quote(self.base,safe='')
  request=urllib.request.Request(url,headers={'Authorization':'Bearer '+os.environ['ACTIONS_ID_TOKEN_REQUEST_TOKEN']})
  try:
   with urllib.request.urlopen(request,timeout=20) as response:self.oidc=json.load(response)['value']
  except Exception:raise RuntimeError('GitHub短效身分驗證失敗，禁止存取資料及通知') from None
  self.oidc_until=time.time()+120
 def notify(self):
  self.refresh_identity()
  req=urllib.request.Request(self.base+'/internal/deliver',data=b'{}',headers={'Authorization':'Bearer '+self.oidc,'Content-Type':'application/json'},method='POST')
  try:
   with urllib.request.urlopen(req,timeout=30) as r:return json.load(r)
  except Exception:raise RuntimeError('雲端通知執行狀態未確認，不盲目重送') from None
 def email_test(self):
  self.refresh_identity()
  req=urllib.request.Request(self.base+'/internal/email-test',data=b'{}',headers={'Authorization':'Bearer '+self.oidc,'Content-Type':'application/json'},method='POST')
  try:
   with urllib.request.urlopen(req,timeout=30) as r:return json.load(r)
  except Exception:raise RuntimeError('Email測試狀態未確認；查持久化寄送紀錄，不重複建立測試') from None
 def reserve_budget(self,day):
  r=self.query("INSERT INTO daily_budget VALUES(?,1) ON CONFLICT(day) DO UPDATE SET runs=runs+1 WHERE runs<72 RETURNING runs",(day,))
  if not r:raise RuntimeError("每日執行次數已達72次保守上限，不再分析、不升級付費")
  return r[0]["runs"]
 def acquire(self,owner,epoch):
  self.query("INSERT INTO lease VALUES('analysis',?,?) ON CONFLICT(k) DO UPDATE SET owner=excluded.owner,expires=excluded.expires WHERE lease.expires<?",(owner,epoch+600,epoch))
  return self.query("SELECT owner FROM lease WHERE k='analysis'")[0]['owner']==owner
 def owns(self,owner):
  r=self.query("SELECT owner,expires FROM lease WHERE k='analysis'")
  return bool(r and r[0]['owner']==owner and r[0]['expires']>int(time.time()))
 def release(self,owner):self.query("DELETE FROM lease WHERE k='analysis' AND owner=?",(owner,))
 def value(self,k):
  r=self.query('SELECT v FROM kv WHERE k=?',(k,));return r[0]['v'] if r else None
 def put(self,k,v):self.query('INSERT INTO kv VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v',(k,v))
 def restore(self,path):
  manifest=self.value('checkpoint')
  if not manifest:return False
  m=json.loads(manifest);rows=self.query('SELECT part,body FROM checkpoints WHERE generation=? ORDER BY part',(m['generation'],))
  if len(rows)!=m['parts'] or [r['part'] for r in rows]!=list(range(m['parts'])):raise RuntimeError('持久化快照缺片，拒絕以空白狀態繼續')
  raw=base64.b64decode(''.join(r['body'] for r in rows),validate=True)
  if hashlib.sha256(raw).hexdigest()!=m['sha256']:raise RuntimeError('持久化快照雜湊錯誤')
  data=zlib.decompress(raw)
  if len(data)>50_000_000:raise RuntimeError('資料庫快照超過50MB上限')
  Path(path).write_bytes(data)
  c=sqlite3.connect(path)
  try:
   if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('資料庫完整性檢查失敗')
  finally:c.close()
  return True
 def checkpoint(self,path,generation,owner):
  raw=zlib.compress(Path(path).read_bytes(),9)
  if len(raw)>4_000_000:raise RuntimeError('壓縮快照超過4MB保守上限')
  body=base64.b64encode(raw).decode();parts=[body[i:i+60000] for i in range(0,len(body),60000)]
  for i,b in enumerate(parts):self.query('INSERT INTO checkpoints VALUES(?,?,?) ON CONFLICT(generation,part) DO UPDATE SET body=excluded.body',(generation,i,b))
  # 原子切換完整快照；租約到期或被接管時不得切換。
  m=json.dumps(dict(generation=generation,parts=len(parts),sha256=hashlib.sha256(raw).hexdigest()))
  self.query("INSERT INTO kv SELECT 'checkpoint',? WHERE EXISTS(SELECT 1 FROM lease WHERE k='analysis' AND owner=? AND expires>?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",(m,owner,int(time.time())))
  if self.value('checkpoint')!=m:raise RuntimeError('持久化提交失去租約；停止通知')
  self.query('DELETE FROM checkpoints WHERE generation<>?',(generation,))
  return dict(compressed_bytes=len(raw),chunks=len(parts),sqlite_bytes=Path(path).stat().st_size)
