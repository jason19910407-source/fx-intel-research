// Resend（電子郵件寄送服務）僅供外匯專案使用；不呼叫房仲端點或資料庫。
const iso=()=>new Date().toISOString();
const hash=async x=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(x)))].map(v=>v.toString(16).padStart(2,'0')).join('');
export function significantChange(previous,candidate){
 if(!previous)return true;
 if(previous.direction!==candidate.direction)return true;
 const oldRisk=Math.abs(previous.entry-previous.stop);
 if(!Number.isFinite(oldRisk)||oldRisk<=0)return false;
 if(['entry','stop','tp1','tp2'].some(k=>Math.abs(candidate[k]-previous[k])>=oldRisk*.5-1e-12))return true;
 return Math.abs(candidate.net_reward_risk-previous.net_reward_risk)>=.5;
}
export function emailEligibility(c,latest,at=Date.now()){
 const reasons=[],flags=['quote_fresh','cost_verified','calendar_complete','account_fresh','drawdown_ok','sources_ok','market_open','no_event_veto','spread_slippage_ok','sizing_verified'];
 if(c.simulation)reasons.push('禁止以模擬資料發出交易研究通知');
 if(!Number.isFinite(c.score)||c.score<70||c.score>100)reasons.push('研究分數未達70或無效');
 const actual=latest?.analysis?.results?.find(x=>x.pair===c.pair);
 if(c.legacy_gate?.passed!==true||actual?.gate?.passed!==true)reasons.push('實際策略或風控閘門未通過');
 for(const key of flags)if(c.conditions?.[key]!==true)reasons.push('未通過：'+key);
 if(!['EURUSD','USDJPY','GBPUSD'].includes(c.pair)||!['做多','做空'].includes(c.direction)||!c.setup_id)reasons.push('交易構想識別資料不足');
 const keys=['entry','stop','tp1','tp2','risk_twd','equity_twd','units','net_reward_risk'];
 if(!keys.every(k=>Number.isFinite(c[k])&&c[k]>0))reasons.push('進出場及風險數值無效');
 else{
  if(!(c.direction==='做多'?c.stop<c.entry&&c.entry<c.tp1&&c.tp1<=c.tp2:c.tp2<=c.tp1&&c.tp1<c.entry&&c.entry<c.stop))reasons.push('進出場方向錯誤');
  if(c.net_reward_risk<2)reasons.push('扣成本風險報酬比未達1：2');
  if(c.equity_twd>35000||c.risk_twd<c.equity_twd*.005||c.risk_twd>c.equity_twd*.01)reasons.push('不符合本金風險限制');
 }
 const data=Date.parse(c.data_at),expiry=Date.parse(c.expires_at),analysis=Date.parse(latest?.analysis?.analyzed_at);
 if(!Number.isFinite(data)||at<data||at-data>60000)reasons.push('即時買賣價過期或時鐘異常');
 if(!Number.isFinite(expiry)||expiry<=at||expiry-at>1800000)reasons.push('交易構想失效');
 if(!Number.isFinite(analysis)||at<analysis||at-analysis>4500000||latest?.analysis?.usable_source_count<30)reasons.push('分析或來源健康不合格');
 if(!c.reasons)reasons.push('缺少新聞與技術依據');
 return {passed:!reasons.length,reasons};
}
export function mailContent(row,candidate,url){
 if(row.kind==='test')return {subject:'【測試通知】外匯情報雲端 Email 通知測試',text:'這是一封測試通知，不是交易訊號。\n\n外匯情報系統已從獨立Cloudflare雲端服務使用Resend寄出本信。\n本系統每30分鐘分析，僅提供人工決策研究，完全不自動下單。\n沒有提供虛構進場價、停損或停利，也不代表任何策略已驗證。\n\n私人分析頁面：'+url+'\n通知測試識別碼：'+row.id};
 if(row.kind==='system')return {subject:'【系統狀態通知】外匯情報分析需要檢查',text:JSON.parse(row.body).text+'\n\n私人分析頁面：'+url};
 const c=candidate;
 return {subject:'【研究訊號】'+c.pair+' '+c.direction+'｜信心'+c.score+'分',text:['研究訊號，非已驗證交易策略','貨幣對：'+c.pair,'方向：'+c.direction,'綜合信心分數：'+c.score+'／100（不是勝率）','建議進場價：'+c.entry,'停損價：'+c.stop,'第一停利：'+c.tp1,'第二停利：'+c.tp2,'扣成本風險報酬比：1：'+c.net_reward_risk,'預估風險：新臺幣'+c.risk_twd+'元','建議交易數量：'+c.units+'基礎貨幣單位','訊號有效期限：'+c.expires_at,'分析資料時間：'+c.data_at,'新聞與技術分析：'+(typeof c.reasons==='string'?c.reasons:JSON.stringify(c.reasons)),'請自行人工確認；不會自動下單，跳空及滑價可能造成超出預算的虧損。','私人分析頁面：'+url].join('\n')};
}
export function freeQuota(usage){
 const d=usage?.emails?.daily,m=usage?.emails?.monthly;
 if(!d||!m||d.limit!==100||m.limit!==3000||![d.used,m.used].every(v=>Number.isFinite(v)&&v>=0))return {passed:false,reason:'無法確認Resend免費方案及共用帳號額度，停止寄信'};
 if(d.used+1>80||m.used+1>2700)return {passed:false,reason:'共用額度接近上限；為房仲保留至少每日20封、每月300封，不寄出外匯通知'};
 return {passed:true,daily_used:d.used,monthly_used:m.used};
}
async function usageCheck(env,fetcher){
 try{const r=await fetcher('https://api.resend.com/usage',{headers:{Authorization:'Bearer '+env.RESEND_API_KEY,'User-Agent':'FXIntelResearch/1.0'},signal:AbortSignal.timeout(10000)});
  if(!r.ok)return {passed:false,reason:'Resend用量查詢未獲授權或失敗；禁止以未知額度寄信',http_status:r.status};return freeQuota(await r.json());
 }catch{return {passed:false,reason:'Resend用量查詢連線失敗，停止寄信'};}
}
async function budget(db,at){
 const day=at.slice(0,10),month=at.slice(0,7);const rows=(await db.prepare('SELECT period,used FROM email_budget WHERE period IN (?,?)').bind(day,month).all()).results;const n=Object.fromEntries(rows.map(r=>[r.period,r.used]));
 if((n[day]||0)>=5||(n[month]||0)>=60)return false;
 await db.batch([db.prepare('INSERT INTO email_budget VALUES(?,1) ON CONFLICT(period) DO UPDATE SET used=used+1').bind(day),db.prepare('INSERT INTO email_budget VALUES(?,1) ON CONFLICT(period) DO UPDATE SET used=used+1').bind(month)]);return true;
}
export async function queueTest(env){
 const at=iso(),id='email-test-'+at.slice(0,10);
 await env.FX_DB.prepare("INSERT OR IGNORE INTO outbox(id,kind,created_at,expires_at,body,status) VALUES(?,'test',?,?,?,'pending')").bind(id,at,new Date(Date.now()+1800000).toISOString(),JSON.stringify({text:'測試通知；不是交易訊號'})).run();
 return id;
}
export async function sendEmailPending(env,{fetcher=fetch,onlyId=null}={}){
 if(!env.RESEND_API_KEY||!env.FX_EMAIL_FROM||!env.FX_EMAIL_TO||env.FX_EMAIL_FREE_CONFIRMED!=='yes')return {configured:false,delivered:0,reason:'尚未完成獨立Email與免費額度設定'};
 const owner=crypto.randomUUID(),at=iso(),epoch=Math.floor(Date.now()/1000);
 await env.FX_DB.prepare("INSERT INTO lease VALUES('email',?,?) ON CONFLICT(k) DO UPDATE SET owner=excluded.owner,expires=excluded.expires WHERE lease.expires<?").bind(owner,epoch+120,epoch).run();
 const lock=await env.FX_DB.prepare("SELECT owner FROM lease WHERE k='email'").first();if(lock?.owner!==owner)return {configured:true,delivered:0,reason:'另一個寄信工作執行中'};
 let sent=0,blocked=[];
 try{
  const rows=onlyId?(await env.FX_DB.prepare('SELECT * FROM outbox WHERE id=?').bind(onlyId).all()).results:(await env.FX_DB.prepare("SELECT * FROM outbox WHERE status='pending' ORDER BY created_at LIMIT 2").all()).results;
  for(const row of rows){
   if(row.status!=='pending')continue;
   if(!Number.isFinite(Date.parse(row.expires_at))||Date.parse(row.expires_at)<=Date.now()){await env.FX_DB.prepare("UPDATE outbox SET status='expired',detail='有效期限已過' WHERE id=?").bind(row.id).run();continue;}
   if(!['test','system','research'].includes(row.kind))continue;
   let candidate=null,signalKey=null;
   if(row.kind==='research'){
    candidate=JSON.parse(row.body);const latestRow=await env.FX_DB.prepare("SELECT v FROM kv WHERE k='latest'").first();const gate=emailEligibility(candidate,latestRow?JSON.parse(latestRow.v):null);
    if(!gate.passed){await env.FX_DB.prepare("UPDATE outbox SET status='rejected',detail=? WHERE id=?").bind(gate.reasons.join('；'),row.id).run();continue;}
    signalKey=await hash(candidate.pair+'|'+candidate.setup_id);const previous=await env.FX_DB.prepare('SELECT last_candidate FROM signal_notifications WHERE signal_key=?').bind(signalKey).first();
    if(previous&&!significantChange(JSON.parse(previous.last_candidate),candidate)){await env.FX_DB.prepare("UPDATE outbox SET status='duplicate',detail='相同構想無重大變化，未重寄' WHERE id=?").bind(row.id).run();continue;}
   }
   let delivery=await env.FX_DB.prepare('SELECT * FROM email_deliveries WHERE outbox_id=?').bind(row.id).first();
   if(delivery?.status==='sent')continue;
   if(delivery?.next_attempt_at&&Date.parse(delivery.next_attempt_at)>Date.now())continue;
   if(delivery&&delivery.attempts>=3){await env.FX_DB.prepare("UPDATE outbox SET status='unknown',detail='已達三次寄送嘗試；可能已寄出，禁止再次寄送並待核對服務紀錄' WHERE id=?").bind(row.id).run();continue;}
   if(delivery?.first_attempt_at&&Date.now()-Date.parse(delivery.first_attempt_at)>23*3600000){await env.FX_DB.prepare("UPDATE outbox SET status='unknown',detail='超過安全冪等重試期間，禁止重送' WHERE id=?").bind(row.id).run();continue;}
   const quota=await usageCheck(env,fetcher);
   if(!quota.passed){blocked.push(quota.reason);await env.FX_DB.prepare('UPDATE outbox SET detail=? WHERE id=?').bind(quota.reason,row.id).run();break;}
   if(!delivery){
    if(!await budget(env.FX_DB,at)){blocked.push('外匯專案已達每日5封或每月60封保守上限');break;}
    const content=mailContent(row,candidate,env.OIDC_AUDIENCE||'');const payload=JSON.stringify({from:env.FX_EMAIL_FROM,to:[env.FX_EMAIL_TO],subject:content.subject,text:content.text});
    const id=await hash('fx-email|'+row.id);
    await env.FX_DB.prepare("INSERT OR IGNORE INTO email_deliveries(id,outbox_id,signal_key,created_at,updated_at,status,attempts,payload) VALUES(?,?,?,?,?,'pending',0,?)").bind(id,row.id,signalKey,at,at,payload).run();delivery=await env.FX_DB.prepare('SELECT * FROM email_deliveries WHERE id=?').bind(id).first();
   }
   const claimed=await env.FX_DB.prepare("UPDATE email_deliveries SET status='sending',attempts=attempts+1,first_attempt_at=COALESCE(first_attempt_at,?),updated_at=? WHERE id=? AND status IN ('pending','retry','sending') AND attempts<3 RETURNING id").bind(at,at,delivery.id).first();if(!claimed)continue;
   let status='retry',providerId=null,detail='連線結果未確認；使用相同冪等識別碼有限重試',retryAt=new Date(Date.now()+120000).toISOString();
   try{
    const r=await fetcher('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+env.RESEND_API_KEY,'Content-Type':'application/json','Idempotency-Key':'fx-email/'+delivery.id,'User-Agent':'FXIntelResearch/1.0'},body:delivery.payload,signal:AbortSignal.timeout(10000)});
    const data=await r.json();
    if(r.ok&&data.id){status='sent';providerId=String(data.id);detail='Resend已接受，是否送達須再核對寄送事件';retryAt=null;sent++;}
    else if(r.status===429){detail='Resend限流或額度不足；未升級付費，稍後有限重試';const delay=Math.min(3600,Math.max(120,Number(r.headers.get('Retry-After'))||120));retryAt=new Date(Date.now()+delay*1000).toISOString();}
    else if(r.status<500){status='failed';detail='Resend拒絕請求（HTTP '+r.status+'）；未記錄機密回應';retryAt=null;}
   }catch{}
   await env.FX_DB.prepare('UPDATE email_deliveries SET status=?,updated_at=?,next_attempt_at=?,provider_id=?,provider_status=?,detail=? WHERE id=?').bind(status,iso(),retryAt,providerId,status==='sent'?'accepted':null,detail,delivery.id).run();
   if(status==='sent'){
    await env.FX_DB.prepare("UPDATE outbox SET status='sent',message_id=?,detail=? WHERE id=?").bind(providerId,detail,row.id).run();
    if(candidate)await env.FX_DB.prepare('INSERT INTO signal_notifications VALUES(?,?,?,?) ON CONFLICT(signal_key) DO UPDATE SET last_candidate=excluded.last_candidate,last_sent_at=excluded.last_sent_at,delivery_id=excluded.delivery_id').bind(signalKey,JSON.stringify(candidate),iso(),delivery.id).run();
   }else if(status==='failed')await env.FX_DB.prepare("UPDATE outbox SET status='failed',detail=? WHERE id=?").bind(detail,row.id).run();
  }
  return {configured:true,delivered:sent,blocked,channel:'email'};
 }finally{await env.FX_DB.prepare("DELETE FROM lease WHERE k='email' AND owner=?").bind(owner).run();}
}
