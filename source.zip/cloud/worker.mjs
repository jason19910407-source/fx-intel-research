import {forwardDashboard} from './forward_dashboard.mjs';
import {dashboard} from './dashboard.mjs';
import {dispatchAnalysis,claimDispatch,remindExpiry,claimAnalysisSlot,preflightGithub} from './dispatch.mjs';
import {sendEmailPending,queueTest} from './email.mjs';
import {verifyGithub} from './oidc.mjs';
import {statements} from './query_allowlist.mjs';
// 只讀手機入口，不公開本機管理 API；所有憑證只在伺服器環境。
export const SESSION_MS=30*24*60*60*1000;
const enc = new TextEncoder();
const sha = async s => [...new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(s)))].map(x=>x.toString(16).padStart(2,'0')).join('');
const eq=(a,b)=>{if(typeof a!=='string'||typeof b!=='string'||a.length!==b.length)return false;let v=0;for(let i=0;i<a.length;i++)v|=a.charCodeAt(i)^b.charCodeAt(i);return v===0;};
async function hmac(s,key){const k=await crypto.subtle.importKey('raw',enc.encode(key),{name:'HMAC',hash:'SHA-256'},false,['sign']);return [...new Uint8Array(await crypto.subtle.sign('HMAC',k,enc.encode(s)))].map(x=>x.toString(16).padStart(2,'0')).join('');}
export async function authenticated(request,env,at=Date.now()){
 if(!env.SESSION_SECRET || env.SESSION_SECRET.length<32)return false;
 const token=(request.headers.get('Cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('__Host-fx_session='))?.slice(18);
 if(!token)return false;const [expiry,nonce,signature]=token.split('.');
 if(!/^\d{13}$/.test(expiry)||!nonce||Number(expiry)<=at||Number(expiry)>at+SESSION_MS)return false;
 if(!eq(await hmac(expiry+'.'+nonce+'|'+env.LOGIN_PASSWORD_HASH,env.SESSION_SECRET),signature))return false;
 if(!env.FX_DB)return false;
 const row=await env.FX_DB.prepare('SELECT expires FROM web_sessions WHERE id=?').bind(await sha(nonce)).first();
 return Boolean(row&&row.expires>at&&row.expires===Number(expiry));
}
const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','X-Frame-Options':'DENY','Permissions-Policy':'camera=(), microphone=(), geolocation=()','Strict-Transport-Security':'max-age=31536000'};
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{...headers,'Content-Type':'application/json; charset=utf-8'}});
const html=(body,nonce)=>new Response(body,{headers:{...headers,'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':`default-src 'none'; style-src 'nonce-${nonce}'; script-src 'nonce-${nonce}'; connect-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'`}});
const css=`body{font:17px/1.6 system-ui;background:#101823;color:#e5eef8;margin:0}main{max-width:1020px;margin:auto;padding:22px}h1{font-size:26px}h2{font-size:21px;color:#9fd7ff}section,article{background:#1c2939;border-radius:12px;padding:18px;margin:15px 0}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px}a{color:#8fd6ff}input,button{font:inherit;padding:10px;border-radius:8px;max-width:90%}button{cursor:pointer;background:#9cd9ff}table{width:100%;font-size:14px;border-collapse:collapse}td,th{text-align:left;border-bottom:1px solid #4c5b6c;padding:9px}.scroll{overflow-x:auto}.muted{color:#b6c4d4}.warning{border-left:5px solid #ffbd65}.good{color:#99edc5}summary{cursor:pointer}`;
function loginPage(n){return html(`<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>外匯研究台｜安全登入</title><style nonce="${n}">${css}</style><main><h1>外匯市場情報研究台</h1><section><h2>私人頁面登入</h2><p>請輸入你設定的專用密碼。登入後維持30天；共用裝置使用完請登出。此系統只提供情報，完全不下單。</p><form action="/login" method="post"><label for="password">專用存取密碼</label><p><input id="password" type="password" name="password" autocomplete="current-password" required minlength="12" maxlength="200"></p><button>安全登入</button></form></section></main><script nonce="${n}">fetch('/api/session',{credentials:'same-origin',cache:'no-store'}).then(r=>{if(r.ok)location.replace('/')}).catch(()=>{});</script></html>`,n);}
function dashboardPage(n,system=false){return html(dashboard(n,system),n);}
export async function fetchHandler(request,env){
 const url=new URL(request.url),path=url.pathname,nonce=crypto.randomUUID().replaceAll('-','');
 if(path.startsWith('/internal/')){
  if(request.method!=='POST'||!env.FX_DB||!await verifyGithub(request,env))return json({error:'雲端工作身分驗證失敗'},403);
  if(path==='/internal/query'){
   if(Number(request.headers.get('Content-Length')||0)>600000)return json({error:'請求過大'},413);
   const text=await request.text();if(text.length>600000)return json({error:'請求過大'},413);
   const input=JSON.parse(text),sql=statements[input.statement_id];
   if(!sql||!Array.isArray(input.params)||input.params.length>100||input.params.some(v=>v!==null&&!['string','number'].includes(typeof v)))return json({error:'資料庫指令不在白名單'},400);
   const result=await env.FX_DB.prepare(sql).bind(...input.params).all();
   return json({success:true,result:[{success:true,results:result.results||[],meta:result.meta||{}}]});
  }
  if(path==='/internal/analysis-slot'){
   const input=await request.json(),jwt=request.headers.get('Authorization').slice(7).split('.')[1];
   const claims=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(jwt.replaceAll('-','+').replaceAll('_','/')),c=>c.charCodeAt(0))));
   return json(await claimAnalysisSlot(env,claims,input.id||''));
  }
  if(path==='/internal/schedule-claim'){
   const input=await request.json();
   // 前面的verifyGithub已完整驗簽、驗證官方發行者、專案及正式分支。
   const jwt=request.headers.get('Authorization').slice(7).split('.')[1];
   const claims=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(jwt.replaceAll('-','+').replaceAll('_','/')),c=>c.charCodeAt(0))));
   return json(await claimDispatch({...env,FX_GITHUB_REPOSITORY:env.GITHUB_REPOSITORY},input.id,claims));
  }
  if(path==='/internal/deliver')return json(await deliverPending(env));
  if(path==='/internal/email-test'){const id=await queueTest(env);return json({test_id:id,...await sendEmailPending(env,{onlyId:id})});}
  return json({error:'不支援的雲端工作'},404);
 }
 if(path==='/health')return json({status:'私人研究入口',automatic_orders:false});
 if(!env.FX_DB||!env.LOGIN_PASSWORD_HASH||!env.SESSION_SECRET||env.SESSION_SECRET.length<32)return json({error:'尚未完成安全設定，停止提供資料'},503);
 if(path==='/login'&&request.method==='POST'){
  if(request.headers.get('Origin')!==url.origin)return json({error:'來源驗證失敗'},403);
  if(Number(request.headers.get('Content-Length')||0)>2048)return json({error:'請求過大'},413);
  const bucket=await sha((request.headers.get('CF-Connecting-IP')||'unknown')+'|'+Math.floor(Date.now()/900000));
  const row=await env.FX_DB.prepare('INSERT INTO login_limits VALUES(?,1) ON CONFLICT(bucket) DO UPDATE SET n=n+1 RETURNING n').bind(bucket).first();
  if(row.n>10)return json({error:'登入嘗試過多，請15分鐘後再試'},429);
  const text=await request.text();if(text.length>2048)return json({error:'請求過大'},413);
  const password=new URLSearchParams(text).get('password')||'';
  if([...password].length<12||password.length>200||!eq(await sha(password),env.LOGIN_PASSWORD_HASH))return json({error:'密碼不正確'},401);
  const expiry=Date.now()+SESSION_MS,sessionId=crypto.randomUUID(),body=String(expiry)+'.'+sessionId,sig=await hmac(body+'|'+env.LOGIN_PASSWORD_HASH,env.SESSION_SECRET);
  await env.FX_DB.prepare('DELETE FROM web_sessions WHERE expires<=?').bind(Date.now()).run();
  await env.FX_DB.prepare('INSERT INTO web_sessions(id,expires) VALUES(?,?)').bind(await sha(sessionId),expiry).run();
  return new Response(null,{status:303,headers:{...headers,Location:'/', 'Set-Cookie':'__Host-fx_session='+body+'.'+sig+'; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=2592000'}});
 }
 if(path==='/logout'&&request.method==='POST'){
  if(request.headers.get('Origin')!==url.origin)return json({error:'來源驗證失敗'},403);
  const token=(request.headers.get('Cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('__Host-fx_session='))?.slice(18);
  if(token&&await authenticated(request,env)){const sessionId=token.split('.')[1];await env.FX_DB.prepare('DELETE FROM web_sessions WHERE id=?').bind(await sha(sessionId)).run();}
  return new Response(null,{status:303,headers:{...headers,Location:'/', 'Set-Cookie':'__Host-fx_session=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0'}});
 }
 if(path==='/api/session'){
  if(request.method!=='GET')return json({error:'只提供登入狀態查詢'},405);
  if(!await authenticated(request,env))return json({error:'需要有效Cookie及伺服器工作階段'},401);
  return json({authenticated:true,session_days:30});
 }
 const auth=await authenticated(request,env);
 if((path==='/'||path==='/system'||path==='/forward')&&request.method==='GET')return auth?(path==='/forward'?html(forwardDashboard(nonce),nonce):dashboardPage(nonce,path==='/system')):loginPage(nonce);
 if(!auth)return json({error:'需要登入'},401);
 if(path==='/api/notifications/test'&&request.method==='POST'){
  if(request.headers.get('Origin')!==url.origin)return json({error:'來源驗證失敗'},403);
  const testId=await queueTest(env);const result=await sendEmailPending(env,{onlyId:testId});
  const record=await env.FX_DB.prepare('SELECT id,status,message_id,detail FROM outbox WHERE id=?').bind(testId).first();
  return json({test_id:testId,result,record},result.configured?200:503);
 }
 if(request.method!=='GET')return json({error:'只提供查詢，不接受交易或管理操作'},405);
 if(path==='/api/dashboard'){
  const r=await env.FX_DB.prepare("SELECT k,v FROM kv WHERE k IN ('latest','last_success_at','monitor_last_at')").all(),v=Object.fromEntries(r.results.map(x=>[x.k,x.v]));
  const d=v.latest?JSON.parse(v.latest):{limitation:'尚未有雲端分析結果'};d.last_success_at=v.last_success_at||null;d.dispatch_authorization={configured:Boolean(env.FX_GITHUB_DISPATCH_TOKEN),expires_at:env.FX_GITHUB_TOKEN_EXPIRES||null};d.monitor_last_at=v.monitor_last_at||null;d.email_configured=Boolean(env.RESEND_API_KEY&&env.FX_EMAIL_FROM&&env.FX_EMAIL_TO&&env.FX_EMAIL_FREE_CONFIRMED==='yes');d.last_scheduled_success=await env.FX_DB.prepare("SELECT id,started_at,ended_at,source_count,workflow_url FROM runs WHERE trigger_kind IN ('schedule','cloudflare_schedule') AND status='success' ORDER BY started_at DESC LIMIT 1").first();
  const age=Date.now()-Date.parse(d.analysis?.analyzed_at||'');d.stale=!Number.isFinite(age)||age<0||age>4500000;if(d.stale)d.signals=[];return json(d);
 }
 if(path==='/api/forward'){
  const id='forward-20261107-20261121-v1';
  const ex=await env.FX_DB.prepare('SELECT * FROM forward_experiments WHERE id=?').bind(id).first();
  const latest=await env.FX_DB.prepare('SELECT body FROM forward_observations WHERE experiment=? ORDER BY recorded_at DESC,id DESC LIMIT 1').bind(id).first();
  const observations=(await env.FX_DB.prepare('SELECT id,slot,analyzed_at,body_hash,a_candidates,b_candidates,c_candidates FROM forward_observations WHERE experiment=? ORDER BY slot DESC LIMIT 30').bind(id).all()).results;
  const count=await env.FX_DB.prepare('SELECT COUNT(*) n FROM forward_observations WHERE experiment=?').bind(id).first();
  const reports=(await env.FX_DB.prepare("SELECT body FROM forward_reports WHERE experiment=? AND kind IN ('daily_final','final') ORDER BY created_at DESC LIMIT 20").bind(id).all()).results;
  const current=await env.FX_DB.prepare("SELECT body FROM forward_reports WHERE experiment=? AND kind='daily_snapshot' ORDER BY created_at DESC LIMIT 1").bind(id).first();
  return json({experiment:ex?{...ex,body:JSON.parse(ex.body)}:null,latest:latest?JSON.parse(latest.body):null,observation_count:count?.n||0,observations,reports:[...(current?[JSON.parse(current.body)]:[]),...reports.map(r=>JSON.parse(r.body))],execution_enabled:false,automatic_orders:false});
 }
 if(path==='/api/scheduler/preflight')return json(await preflightGithub(env));
 if(path==='/api/notifications/status')return json({channel:'電子郵件',configured:Boolean(env.RESEND_API_KEY&&env.FX_EMAIL_FROM&&env.FX_EMAIL_TO&&env.FX_EMAIL_FREE_CONFIRMED==='yes'),daily_limit:5,monthly_limit:60,records:(await env.FX_DB.prepare('SELECT id,created_at,status,attempts,provider_status,detail FROM email_deliveries ORDER BY created_at DESC LIMIT 10').all()).results});
 if(path==='/api/reports'){
  const slot=url.searchParams.get('slot');
  if(slot){if(!/^\d{4}-\d{2}-\d{2}T(?:00|08|12|16|20):00\+08:00$/.test(slot))return json({error:'報告時槽格式不符'},400);const r=await env.FX_DB.prepare('SELECT body FROM research_reports_v2 WHERE slot=?').bind(slot).first();return r?json(JSON.parse(r.body)):json({error:'沒有此報告'},404);}
  return json((await env.FX_DB.prepare('SELECT slot,created_at,status FROM research_reports_v2 ORDER BY slot DESC LIMIT 150').all()).results);
 }
 if(path==='/api/runs')return json((await env.FX_DB.prepare('SELECT id,started_at,ended_at,status,trigger_kind,workflow_url,source_count FROM runs ORDER BY started_at DESC LIMIT 20').all()).results);
 if(path==='/api/signals')return json((await env.FX_DB.prepare('SELECT id,kind,created_at,expires_at,status,attempts FROM outbox ORDER BY created_at DESC LIMIT 30').all()).results);
 return json({error:'找不到頁面'},404);
}
export async function deliverPending(env){return sendEmailPending(env);}
export async function scheduledHandler(event,env){
 await remindExpiry(env);
 if(event.cron==='8,38 * * * *')return dispatchAnalysis(event,{...env,FX_GITHUB_REPOSITORY:env.GITHUB_REPOSITORY});
 if(!env.FX_DB)return;
 const r=await env.FX_DB.prepare("SELECT k,v FROM kv WHERE k IN ('last_success_at','consecutive_failures')").all(),v=Object.fromEntries(r.results.map(x=>[x.k,x.v]));
 const stale=!v.last_success_at || Date.now()-Date.parse(v.last_success_at)>4500000;
 const healthy=!stale&&Number(v.consecutive_failures||0)<3;
 const scheduledAt=new Date(event.scheduledTime||Date.now()).toISOString(),checkedAt=new Date().toISOString();
 await env.FX_DB.prepare('INSERT OR REPLACE INTO monitor_runs VALUES(?,?,?,?,?,?)').bind('monitor-'+scheduledAt,scheduledAt,checkedAt,v.last_success_at||null,healthy?'healthy':'needs_attention','雲端排程健康檢查；不是市場分析執行證據').run();
 await env.FX_DB.prepare("INSERT INTO kv VALUES('monitor_last_at',?) ON CONFLICT(k) DO UPDATE SET v=excluded.v").bind(checkedAt).run();
 if(healthy){await env.FX_DB.prepare("UPDATE outbox SET status='expired',detail='新的完整分析已成功，解除舊健康警報' WHERE kind='system' AND id LIKE 'system-health-%' AND status='pending'").run();return;}
 const id='system-health-'+Math.floor(Date.now()/21600000),now=new Date().toISOString(),expiry=new Date(Date.now()+21600000).toISOString();
 const body=JSON.stringify({text:'【系統監控警報・非交易訊號】\n外匯分析超過75分鐘未完整成功，或連續失敗至少3次。暫停交易訊號，請開啟私人頁面查看。\n最後成功：'+(v.last_success_at||'尚無紀錄')+'\n不保證排程即時性。'});
 await env.FX_DB.prepare("INSERT OR IGNORE INTO outbox(id,kind,created_at,expires_at,body,status) VALUES(?,'system',?,?,?,'pending')").bind(id,now,expiry,body).run();
 await deliverPending(env);
 await env.FX_DB.prepare('DELETE FROM login_limits').run();
}
export default {async fetch(request,env){try{return await fetchHandler(request,env)}catch{return json({error:'資料讀取失敗，禁止交易訊號'},503)}},scheduled:scheduledHandler};
