"""沿用既有蒐集與分析；刻意不呼叫本機 cycle/emit_simulations。"""
import os,sys,json,time,uuid,tempfile,sqlite3,datetime as dt,hashlib
from pathlib import Path
from .store import Store
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'app'))
from fxintel import core,collect,analyze,market_view,formal_reports,paper_forward
UTC=dt.timezone.utc

def configure(root):
 root=Path(root);(root/'reports').mkdir(parents=True,exist_ok=True);(root/'data').mkdir(parents=True,exist_ok=True)
 for name in ['sources.json','config.json']:(root/name).write_bytes((BASE/'app'/name).read_bytes())
 for module in [core,collect,analyze]:module.ROOT=root
 return root/'data/intelligence.sqlite3'

def compact(c):
 # 明確保存期限：新聞30日、擷取/盤點90日、參考價180日、站內事件180日。
 at=core.now()
 for table,col,days in [('items','observed_at',30),('fetches','observed_at',90),('cycles','started_at',90),('reference_rates','reference_date',180),('alerts','created_at',180)]:
  c.execute('DELETE FROM '+table+' WHERE '+col+'<?',((at-dt.timedelta(days=days)).isoformat(),))
 c.execute('DELETE FROM calendar WHERE event_time<?',((at-dt.timedelta(days=7)).isoformat(),));c.commit()

def view(c,analysis):
 s=core.snapshot(c)
 market=market_view.snapshot(c,core.now());reports=formal_reports.update(c,market,core.now(),s["items"])
 seen=set();news=[]
 for item in s['items']:
  key=(item.get('source_id'),item.get('link') or item.get('title'))
  if key in seen:continue
  seen.add(key);news.append({k:item.get(k) for k in ['source_id','title_zh','title','link','published_at','observed_at']})
 # 不把手動帳戶紀錄、操作管理功能、原始全文或試發模擬通知放到手機頁。
 return dict(generated_at=s['generated_at'],automatic_orders=False,analysis=analysis,rates=s['rates'],sources=[dict(id=x['id'],name=x['name'],enabled=x['enabled'],state=x['state']) for x in s['sources']],news=news[:35],market_v2=market,formal_reports=reports,signals=[],performance=dict(status='沒有已驗證交易訊號，不計算虛構勝率'),limitation=s['limitation'])

def run():
 # 明確拒絕在未檢查免費方案的遠端環境意外啟動。
 if os.environ.get('FREE_PLAN_CONFIRMED')!='yes':raise RuntimeError('尚未確認獨立專案及免費方案，停止部署執行')
 store=Store();owner=uuid.uuid4().hex;at=core.iso();trigger=os.getenv('GITHUB_EVENT_NAME','manual');runid=os.getenv('GITHUB_RUN_ID',owner)+'-'+os.getenv('GITHUB_RUN_ATTEMPT','1')
 workflow='https://github.com/'+os.getenv('GITHUB_REPOSITORY','')+'/actions/runs/'+os.getenv('GITHUB_RUN_ID','')
 store.reserve_budget(core.now().date().isoformat())
 if not store.acquire(owner,int(time.time())):return dict(status='已有執行中工作，未重複執行')
 try:
  store.query('INSERT OR IGNORE INTO runs(id,started_at,status,trigger_kind,workflow_url) VALUES(?,?,\'running\',?,?)',(runid,at,trigger,workflow))
  with tempfile.TemporaryDirectory(prefix='fxintel-cloud-') as temp:
   db=configure(temp);restored=store.restore(db)
   c=core.connect(db);c.close()
   # 排程重試只針對完整分析工作；來源429及失敗沿用原有退避，不強迫重抓。
   collected=collect.collect();c=core.connect(db)
   analysis=analyze.analyze(c);health=[dict(r) for r in c.execute('SELECT * FROM source_state')]
   payload=view(c,analysis)
   try:payload['forward_14d']=paper_forward.record(store,c,payload,runid,core.now())
   except Exception:payload['forward_14d']=dict(status='前向紀錄失敗，沒有補造或成交；詳執行與資料庫紀錄',execution_enabled=False,error=True)
   compact(c);c.execute('PRAGMA wal_checkpoint(TRUNCATE)');c.close()
   info=store.checkpoint(db,runid+'-'+owner,owner)
   if not store.owns(owner):raise RuntimeError('執行租約失效，禁止通知')
   # 分析保留90日，不重複儲存每日完整history，避免容量按每30分鐘膨脹。
   small=json.loads(json.dumps(analysis))
   for x in small['results']:x.pop('history',None)
   small['research_version']='2.0資料品質研究版'
   small['v2_results']=[{k:p[k] for k in ['pair','combined','technical','news_macro','quote_quality','qualified','blocking_reasons']} for p in payload['market_v2']['pairs']]
   payload['analysis']=small
   encoded=json.dumps(payload,ensure_ascii=False,separators=(',',':'))
   if len(encoded.encode())>500_000:raise RuntimeError('手機快照超過容量上限')
   store.query('INSERT OR IGNORE INTO analyses VALUES(?,?,?)',(runid,analysis['analyzed_at'],json.dumps(small,ensure_ascii=False)))
   store.put('latest',encoded);store.put('source_health',json.dumps(health,ensure_ascii=False))
   for report in payload.get('formal_reports',[]):
    store.query('INSERT OR IGNORE INTO research_reports_v2 VALUES(?,?,?,?)',(report['target_slot'],report['published_at'],report['status'],json.dumps(report,ensure_ascii=False)))
   store.query('DELETE FROM research_reports_v2 WHERE created_at<?',((core.now()-dt.timedelta(days=30)).isoformat(),))
   status='success' if analysis['minimum_sources_met'] else 'degraded'
   summary=dict(usable_sources=analysis['usable_source_count'],restored=restored,persistence=info,source_checks=collected,real_signals=0,forward_14d=payload.get('forward_14d'),signal_reason='現有策略尚未通過，且沒有即時買賣價與可驗證交易構想；未啟用模擬訊號產生器')
   if os.environ.get('FX_CLOUD_URL'):summary['notifications']=store.notify()
   store.query('UPDATE runs SET ended_at=?,status=?,source_count=?,summary=? WHERE id=?',(core.iso(),status,analysis['usable_source_count'],json.dumps(summary,ensure_ascii=False),runid))
   store.put('latest_completed_at',core.iso())
   if status=='success':store.put('last_success_at',core.iso());store.put('consecutive_failures','0')
   else:store.put('consecutive_failures',str(int(store.value('consecutive_failures') or '0')+1))
   # 保留90日分析與排程、180日通知及後續評估。沒有報價時不補造評估結果。
   cutoff=(core.now()-dt.timedelta(days=90)).isoformat()
   store.query('DELETE FROM analyses WHERE id IN (SELECT id FROM analyses WHERE at<? LIMIT 80)',(cutoff,));store.query('DELETE FROM runs WHERE id IN (SELECT id FROM runs WHERE started_at<? LIMIT 80)',(cutoff,))
   store.query('DELETE FROM outbox WHERE id IN (SELECT id FROM outbox WHERE created_at<? LIMIT 50)',((core.now()-dt.timedelta(days=180)).isoformat(),))
   return dict(status=status,run_id=runid,usable_sources=analysis['usable_source_count'],checkpoint=info,real_signals=0)
 except Exception:
  try:
   store.query("UPDATE runs SET ended_at=?,status='failed',summary=? WHERE id=?",(core.iso(),json.dumps({'error':'分析、資料庫或通知驗證失敗；詳工作執行紀錄，未輸出機密'}),runid))
   store.put('consecutive_failures',str(int(store.value('consecutive_failures') or '0')+1))
  except Exception:pass
  raise
 finally:store.release(owner)

if __name__=='__main__':
 try:print(json.dumps(run(),ensure_ascii=False))
 except Exception as e:print('執行失敗：'+str(e),file=sys.stderr);sys.exit(1)
