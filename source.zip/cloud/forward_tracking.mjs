// 只讀追蹤：從原不可改寫帳本投影，不更改策略、不回填方向或驗證價格。
export const EXPERIMENT='forward-20261107-20261121-v1';
export const EXPERIMENTS={'1':EXPERIMENT,'2':'forward-20261107-20261121-v2'};
export const TRACKING_POLICY={version:1,expiry:'沿用每筆原始30分鐘有效期限；到期不代表判斷正確',accuracy:'只計有明確多空方向且起訖合格買賣價可驗證的紀錄；觀望不進分母',quote_verification_enabled:false,execution_enabled:false,reason:'持續報價與保存授權尚未驗收，沒有合格起訖報價；不使用每日參考價、最近價或事後補價判輸贏',metrics_note:'方向準確率不是交易獲利或勝率；分數不是機率；重複時槽不是獨立機會'};
export function project(observation,at){
 const b=typeof observation.body==='string'?JSON.parse(observation.body):observation.body;
 const markets=new Map((b.market_inputs||[]).map(m=>[m.pair,m]));
 return (b.decisions||[]).map(d=>{
  const end=Date.parse(d.expiry_at),created=Date.parse(b.analyzed_at),now=Date.parse(at),validTime=Number.isFinite(end)&&Number.isFinite(created)&&end>=created;
  const expiry=validTime?(now>=end?'已到期':'尚未到期'):'期限資料異常';
  const directional=['偏多','偏空'].includes(d.direction),m=markets.get(d.pair)||{};
  const verification=!directional?'不評分：觀望／未形成方向':expiry==='尚未到期'?'尚未到期：等待追蹤':expiry==='期限資料異常'?'資料不足無法驗證：期限異常':'資料不足無法驗證：缺合格起訖買賣價';
  return {id:b.id+':'+d.strategy+':'+d.pair,observation_id:b.id,run_id:b.run_id,slot:b.slot,strategy:d.strategy,pair:d.pair,generated_at:b.analyzed_at,expiry_at:d.expiry_at,direction:d.direction,confidence_score:d.score??null,candidate:Boolean(d.candidate),expiry_state:expiry,verification_state:verification,directional,verified:false,direction_correct:null,accuracy_eligible:false,actual_trade_pnl_twd:null,
   basis:{technical:m.technical||null,news_evidence_ids:d.news_evidence||[],news_facts:(b.news_direction_facts||[]).filter(f=>(d.news_evidence||[]).includes(f.id)),blocking_reasons:d.blocking_reasons||[],invalidation:d.invalidation||null},
   data_quality:{quote_quality:m.quote_quality||{valid:false,reason:'原始紀錄缺報價品質'},calendar_coverage_verified:b.calendar_coverage_verified===true,missing_confidence_score:d.score==null,publication_note:b.first_publication_note||null,original_analysis_time:b.analyzed_at},
   provenance:{original_record_hash:observation.body_hash,rules_hash:b.rules_hash,derived_at:at,original_record_unchanged:true},execution_enabled:false};
 });
}
export const SQL_STATS=`SELECT COUNT(*) observations,COALESCE(SUM(json_array_length(body,'$.decisions')),0) prediction_records,COALESCE(SUM(CASE WHEN json_array_length(body,'$.decisions')=24 THEN 0 ELSE 1 END),0) malformed_observations,MIN(analyzed_at) first_analysis_at,MAX(analyzed_at) last_analysis_at FROM forward_observations WHERE experiment=? AND julianday(analyzed_at)<=julianday(?)`;
export const SQL_DAYS=`SELECT o.day_taipei,json_extract(d.value,'$.strategy') strategy,COUNT(*) records,SUM(CASE WHEN json_extract(d.value,'$.direction') IN ('偏多','偏空') THEN 1 ELSE 0 END) directional,SUM(CASE WHEN json_extract(d.value,'$.candidate')=1 THEN 1 ELSE 0 END) candidates,SUM(CASE WHEN julianday(json_extract(d.value,'$.expiry_at'))<=julianday(?) THEN 1 ELSE 0 END) expired,SUM(CASE WHEN julianday(json_extract(d.value,'$.expiry_at'))>julianday(?) THEN 1 ELSE 0 END) pending,SUM(CASE WHEN julianday(json_extract(d.value,'$.expiry_at')) IS NULL THEN 1 ELSE 0 END) invalid_expiry,SUM(CASE WHEN json_extract(d.value,'$.direction') IN ('偏多','偏空') AND julianday(json_extract(d.value,'$.expiry_at'))<=julianday(?) THEN 1 ELSE 0 END) expired_directional,SUM(CASE WHEN json_extract(d.value,'$.score') IS NULL THEN 1 ELSE 0 END) missing_score,MIN(o.analyzed_at) first_analysis_at,MAX(o.analyzed_at) last_analysis_at FROM forward_observations o,json_each(o.body,'$.decisions') d WHERE o.experiment=? AND julianday(o.analyzed_at)<=julianday(?) GROUP BY o.day_taipei,json_extract(d.value,'$.strategy') ORDER BY o.day_taipei DESC,strategy`;
export async function tracking(db,{page=0,anchor,at=new Date().toISOString(),experiment=EXPERIMENT}={}){
 if(!Object.values(EXPERIMENTS).includes(experiment))throw new RangeError('版本不符');
 if(!Number.isInteger(page)||page<0||page>335)throw new RangeError('頁碼不符');
 const parsed=anchor?Date.parse(anchor):Date.parse(at);
 if(!Number.isFinite(parsed)||parsed>Date.parse(at))throw new RangeError('查詢時點不符');
 // 正規化成原帳本UTC格式（+00:00），只讀固定界線以前的紀錄，翻頁不因新時槽位移。
 const boundary=new Date(parsed).toISOString().replace('.000Z','+00:00');
 const [stats,days,recent]=await Promise.all([
  db.prepare(SQL_STATS).bind(experiment,boundary).first(),
  db.prepare(SQL_DAYS).bind(at,at,at,experiment,boundary).all(),
  db.prepare('SELECT id,body,body_hash FROM forward_observations WHERE experiment=? AND julianday(analyzed_at)<=julianday(?) ORDER BY slot DESC LIMIT 2 OFFSET ?').bind(experiment,boundary,page*2).all()
 ]);
 const summary=(days.results||[]).map(d=>({...d,abstentions:d.records-d.directional,unverifiable_directional:d.expired_directional,verified_directional:0,direction_correct:0,direction_accuracy:null,accuracy_status:d.directional===0?'無多空預測，無方向準確率分母':'無合格起訖報價，不能計算方向準確率',executed_trades:0,trade_win_rate:null,actual_trade_pnl_twd:null,trade_status:'未啟用成交；不是已驗證零損益'}));
 return {experiment,as_of:at,anchor:boundary,page,page_size_observations:2,total_pages:Math.ceil((stats?.observations||0)/2),statistics:stats,daily_comparison:summary,predictions:(recent.results||[]).flatMap(o=>project(o,at)),policy:TRACKING_POLICY,execution_enabled:false,automatic_orders:false};
}
