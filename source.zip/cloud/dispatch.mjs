// Cloudflare定時啟動既有GitHub分析；專用憑證僅存在伺服器機密。
// 不接受HTTP請求直接呼叫；由Worker的scheduled處理器傳入真正雲端事件。
export const schema=`CREATE TABLE IF NOT EXISTS analysis_dispatches(
 id TEXT PRIMARY KEY,slot TEXT NOT NULL UNIQUE,scheduled_at TEXT NOT NULL,
 observed_at TEXT NOT NULL,status TEXT NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,
 github_run_id TEXT UNIQUE,http_status INTEGER,detail TEXT NOT NULL);`;
const cron='8,38 * * * *';
export async function dispatchAnalysis(event,env,{now=Date.now(),fetcher=fetch}={}){
 const t=Number(event?.scheduledTime),d=new Date(t),age=now-t;
 if(event?.cron!==cron||!Number.isFinite(t)||age<0||age>120000||![8,38].includes(d.getUTCMinutes()))throw Error('不是有效且及時的半小時排程事件');
 if(!env.FX_DB)throw Error('缺少獨立外匯資料庫');
 const slot=d.toISOString().slice(0,16),id=crypto.randomUUID();
 const expiry=Date.parse(env.FX_GITHUB_TOKEN_EXPIRES||'');
 const configured=Number.isFinite(expiry)&&expiry>now&&env.FX_CLOUD_DISPATCH_ENABLED==='yes'&&typeof env.FX_GITHUB_DISPATCH_TOKEN==='string'&&env.FX_GITHUB_DISPATCH_TOKEN.length>=20;
 const row=await env.FX_DB.prepare('INSERT OR IGNORE INTO analysis_dispatches(id,slot,scheduled_at,observed_at,status,detail) VALUES(?,?,?,?,?,?) RETURNING id').bind(id,slot,d.toISOString(),new Date(now).toISOString(),configured?'starting':'blocked',configured?'真正Cloudflare排程事件；尚未取得分析結果':'尚未授權外匯專用GitHub啟動權限；未呼叫GitHub').first();
 if(!row)return {status:'duplicate',slot};
 if(!configured)return {status:'blocked',id};
 const repo=env.FX_GITHUB_REPOSITORY;
 if(typeof repo!=='string'||!/^[-A-Za-z0-9_.]+\/[-A-Za-z0-9_.]+$/.test(repo))throw Error('缺少限定外匯專案名稱');
 const url='https://api.github.com/repos/'+repo+'/actions/workflows/analyze.yml/dispatches';
 for(let attempt=1;attempt<=2;attempt++){
  await env.FX_DB.prepare("UPDATE analysis_dispatches SET attempts=? WHERE id=?").bind(attempt,id).run();
  let r;
  try{r=await fetcher(url,{method:'POST',redirect:'manual',headers:{Authorization:'Bearer '+env.FX_GITHUB_DISPATCH_TOKEN,Accept:'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'FXIntelCloudScheduler/1.0','Content-Type':'application/json'},body:JSON.stringify({ref:'main',inputs:{cloud_schedule_id:id}}),signal:AbortSignal.timeout(15000)});}
  catch{await env.FX_DB.prepare("UPDATE analysis_dispatches SET status='unknown',detail=? WHERE id=?").bind('連線結果不明，不盲目重送；不是分析成功',id).run();return {status:'unknown',id};}
  if(r.status===204){await env.FX_DB.prepare("UPDATE analysis_dispatches SET status='accepted',http_status=204,detail=? WHERE id=?").bind('GitHub已接受啟動；必須另外核對雲端工作與D1分析成功',id).run();return {status:'accepted',id};}
  if(r.status>=500&&attempt===1)continue;
  await env.FX_DB.prepare("UPDATE analysis_dispatches SET status='failed',http_status=?,detail=? WHERE id=?").bind(r.status,'GitHub未接受啟動；未讀取或記錄可能包含機密的回應全文',id).run();return {status:'failed',id,http_status:r.status};
 }
}
// claims必須來自既有OIDC完整驗簽後的結果；不可直接信任HTTP傳入的run_id。
export async function claimDispatch(env,id,claims,at=Date.now()){
 if(!/^[a-f0-9-]{36}$/.test(id)||claims?.event_name!=='workflow_dispatch'||!/^\d+$/.test(String(claims.run_id))||claims.repository!==env.FX_GITHUB_REPOSITORY||claims.ref!=='refs/heads/main')throw Error('排程執行身分不符');
 const row=await env.FX_DB.prepare('SELECT * FROM analysis_dispatches WHERE id=?').bind(id).first();
 if(!row||!['starting','accepted','unknown'].includes(row.status)||at-Date.parse(row.observed_at)<0||at-Date.parse(row.observed_at)>600000)throw Error('沒有對應且未過期的真正雲端排程紀錄');
 if(row.github_run_id&&row.github_run_id!==String(claims.run_id))throw Error('排程識別碼已由其他工作使用');
 const changed=await env.FX_DB.prepare('UPDATE analysis_dispatches SET github_run_id=? WHERE id=? AND (github_run_id IS NULL OR github_run_id=?) RETURNING id').bind(String(claims.run_id),id,String(claims.run_id)).first();
 if(!changed)throw Error('排程識別碼重複使用');
 return {trigger_kind:'cloudflare_schedule',dispatch_id:id,scheduled_at:row.scheduled_at,github_run_id:String(claims.run_id)};
}

// 到期前7日、1日及到期時各留一筆持久化系統提醒。Email尚未授權時只留待送與頁面狀態。
export async function remindExpiry(env,now=Date.now()){
 const expiry=Date.parse(env.FX_GITHUB_TOKEN_EXPIRES||'');
 if(!env.FX_DB||!Number.isFinite(expiry))return {status:'not_configured'};
 const days=(expiry-now)/86400000,stage=days<=0?'expired':days<=1?'one_day':days<=7?'seven_days':null;
 if(!stage)return {status:'not_due'};
 const id='dispatch-expiry-'+new Date(expiry).toISOString().slice(0,10)+'-'+stage;
 const body=JSON.stringify({text:'【系統授權到期提醒・非交易訊號】\n外匯專用GitHub啟動授權到期時間：'+new Date(expiry).toISOString()+'。'+(days<=0?'已到期，停止啟動分析。':'請於到期前安全更新；不要貼金鑰到聊天。')+'\nEmail未設定時，此提醒只保存在私人頁面與雲端資料庫。'});
 await env.FX_DB.prepare("INSERT OR IGNORE INTO outbox(id,kind,created_at,expires_at,body,status) VALUES(?,'system',?,?,?,'pending')").bind(id,new Date(now).toISOString(),new Date(now+7*86400000).toISOString(),body).run();
 return {status:stage,id};
}

// 原生與備援共用時槽；同一GitHub工作重試可繼續，不同工作不重複分析。
export async function claimAnalysisSlot(env,claims,dispatchId='',now=Date.now()){
 if(!/^\d+$/.test(String(claims?.run_id))||claims.repository!==env.GITHUB_REPOSITORY||claims.ref!=='refs/heads/main')throw Error('工作身分不符');
 let at=now;
 if(dispatchId){const row=await env.FX_DB.prepare('SELECT * FROM analysis_dispatches WHERE id=?').bind(dispatchId).first();if(!row||row.github_run_id!==String(claims.run_id))throw Error('未確認雲端收據');at=Date.parse(row.scheduled_at)}
 else if(claims.event_name==='workflow_dispatch')return {allowed:true,mode:'explicit_manual'};
 else if(claims.event_name!=='schedule')throw Error('不支援的排程身分');
 const slot=String(Math.floor((at-8*60000)/(30*60000)));
 await env.FX_DB.prepare('INSERT OR IGNORE INTO analysis_slots(slot,github_run_id,created_at) VALUES(?,?,?)').bind(slot,String(claims.run_id),new Date(now).toISOString()).run();
 const row=await env.FX_DB.prepare('SELECT github_run_id FROM analysis_slots WHERE slot=?').bind(slot).first();
 return {allowed:row?.github_run_id===String(claims.run_id),slot,mode:dispatchId?'cloudflare_schedule':'native_schedule'};
}

// 真實Workers環境的唯讀預檢；不呼叫dispatches，不建立分析工作。
export async function preflightGithub(env){
 if(!env.FX_GITHUB_DISPATCH_TOKEN||!env.GITHUB_REPOSITORY)return {configured:false};
 let legacyRedirectSupport='unknown';
 try{new Request('https://api.github.com/',{redirect:'error'});legacyRedirectSupport='supported'}catch{legacyRedirectSupport='unsupported'}
 const r=await fetch('https://api.github.com/repos/'+env.GITHUB_REPOSITORY+'/actions/workflows/analyze.yml',{redirect:'manual',headers:{Authorization:'Bearer '+env.FX_GITHUB_DISPATCH_TOKEN,Accept:'application/vnd.github+json','User-Agent':'FXIntelCloudScheduler/1.0'},signal:AbortSignal.timeout(15000)});
 let state=null;if(r.ok){const x=await r.json();state=x.state||null;}
 return {configured:true,workflow_http_status:r.status,workflow_state:state,redirect_mode:'manual',legacy_redirect_error_mode:legacyRedirectSupport,automatic_analysis_triggered:false};
}
