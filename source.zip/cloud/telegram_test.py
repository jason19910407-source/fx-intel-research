"""只允許手動執行的傳輸測試，不產生虛構交易。"""
import os,json,datetime as dt
from .store import Store

def run():
 if os.environ.get('GITHUB_EVENT_NAME')!='workflow_dispatch':raise RuntimeError('通知測試只允許手動觸發')
 store=Store();at=dt.datetime.now(dt.timezone.utc);key='transport-test-'+os.environ['GITHUB_RUN_ID']
 body=json.dumps({'text':'【雲端通知通路測試・不是交易訊號】\n外匯情報研究系統已由GitHub雲端工作傳送本測試。\n不含交易建議、不代表策略已驗證、不會下單。\n時間：'+at.isoformat()},ensure_ascii=False)
 store.query("INSERT OR IGNORE INTO outbox(id,kind,created_at,expires_at,body,status) VALUES(?,'test',?,?,?,'pending')",(key,at.isoformat(),(at+dt.timedelta(minutes=30)).isoformat(),body))
 result=store.notify()
 if not result.get('configured'):raise RuntimeError('Telegram尚未設定，測試不能宣稱成功')
 return result
if __name__=='__main__':print(json.dumps(run(),ensure_ascii=False))
