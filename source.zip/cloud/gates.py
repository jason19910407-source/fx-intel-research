"""保守通知閘門；不能以每日參考價生成虛構交易構想。"""
import math,datetime as dt,hashlib,json
UTC=dt.timezone.utc
REQUIRED=['quote_fresh','cost_verified','calendar_complete','account_fresh','drawdown_ok','sources_ok','market_open','no_event_veto','spread_slippage_ok','sizing_verified']
def stamp(x):
 try:
  v=dt.datetime.fromisoformat(str(x).replace('Z','+00:00'))
  return v.astimezone(UTC) if v.tzinfo else None
 except (ValueError,TypeError):return None

def eligibility(candidate,at):
 reasons=[]
 if candidate.get('simulation'):reasons.append('模擬訊號禁止當成研究交易通知')
 score=candidate.get('score')
 if not isinstance(score,(float,int)) or not math.isfinite(score) or not 70<=score<=100:reasons.append('分數未達70或無效')
 if candidate.get('legacy_gate',{}).get('passed') is not True:reasons.append('原有策略及風控資格未通過')
 for k in REQUIRED:
  if candidate.get('conditions',{}).get(k) is not True:reasons.append('未通過：'+k)
 pair=candidate.get('pair');direction=candidate.get('direction')
 if pair not in ['EURUSD','USDJPY','GBPUSD']:reasons.append('貨幣對不支援')
 if direction not in ['做多','做空']:reasons.append('缺少明確交易方向')
 nums=[candidate.get(k) for k in ['entry','stop','tp1','tp2','risk_twd','equity_twd','units','net_reward_risk']]
 valid=all(isinstance(v,(float,int)) and math.isfinite(v) and v>0 for v in nums)
 if not valid:reasons.append('沒有經驗證的進出場、數量與成本數值')
 else:
  entry,stop,t1,t2,risk,equity,units,rr=nums
  if not (stop<entry<t1<=t2 if direction=='做多' else t2<=t1<entry<stop):reasons.append('進出場方向錯誤')
  if rr<2:reasons.append('扣成本後風險報酬比未達1：2')
  if equity>35000 or risk>min(equity,35000)*.01 or risk<min(equity,35000)*.005:reasons.append('風險金額不在本金0.5%至1%內')
 expires=stamp(candidate.get('expires_at'));data=stamp(candidate.get('data_at'))
 if not expires or not 0<(expires-at).total_seconds()<=1800:reasons.append('訊號無效或期限不明')
 if not data or not 0<=(at-data).total_seconds()<=60:reasons.append('報價時間缺失、過期或來自未來')
 if not candidate.get('reasons'):reasons.append('缺少分析依據')
 return dict(passed=not reasons,reasons=reasons)

def signal_id(c):
 # 分數或執行時間改變不構成新訊號；候選產生器須固定setup_id。
 required=['pair','direction','setup_id','entry','stop','tp1','tp2']
 if not c.get('setup_id'):raise ValueError('缺少持久化交易構想識別碼')
 return hashlib.sha256(json.dumps({k:c[k] for k in required},sort_keys=True).encode()).hexdigest()

def message(c):
 return '\n'.join(['研究訊號，非已驗證交易策略',c['pair']+'｜'+c['direction'],'綜合信心分數：'+str(c['score'])+'／100','建議進場：'+str(c['entry']),'停損：'+str(c['stop']),'第一停利：'+str(c['tp1'])+'；第二停利：'+str(c['tp2']),'預估風險：新臺幣'+str(c['risk_twd'])+'元；數量：'+str(c['units'])+'基礎貨幣單位','有效期限：'+c['expires_at'],'理由：'+str(c['reasons']),'分析資料時間：'+c['data_at'],'僅供人工複核；不會自動下單，停損可能滑價。'])
