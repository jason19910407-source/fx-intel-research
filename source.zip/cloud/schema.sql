-- 獨立外匯研究資料庫；不可對既有客戶管理資料庫執行。
CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY,v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS lease(k TEXT PRIMARY KEY,owner TEXT NOT NULL,expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS checkpoints(generation TEXT NOT NULL,part INTEGER NOT NULL,body TEXT NOT NULL,PRIMARY KEY(generation,part));
CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY,started_at TEXT NOT NULL,ended_at TEXT,status TEXT NOT NULL,trigger_kind TEXT NOT NULL,workflow_url TEXT,source_count INTEGER,summary TEXT);
CREATE INDEX IF NOT EXISTS runs_time ON runs(started_at);
CREATE TABLE IF NOT EXISTS analyses(id TEXT PRIMARY KEY,at TEXT NOT NULL,body TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS analyses_time ON analyses(at);
CREATE TABLE IF NOT EXISTS outbox(id TEXT PRIMARY KEY,kind TEXT NOT NULL,created_at TEXT NOT NULL,expires_at TEXT NOT NULL,body TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',attempts INTEGER NOT NULL DEFAULT 0,message_id TEXT,detail TEXT);
CREATE INDEX IF NOT EXISTS outbox_time ON outbox(created_at);
CREATE TABLE IF NOT EXISTS prediction_outcomes(signal_id TEXT PRIMARY KEY,observed_at TEXT NOT NULL,status TEXT NOT NULL,evidence TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS login_limits(bucket TEXT PRIMARY KEY,n INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS daily_budget(day TEXT PRIMARY KEY,runs INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS email_deliveries(id TEXT PRIMARY KEY,outbox_id TEXT NOT NULL UNIQUE,signal_key TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,status TEXT NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,first_attempt_at TEXT,next_attempt_at TEXT,provider_id TEXT,provider_status TEXT,payload TEXT NOT NULL,detail TEXT);
CREATE INDEX IF NOT EXISTS email_delivery_time ON email_deliveries(created_at);
CREATE TABLE IF NOT EXISTS signal_notifications(signal_key TEXT PRIMARY KEY,last_candidate TEXT NOT NULL,last_sent_at TEXT NOT NULL,delivery_id TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS email_budget(period TEXT PRIMARY KEY,used INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS monitor_runs(id TEXT PRIMARY KEY,scheduled_at TEXT NOT NULL,checked_at TEXT NOT NULL,last_analysis_success TEXT,status TEXT NOT NULL,detail TEXT);
CREATE INDEX IF NOT EXISTS monitor_time ON monitor_runs(checked_at);
CREATE INDEX IF NOT EXISTS runs_trigger_time ON runs(trigger_kind,status,started_at);

-- Cloudflare自動啟動收據；與分析資料列交叉驗收。
CREATE TABLE IF NOT EXISTS analysis_dispatches(
 id TEXT PRIMARY KEY,slot TEXT NOT NULL UNIQUE,scheduled_at TEXT NOT NULL,
 observed_at TEXT NOT NULL,status TEXT NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,
 github_run_id TEXT UNIQUE,http_status INTEGER,detail TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS analysis_slots(slot TEXT PRIMARY KEY,github_run_id TEXT NOT NULL,created_at TEXT NOT NULL);
