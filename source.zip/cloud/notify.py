import os,json,urllib.request,urllib.error,time,datetime as dt
from .gates import eligibility,signal_id,message,stamp
UTC=dt.timezone.utc

def enqueue(store,candidate,at):
 gate=eligibility(candidate,at)
 if not gate['passed']:return dict(enqueued=False,reasons=gate['reasons'])
 key=signal_id(candidate)
 store.query("INSERT OR IGNORE INTO outbox(id,kind,created_at,expires_at,body,status) VALUES(?,'research',?,?,?,'pending')",(key,at.isoformat(),candidate['expires_at'],json.dumps(candidate,ensure_ascii=False)))
 return dict(enqueued=True,id=key)

def telegram_send(text):
 token=os.environ['TELEGRAM_BOT_TOKEN'];chat=os.environ['TELEGRAM_CHAT_ID']
 req=urllib.request.Request('https://api.telegram.org/bot'+token+'/sendMessage',data=json.dumps(dict(chat_id=chat,text=text[:4000],disable_web_page_preview=True,protect_content=True)).encode(),headers={'Content-Type':'application/json'},method='POST')
 try:
  with urllib.request.urlopen(req,timeout=20) as r:d=json.load(r)
  if d.get('ok'):return 'sent',str(d['result']['message_id']),None
  return 'failed',None,'Telegram 拒絕訊息'
 except urllib.error.HTTPError as e:
  if e.code==429:
   try:wait=int(json.loads(e.read()).get('parameters',{}).get('retry_after',60))
   except Exception:wait=60
   return 'retry',None,min(max(wait,1),3600)
  # 伺服器可能已送出：5xx不盲目重送，避免重複手機通知。
  return ('unknown' if e.code>=500 else 'failed'),None,'Telegram HTTP '+str(e.code)
 except Exception:return 'unknown',None,'連線結果不明；不自動重送，以免重複'

def deliver(store,send=telegram_send,at=None):
 at=at or dt.datetime.now(UTC);out=[]
 for row in store.query("SELECT * FROM outbox WHERE status='pending' ORDER BY created_at LIMIT 5"):
  expiry=stamp(row['expires_at'])
  if not expiry or expiry<=at:
   store.query("UPDATE outbox SET status='expired',detail='超過有效期限' WHERE id=? AND status='pending'",(row['id'],));continue
  candidate=json.loads(row['body'])
  if row['kind']=='research':
   if not eligibility(candidate,at)['passed']:
    store.query("UPDATE outbox SET status='rejected',detail='送出前重新審查未通過' WHERE id=? AND status='pending'",(row['id'],));continue
   text=message(candidate)
  elif row['kind'] in ['test','system']:text=candidate['text']
  else:continue
  # 發送前必須取得持久化單次送出權。中途當機留下 sending，不自動重送。
  claimed=store.query("UPDATE outbox SET status='sending',attempts=attempts+1 WHERE id=? AND status='pending' AND attempts<3 RETURNING id",(row['id'],))
  if not claimed:continue
  for attempt in range(3):
   status,msg,detail=send(text)
   if status!='retry':break
   if not isinstance(detail,int) or detail>30 or attempt==2 or dt.datetime.now(UTC)+dt.timedelta(seconds=detail)>=expiry:
    status='failed';detail='限流重試已達保守上限';break
   time.sleep(detail)
   store.query('UPDATE outbox SET attempts=attempts+1 WHERE id=?',(row['id'],))
  store.query('UPDATE outbox SET status=?,message_id=?,detail=? WHERE id=? AND status=\'sending\'',(status,msg,str(detail or ''),row['id']))
  out.append(dict(id=row['id'],kind=row['kind'],status=status))
 return out
