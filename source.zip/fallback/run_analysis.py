"""待授權備援入口；正式排程目前尚未使用此檔。沿用cloud.runner，不更動分析參數。"""
import os,json,urllib.request
from cloud.store import Store

def confirm_dispatch():
 dispatch=os.getenv('FX_CLOUD_SCHEDULE_ID','')
 if not dispatch:return None
 if os.getenv('GITHUB_EVENT_NAME')!='workflow_dispatch':raise RuntimeError('備援啟動事件不符')
 store=Store();store.refresh_identity()
 request=urllib.request.Request(store.base+'/internal/schedule-claim',data=json.dumps({'id':dispatch}).encode(),headers={'Authorization':'Bearer '+store.oidc,'Content-Type':'application/json'},method='POST')
 try:
  with urllib.request.urlopen(request,timeout=20) as response:receipt=json.load(response)
 except Exception:raise RuntimeError('尚未確認真正雲端排程收據，禁止執行分析') from None
 if receipt.get('dispatch_id')!=dispatch or receipt.get('github_run_id')!=os.getenv('GITHUB_RUN_ID') or receipt.get('trigger_kind')!='cloudflare_schedule':raise RuntimeError('雲端排程收據與工作編號不符')
 os.environ['GITHUB_EVENT_NAME']='cloudflare_schedule'
 return receipt

def claim_slot():
 store=Store();store.refresh_identity()
 request=urllib.request.Request(store.base+'/internal/analysis-slot',data=json.dumps({'id':os.getenv('FX_CLOUD_SCHEDULE_ID','')}).encode(),headers={'Authorization':'Bearer '+store.oidc,'Content-Type':'application/json'},method='POST')
 try:
  with urllib.request.urlopen(request,timeout=20) as response:result=json.load(response)
 except Exception:raise RuntimeError('無法確認排程時槽，停止以免重複分析') from None
 if not isinstance(result.get('allowed'),bool):raise RuntimeError('排程時槽回應不合格')
 return result

if __name__=='__main__':
 confirm_dispatch()
 slot=claim_slot()
 if slot['allowed']:
  from cloud.runner import run
  print(json.dumps(run(),ensure_ascii=False))
 else:print(json.dumps({'status':'同一半小時已有其他工作，不重複分析','slot':slot.get('slot')},ensure_ascii=False))
