"""隔離測試，不連網、不使用任何真實憑證或資料。"""
import unittest,os,json
from unittest.mock import patch,MagicMock
from fallback.run_analysis import confirm_dispatch
class Bridge(unittest.TestCase):
 def setUp(self):
  self.variables={'FX_CLOUD_SCHEDULE_ID':'fixture-dispatch','GITHUB_EVENT_NAME':'workflow_dispatch','GITHUB_RUN_ID':'1234'}
 def response(self,receipt):
  r=MagicMock();r.__enter__.return_value.read.return_value=json.dumps(receipt).encode();return r
 def receipt(self):return {'dispatch_id':'fixture-dispatch','github_run_id':'1234','trigger_kind':'cloudflare_schedule'}
 def test_manual_unchanged(self):
  with patch.dict(os.environ,{'GITHUB_EVENT_NAME':'workflow_dispatch'},clear=True),patch('fallback.run_analysis.Store') as store:
   self.assertIsNone(confirm_dispatch());store.assert_not_called();self.assertEqual(os.environ['GITHUB_EVENT_NAME'],'workflow_dispatch')
 def test_wrong_event_rejected(self):
  with patch.dict(os.environ,{**self.variables,'GITHUB_EVENT_NAME':'schedule'},clear=True):
   with self.assertRaises(RuntimeError):confirm_dispatch()
 def test_verified_receipt_only_then_marks_cloud_schedule(self):
  with patch.dict(os.environ,self.variables,clear=True),patch('fallback.run_analysis.Store') as store,patch('urllib.request.urlopen',return_value=self.response(self.receipt())):
   store.return_value.base='https://fixture.example';store.return_value.oidc='fixture-token';self.assertEqual(confirm_dispatch()['github_run_id'],'1234');self.assertEqual(os.environ['GITHUB_EVENT_NAME'],'cloudflare_schedule')
 def test_mismatched_receipt_never_marks_automatic(self):
  for change in [{'dispatch_id':'other'},{'github_run_id':'5678'},{'trigger_kind':'manual'}]:
   with self.subTest(change=change),patch.dict(os.environ,self.variables,clear=True),patch('fallback.run_analysis.Store') as store,patch('urllib.request.urlopen',return_value=self.response({**self.receipt(),**change})):
    store.return_value.base='https://fixture.example';store.return_value.oidc='fixture-token'
    with self.assertRaises(RuntimeError):confirm_dispatch()
    self.assertEqual(os.environ['GITHUB_EVENT_NAME'],'workflow_dispatch')
 def test_unconfirmed_network_never_marks_automatic(self):
  with patch.dict(os.environ,self.variables,clear=True),patch('fallback.run_analysis.Store') as store,patch('urllib.request.urlopen',side_effect=Exception('fixture-secret')):
   store.return_value.base='https://fixture.example';store.return_value.oidc='fixture-token'
   with self.assertRaisesRegex(RuntimeError,'尚未確認'):confirm_dispatch()
   self.assertEqual(os.environ['GITHUB_EVENT_NAME'],'workflow_dispatch')
if __name__=='__main__':unittest.main()
